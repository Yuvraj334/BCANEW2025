
import React, { useState, useEffect } from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { FinanceProvider } from "@/contexts/FinanceContext";
import { AiAssistantProvider } from "@/contexts/AiAssistantContext";
import { ThemeProvider } from "@/contexts/ThemeContext";
import NavBar from "@/components/layout/NavBar";
import CustomizationDialog from "@/components/layout/CustomizationDialog";
import SplashScreen from "@/components/layout/SplashScreen";
import Index from "./pages/Index";
import Expenses from "./pages/Expenses";
import History from "./pages/History";
import Insights from "./pages/Insights";
import AiAssistant from "./pages/AiAssistant";
import Profile from "./pages/Profile";
import About from "./pages/About";
import Testimonials from "./pages/Testimonials";
import Auth from "./pages/Auth";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

// Wrapper for protected routes
const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  // Check if user is logged in (in a real app, this would verify auth tokens)
  const isLoggedIn = localStorage.getItem('wealthsync-user') !== null;
  
  // If not logged in, redirect to auth page
  if (!isLoggedIn) {
    return <Navigate to="/login" replace />;
  }
  
  return <>{children}</>;
};

const Layout = ({ children }: { children: React.ReactNode }) => (
  <div className="min-h-screen bg-wealthsync-dark">
    <NavBar />
    {children}
  </div>
);

const App = () => {
  const [showSplash, setShowSplash] = useState(true);
  
  // Control how long splash screen shows
  useEffect(() => {
    // If user has visited before, skip splash or make it shorter
    const hasVisited = localStorage.getItem('hasVisited');
    
    const timeout = setTimeout(() => {
      setShowSplash(false);
      localStorage.setItem('hasVisited', 'true');
    }, hasVisited ? 1000 : 3000);
    
    return () => clearTimeout(timeout);
  }, []);

  if (showSplash) {
    return (
      <ThemeProvider>
        <SplashScreen onFinished={() => setShowSplash(false)} />
      </ThemeProvider>
    );
  }

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <ThemeProvider>
          <FinanceProvider>
            <AiAssistantProvider>
              <BrowserRouter>
                <Routes>
                  <Route path="/login" element={<Auth />} />
                  <Route 
                    path="/" 
                    element={
                      <ProtectedRoute>
                        <Index />
                      </ProtectedRoute>
                    } 
                  />
                  <Route 
                    path="/expenses" 
                    element={
                      <ProtectedRoute>
                        <Layout>
                          <Expenses />
                        </Layout>
                      </ProtectedRoute>
                    }
                  />
                  <Route 
                    path="/history" 
                    element={
                      <ProtectedRoute>
                        <Layout>
                          <History />
                        </Layout>
                      </ProtectedRoute>
                    }
                  />
                  <Route 
                    path="/insights" 
                    element={
                      <ProtectedRoute>
                        <Layout>
                          <Insights />
                        </Layout>
                      </ProtectedRoute>
                    }
                  />
                  <Route 
                    path="/ai-assistant" 
                    element={
                      <ProtectedRoute>
                        <Layout>
                          <AiAssistant />
                        </Layout>
                      </ProtectedRoute>
                    }
                  />
                  <Route 
                    path="/about" 
                    element={
                      <ProtectedRoute>
                        <Layout>
                          <About />
                        </Layout>
                      </ProtectedRoute>
                    }
                  />
                  <Route 
                    path="/testimonials" 
                    element={
                      <ProtectedRoute>
                        <Layout>
                          <Testimonials />
                        </Layout>
                      </ProtectedRoute>
                    }
                  />
                  <Route 
                    path="/profile" 
                    element={
                      <ProtectedRoute>
                        <Layout>
                          <Profile />
                        </Layout>
                      </ProtectedRoute>
                    }
                  />
                  <Route path="*" element={<NotFound />} />
                </Routes>
                <CustomizationDialog />
                <Toaster />
                <Sonner />
              </BrowserRouter>
            </AiAssistantProvider>
          </FinanceProvider>
        </ThemeProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;
