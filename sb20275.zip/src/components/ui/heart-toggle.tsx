
import * as React from "react";
import { Switch } from "@/components/ui/switch";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";

interface HeartToggleProps extends React.ComponentPropsWithoutRef<typeof Switch> {
  size?: "default" | "sm" | "lg";
}

const HeartToggle = React.forwardRef<
  React.ElementRef<typeof Switch>,
  HeartToggleProps
>(({ className, size = "default", ...props }, ref) => {
  const [isAnimating, setIsAnimating] = React.useState(false);
  
  const sizeClasses = {
    sm: "w-9 h-5",
    default: "w-11 h-6", 
    lg: "w-14 h-7"
  };
  
  const thumbClasses = {
    sm: "h-4 w-4",
    default: "h-5 w-5",
    lg: "h-6 w-6"
  };

  const handleChange = (checked: boolean) => {
    if (checked) {
      setIsAnimating(true);
      setTimeout(() => setIsAnimating(false), 1000);
    }
    if (props.onCheckedChange) {
      props.onCheckedChange(checked);
    }
  };

  return (
    <Switch
      ref={ref}
      className={cn(
        "peer inline-flex shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-pink-500 data-[state=unchecked]:bg-gray-600",
        sizeClasses[size],
        className
      )}
      style={{
        backgroundImage: props.checked 
          ? "linear-gradient(225deg, #FFE29F 0%, #FFA99F 48%, #FF719A 100%)" 
          : "linear-gradient(to right, #243949 0%, #517fa4 100%)"
      }}
      onCheckedChange={handleChange}
      checked={props.checked}
    >
      <motion.span
        className={cn(
          "pointer-events-none flex items-center justify-center rounded-full bg-white shadow-lg ring-0 transition-transform data-[state=checked]:translate-x-[calc(100%-0.25rem)] data-[state=unchecked]:translate-x-0",
          thumbClasses[size],
          "relative group overflow-hidden"
        )}
        animate={isAnimating ? {
          scale: [1, 1.2, 1],
          transition: { duration: 0.4 }
        } : {}}
      >
        <motion.span 
          className={cn(
            "absolute inset-0 flex items-center justify-center opacity-0 transition-opacity data-[state=checked]:opacity-100",
            "text-pink-500 text-[10px] font-bold"
          )}
          data-state={props.checked ? "checked" : "unchecked"}
          animate={isAnimating ? {
            scale: [1, 1.5, 1],
            transition: { duration: 0.4 }
          } : {}}
        >
          ♥
        </motion.span>
        <span 
          className={cn(
            "absolute inset-0 flex items-center justify-center opacity-0 transition-opacity data-[state=unchecked]:opacity-100",
            "text-gray-600 text-[10px] font-bold"
          )}
          data-state={props.checked ? "checked" : "unchecked"}
        >
          ○
        </span>
      </motion.span>
    </Switch>
  );
});

HeartToggle.displayName = "HeartToggle";

export { HeartToggle };
