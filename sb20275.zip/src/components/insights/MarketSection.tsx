
import { useEffect, useState } from "react";
import { Bitcoin, Briefcase, Landmark, ArrowUpRight, ArrowDownRight } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { CryptoData, MarketSectorData } from "@/types";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

interface MarketSectionProps {
  marketTab: string;
  cryptoData?: CryptoData[];
  metalsData?: { name: string; price: number; change: number }[];
  stocksData?: { symbol: string; name: string; price: number; change: number }[];
  isCryptoLoading: boolean;
  isMetalsLoading: boolean;
  isStocksLoading: boolean;
  searchTerm: string;
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];

export function MarketSection({
  marketTab,
  cryptoData,
  metalsData,
  stocksData,
  isCryptoLoading,
  isMetalsLoading,
  isStocksLoading,
  searchTerm
}: MarketSectionProps) {
  const [sectorData, setSectorData] = useState<MarketSectorData[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (marketTab === 'sectors') {
      setIsLoading(true);
      // Mock data for sectors
      setTimeout(() => {
        setSectorData([
          { name: 'Technology', performance: 2.45, marketCap: 14.2, volume: 1.8 },
          { name: 'Healthcare', performance: 1.20, marketCap: 8.4, volume: 1.2 },
          { name: 'Finance', performance: -0.75, marketCap: 9.8, volume: 1.5 },
          { name: 'Energy', performance: 0.45, marketCap: 5.6, volume: 0.9 },
          { name: 'Consumer', performance: -0.25, marketCap: 7.2, volume: 1.1 }
        ]);
        setIsLoading(false);
      }, 800);
    }
  }, [marketTab]);

  const filteredCryptoData = cryptoData?.filter(item => 
    item.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    item.symbol.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredMetalsData = metalsData?.filter(item => 
    item.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredStocksData = stocksData?.filter(item => 
    item.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    item.symbol.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredSectorData = sectorData?.filter(item => 
    item.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const renderSectorChart = () => {
    if (isLoading) return (
      <div className="flex justify-center items-center h-[300px]">
        <Skeleton className="h-[300px] w-full" />
      </div>
    );

    const chartData = sectorData.map(sector => ({
      name: sector.name,
      performance: sector.performance,
      fill: sector.performance > 0 ? "#4CAF50" : "#FF6B6B"
    }));

    return (
      <div className="mt-4">
        <h3 className="text-lg font-semibold mb-2">Sector Performance</h3>
        <div className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} layout="vertical" margin={{ top: 5, right: 30, left: 60, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" horizontal={false} />
              <XAxis type="number" domain={[-3, 3]} tickFormatter={(value) => `${value}%`} />
              <YAxis type="category" dataKey="name" />
              <Tooltip formatter={(value) => [`${value}%`, 'Performance']} />
              <Bar dataKey="performance" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <h3 className="text-lg font-semibold mt-6 mb-2">Market Cap Distribution</h3>
        <div className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={sectorData}
                cx="50%"
                cy="50%"
                labelLine={false}
                outerRadius={120}
                dataKey="marketCap"
                nameKey="name"
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
              >
                {sectorData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip formatter={(value) => [`$${value} trillion`, 'Market Cap']} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>
    );
  };

  const renderCryptoData = () => {
    if (isCryptoLoading) return (
      <div className="space-y-4">
        {[1, 2, 3, 4, 5].map((item) => (
          <div key={item} className="flex items-center justify-between p-3 border border-border rounded-lg">
            <div className="flex items-center gap-3">
              <Skeleton className="h-8 w-8 rounded-full" />
              <div>
                <Skeleton className="h-5 w-24" />
                <Skeleton className="h-4 w-16 mt-1" />
              </div>
            </div>
            <div className="text-right">
              <Skeleton className="h-5 w-20" />
              <Skeleton className="h-4 w-12 mt-1 ml-auto" />
            </div>
          </div>
        ))}
      </div>
    );

    if (!filteredCryptoData?.length) return (
      <div className="text-center py-12">
        <Bitcoin className="h-16 w-16 mx-auto text-muted-foreground opacity-20" />
        <h3 className="mt-4 text-lg font-medium">No crypto data available</h3>
        <p className="text-muted-foreground">Try adjusting your search or check back later</p>
      </div>
    );

    return (
      <div className="space-y-4">
        {filteredCryptoData?.map((coin) => (
          <div key={coin.id} className="flex items-center justify-between p-3 border border-border bg-background/50 rounded-lg hover:bg-background/80 transition-colors">
            <div className="flex items-center gap-3">
              <img src={coin.image} alt={coin.name} className="h-8 w-8 rounded-full" />
              <div>
                <h3 className="font-medium">{coin.name}</h3>
                <span className="text-sm text-muted-foreground">{coin.symbol.toUpperCase()}</span>
              </div>
            </div>
            <div className="text-right">
              <div className="font-medium">${coin.current_price.toLocaleString()}</div>
              <div className={`text-sm flex items-center justify-end ${coin.price_change_percentage_24h >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                {coin.price_change_percentage_24h >= 0 ? (
                  <ArrowUpRight className="h-3 w-3 mr-1" />
                ) : (
                  <ArrowDownRight className="h-3 w-3 mr-1" />
                )}
                {Math.abs(coin.price_change_percentage_24h).toFixed(2)}%
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  };

  const renderMetalsData = () => {
    if (isMetalsLoading) return (
      <div className="space-y-4">
        {[1, 2, 3].map((item) => (
          <div key={item} className="flex items-center justify-between p-3 border border-border rounded-lg">
            <div>
              <Skeleton className="h-5 w-24" />
            </div>
            <div className="text-right">
              <Skeleton className="h-5 w-20" />
              <Skeleton className="h-4 w-12 mt-1 ml-auto" />
            </div>
          </div>
        ))}
      </div>
    );

    if (!filteredMetalsData?.length) return (
      <div className="text-center py-12">
        <svg className="h-16 w-16 mx-auto text-muted-foreground opacity-20" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M12 22V8M5 12H2a10 10 0 0020 0h-3"/>
          <path d="M5 12V8a2 2 0 012-2h10a2 2 0 012 2v4"/>
        </svg>
        <h3 className="mt-4 text-lg font-medium">No metals data available</h3>
        <p className="text-muted-foreground">Try adjusting your search or check back later</p>
      </div>
    );

    return (
      <div className="space-y-4">
        {filteredMetalsData?.map((metal, index) => (
          <div key={index} className="flex items-center justify-between p-3 border border-border bg-background/50 rounded-lg hover:bg-background/80 transition-colors">
            <div className="flex items-center gap-3">
              <div className={`h-8 w-8 rounded-full flex items-center justify-center ${
                metal.name === 'Gold' ? 'bg-amber-200' : 
                metal.name === 'Silver' ? 'bg-gray-200' : 
                'bg-gray-300'
              }`}>
                <span className="text-xs font-bold text-black opacity-70">{metal.name.charAt(0)}</span>
              </div>
              <h3 className="font-medium">{metal.name}</h3>
            </div>
            <div className="text-right">
              <div className="font-medium">${metal.price.toFixed(2)}</div>
              <div className={`text-sm flex items-center justify-end ${metal.change >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                {metal.change >= 0 ? (
                  <ArrowUpRight className="h-3 w-3 mr-1" />
                ) : (
                  <ArrowDownRight className="h-3 w-3 mr-1" />
                )}
                {Math.abs(metal.change).toFixed(2)}%
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  };

  const renderStocksData = () => {
    if (isStocksLoading) return (
      <div className="space-y-4">
        {[1, 2, 3, 4].map((item) => (
          <div key={item} className="flex items-center justify-between p-3 border border-border rounded-lg">
            <div>
              <Skeleton className="h-5 w-24" />
              <Skeleton className="h-4 w-16 mt-1" />
            </div>
            <div className="text-right">
              <Skeleton className="h-5 w-20" />
              <Skeleton className="h-4 w-12 mt-1 ml-auto" />
            </div>
          </div>
        ))}
      </div>
    );

    if (!filteredStocksData?.length) return (
      <div className="text-center py-12">
        <Briefcase className="h-16 w-16 mx-auto text-muted-foreground opacity-20" />
        <h3 className="mt-4 text-lg font-medium">No stocks data available</h3>
        <p className="text-muted-foreground">Try adjusting your search or check back later</p>
      </div>
    );

    return (
      <div className="space-y-4">
        {filteredStocksData?.map((stock, index) => (
          <div key={index} className="flex items-center justify-between p-3 border border-border bg-background/50 rounded-lg hover:bg-background/80 transition-colors">
            <div>
              <h3 className="font-medium">{stock.name}</h3>
              <span className="text-sm text-muted-foreground">{stock.symbol}</span>
            </div>
            <div className="text-right">
              <div className="font-medium">${stock.price.toFixed(2)}</div>
              <div className={`text-sm flex items-center justify-end ${stock.change >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                {stock.change >= 0 ? (
                  <ArrowUpRight className="h-3 w-3 mr-1" />
                ) : (
                  <ArrowDownRight className="h-3 w-3 mr-1" />
                )}
                {Math.abs(stock.change).toFixed(2)}%
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  };

  return (
    <div>
      {marketTab === 'crypto' && renderCryptoData()}
      {marketTab === 'metals' && renderMetalsData()}
      {marketTab === 'stocks' && renderStocksData()}
      {marketTab === 'sectors' && renderSectorChart()}
    </div>
  );
}

export default MarketSection;
