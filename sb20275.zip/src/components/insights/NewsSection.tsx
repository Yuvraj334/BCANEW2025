
import { CalendarIcon, ExternalLinkIcon } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { NewsItem } from "@/types";

interface NewsSectionProps {
  newsTab: string;
  newsData?: any[];
  isNewsLoading: boolean;
  searchTerm: string;
}

const defaultNewsImage = "https://images.unsplash.com/photo-1526304640581-d334cdbbf45e?auto=format&fit=crop&q=80";

// More comprehensive mock data with categories
const mockNewsData: NewsItem[] = [
  {
    title: 'Markets rally on hopes of interest rate cuts',
    source: 'Financial Times',
    date: '2023-07-12',
    url: '#',
    imageUrl: 'https://images.unsplash.com/photo-1590283603385-17ffb3a7f29f?auto=format&fit=crop&q=80',
    category: 'investing',
    summary: 'Global markets rallied this week as central banks signaled potential interest rate cuts in response to cooling inflation data.'
  },
  {
    title: 'Tech stocks surge as AI investments grow',
    source: 'Wall Street Journal',
    date: '2023-07-11',
    url: '#',
    imageUrl: 'https://images.unsplash.com/photo-1518186285589-2f7649de83e0?auto=format&fit=crop&q=80',
    category: 'investing',
    summary: 'Technology sector stocks have seen significant gains as companies increase their investments in artificial intelligence technologies.'
  },
  {
    title: '5 ways to reduce your monthly expenses',
    source: 'Money Magazine',
    date: '2023-07-10',
    url: '#',
    imageUrl: 'https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?auto=format&fit=crop&q=80',
    category: 'spending',
    summary: 'Financial experts share their top tips for cutting back on monthly expenses without sacrificing quality of life.'
  },
  {
    title: 'Smart budgeting strategies for young professionals',
    source: 'Forbes',
    date: '2023-07-09',
    url: '#',
    imageUrl: 'https://images.unsplash.com/photo-1554224155-6726b3ff858f?auto=format&fit=crop&q=80',
    category: 'spending',
    summary: 'Learn how young professionals are managing their finances in today\'s economic environment with these budgeting techniques.'
  },
  {
    title: 'New study reveals shopping habits post-pandemic',
    source: 'CNN Business',
    date: '2023-07-08',
    url: '#',
    category: 'other',
    summary: 'Consumer behavior has shifted significantly following the pandemic, with online shopping remaining strong despite reopened stores.'
  },
  {
    title: 'Understanding the basics of cryptocurrency investment',
    source: 'Bloomberg',
    date: '2023-07-07',
    url: '#',
    category: 'investing',
    summary: 'A beginner\'s guide to understanding cryptocurrency markets and how to approach them as part of a diversified investment strategy.'
  }
];

export function NewsSection({
  newsTab,
  newsData,
  isNewsLoading,
  searchTerm
}: NewsSectionProps) {
  // Use the mock data if no real data is provided
  const allNews = newsData?.length ? newsData : mockNewsData;
  
  // Filter by tab category and search term
  const filteredNews = allNews.filter(news => {
    const matchesCategory = newsTab === 'other' ? true : news.category === newsTab;
    const matchesSearch = news.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         (news.summary && news.summary.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchesCategory && (searchTerm === '' || matchesSearch);
  });

  if (isNewsLoading) {
    return (
      <div className="space-y-6">
        {[1, 2, 3].map((item) => (
          <div key={item} className="flex flex-col md:flex-row gap-4">
            <Skeleton className="h-40 w-full md:w-60 rounded-lg" />
            <div className="flex-1 space-y-2">
              <Skeleton className="h-6 w-4/5" />
              <Skeleton className="h-4 w-1/3" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-3/4" />
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (!filteredNews.length) {
    return (
      <div className="text-center py-12">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mx-auto text-muted-foreground opacity-20" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v10m2 4h-4m-6-5v3m0 0v3m0-3h8m-8 0h8" />
        </svg>
        <h3 className="mt-4 text-lg font-medium">No news articles found</h3>
        <p className="text-muted-foreground">Try adjusting your search or check back later</p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {filteredNews.map((news, index) => (
        <div key={index} className="flex flex-col md:flex-row gap-4">
          <div className="h-40 w-full md:w-60 rounded-lg overflow-hidden">
            <img 
              src={news.imageUrl || defaultNewsImage} 
              alt={news.title}
              className="h-full w-full object-cover"
            />
          </div>
          <div className="flex-1 space-y-2">
            <div className="flex justify-between items-start">
              <Badge variant="secondary" className="mb-2">
                {news.category === 'investing' ? 'Investment' : 
                 news.category === 'spending' ? 'Spending' : 'General'}
              </Badge>
              <div className="flex items-center text-sm text-muted-foreground">
                <CalendarIcon className="h-3 w-3 mr-1" />
                {news.date}
              </div>
            </div>
            <h3 className="text-lg font-semibold">{news.title}</h3>
            <p className="text-muted-foreground text-sm">{news.source}</p>
            {news.summary && (
              <p className="line-clamp-2 text-sm">{news.summary}</p>
            )}
            <Button size="sm" variant="outline" className="mt-2" asChild>
              <a href={news.url} target="_blank" rel="noopener noreferrer">
                Read More <ExternalLinkIcon className="h-3 w-3 ml-1" />
              </a>
            </Button>
          </div>
        </div>
      ))}

      <div className="flex justify-center pt-4">
        <Button variant="outline" className="w-full md:w-auto">
          Load More Articles
        </Button>
      </div>
    </div>
  );
}

export default NewsSection;
