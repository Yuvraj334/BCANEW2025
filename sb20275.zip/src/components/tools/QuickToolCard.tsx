import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { useTheme } from '@/contexts/ThemeContext';

const currencies = ['USD', 'EUR', 'INR', 'GBP', 'JPY', 'CAD'];
const exchangeRates: Record<string, number> = {
  USD: 1,
  EUR: 0.9,
  INR: 83,
  GBP: 0.78,
  JPY: 150,
  CAD: 1.35
};

const QuickToolCard = () => {
  const [expanded, setExpanded] = useState(true);

  // Calculator
  const [calc, setCalc] = useState('');

  // Sticky Note
  const [note, setNote] = useState('');

  // Currency Converter
  const [from, setFrom] = useState('USD');
  const [to, setTo] = useState('INR');
  const [amount, setAmount] = useState(1);
  const converted = ((amount / exchangeRates[from]) * exchangeRates[to]).toFixed(2);

  // Timer
  const [seconds, setSeconds] = useState(0);
  const [running, setRunning] = useState(false);

  React.useEffect(() => {
    let interval: NodeJS.Timeout;
    if (running) {
      interval = setInterval(() => {
        setSeconds((prev) => prev + 1);
      }, 1000);
    } else {
      clearInterval(interval);
    }
    return () => clearInterval(interval);
  }, [running]);

  const { mode } = useTheme();

  return (
    <Card className={`p-4 w-full max-w-xl mx-auto ${mode === 'dark' ? 'bg-navy-blue text-periwinkle' : 'bg-cream text-golden-beige'} rounded-2xl shadow-md`}>
      <CardContent>
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-bold text-golden-beige">Quick Tool Card</h2>
          <Button variant="outline" className="bg-white text-black" onClick={() => setExpanded(!expanded)}>
            {expanded ? 'Minimize' : 'Maximize'}
          </Button>
        </div>

        {expanded && (
          <div className="space-y-6">
            {/* Calculator */}
            <div>
              <h3 className="font-semibold text-golden-beige">Calculator</h3>
              <div className="flex gap-2">
                <Input
                  value={calc}
                  onChange={(e) => setCalc(e.target.value)}
                  placeholder="Enter expression (e.g., 2+2*5)"
                  className="bg-white text-black"
                />
                <Button onClick={() => {
                  try {
                    setCalc(eval(calc).toString());
                  } catch {
                    setCalc('Error');
                  }
                }} className="bg-white text-black">Calculate</Button>
              </div>
            </div>

            {/* Sticky Note */}
            <div>
              <h3 className="font-semibold text-golden-beige">Sticky Note</h3>
              <textarea
                className="w-full p-2 border rounded-md bg-white text-black"
                rows={3}
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="Write your notes here..."
              ></textarea>
            </div>

            {/* Currency Converter */}
            <div>
              <h3 className="font-semibold text-golden-beige">Currency Converter</h3>
              <div className="flex items-center gap-2">
                <Input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(Number(e.target.value))}
                  className="bg-white text-black"
                />
                <Select value={from} onValueChange={setFrom}>
                  <SelectTrigger className="w-24">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {currencies.map((cur) => (
                      <SelectItem key={cur} value={cur}>{cur}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <span className="mx-1">→</span>
                <Select value={to} onValueChange={setTo}>
                  <SelectTrigger className="w-24">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {currencies.map((cur) => (
                      <SelectItem key={cur} value={cur}>{cur}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <div>= {converted} {to}</div>
              </div>
            </div>

            {/* Timer */}
            <div>
              <h3 className="font-semibold text-golden-beige">Timer</h3>
              <div className="flex items-center gap-3">
                <span className="text-xl">{seconds}s</span>
                <Button variant="secondary" className="bg-white text-black" onClick={() => setRunning(!running)}>
                  {running ? 'Pause' : 'Start'}
                </Button>
                <Button variant="destructive" className="bg-white text-black" onClick={() => { setSeconds(0); setRunning(false); }}>
                  Reset
                </Button>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default QuickToolCard;