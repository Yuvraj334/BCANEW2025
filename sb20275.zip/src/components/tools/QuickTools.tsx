
import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Calculator, Calendar, RefreshCcw, PiggyBank, Pencil, StickyNote, Currency, Settings } from 'lucide-react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { useTheme } from '@/contexts/ThemeContext';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { availableCurrencies } from '@/utils/currency';

const QuickTools = () => {
  const { toggleCustomization } = useTheme();
  const [activeTab, setActiveTab] = useState('calculator');
  const [calcInput, setCalcInput] = useState('');
  const [calcResult, setCalcResult] = useState('');
  const [note, setNote] = useState('');
  const [savedNotes, setSavedNotes] = useState<string[]>([]);
  
  // Currency converter state
  const [amount, setAmount] = useState<string>('100');
  const [fromCurrency, setFromCurrency] = useState('USD');
  const [toCurrency, setToCurrency] = useState('INR');
  const [convertedAmount, setConvertedAmount] = useState<number | null>(null);
  
  // Puzzle game state
  const [tiles, setTiles] = useState<number[]>([]);
  const [isWon, setIsWon] = useState(false);
  
  // Exchange rates (simplified for demo)
  const exchangeRates: Record<string, number> = {
    'USD': 1,
    'INR': 83.12,
    'EUR': 0.92,
    'GBP': 0.79,
    'JPY': 154.69,
    'AUD': 1.52,
    'CAD': 1.37,
    'CHF': 0.89,
    'CNY': 7.23,
    'HKD': 7.82,
    'NZD': 1.67,
    'SGD': 1.35,
    'ZAR': 18.73
  };

  // Load saved notes from localStorage
  useEffect(() => {
    const storedNotes = localStorage.getItem('wealthsync-notes');
    if (storedNotes) {
      try {
        setSavedNotes(JSON.parse(storedNotes));
      } catch (e) {
        console.error("Error parsing saved notes:", e);
      }
    }
  }, []);

  // Save notes to localStorage when they change
  useEffect(() => {
    localStorage.setItem('wealthsync-notes', JSON.stringify(savedNotes));
  }, [savedNotes]);
  
  // Initialize puzzle
  useEffect(() => {
    initializePuzzle();
  }, []);

  const handleCalcButtonClick = (value: string) => {
    if (value === 'C') {
      setCalcInput('');
      setCalcResult('');
    } else if (value === '=') {
      try {
        // Safe eval using Function
        const result = new Function('return ' + calcInput)();
        setCalcResult(String(result));
      } catch (error) {
        setCalcResult('Error');
      }
    } else if (value === 'AC') {
      // Remove last character
      setCalcInput(prev => prev.slice(0, -1));
    } else {
      setCalcInput(prev => prev + value);
    }
  };

  const calculatorButtons = [
    ['7', '8', '9', '/'],
    ['4', '5', '6', '*'],
    ['1', '2', '3', '-'],
    ['C', '0', '=', '+'],
    ['(', ')', 'AC', '.']
  ];
  
  const handleSaveNote = () => {
    if (note.trim()) {
      setSavedNotes([...savedNotes, note]);
      setNote('');
      toast.success("Note saved successfully!");
    } else {
      toast.error("Please enter some text for your note");
    }
  };
  
  const handleDeleteNote = (index: number) => {
    const newNotes = [...savedNotes];
    newNotes.splice(index, 1);
    setSavedNotes(newNotes);
    toast.success("Note deleted");
  };
  
  // Currency converter functions
  const handleConvert = () => {
    if (!amount || isNaN(Number(amount))) {
      toast.error("Please enter a valid amount");
      return;
    }
    
    const fromRate = exchangeRates[fromCurrency];
    const toRate = exchangeRates[toCurrency];
    
    if (fromRate && toRate) {
      // Convert to USD first, then to target currency
      const inUSD = Number(amount) / fromRate;
      const converted = inUSD * toRate;
      setConvertedAmount(parseFloat(converted.toFixed(2)));
      toast.success("Currency converted successfully!");
    } else {
      toast.error("Conversion failed. Try again later.");
    }
  };
  
  // Puzzle game functions
  const initializePuzzle = () => {
    // Create a 3x3 puzzle (numbers 0-8, 0 represents the empty space)
    const numbers = Array.from({ length: 9 }, (_, i) => i);
    // Shuffle the numbers (ensuring it's solvable)
    let shuffled = [...numbers];
    do {
      shuffled.sort(() => Math.random() - 0.5);
    } while (!isSolvable(shuffled));
    
    setTiles(shuffled);
    setIsWon(false);
  };
  
  const isSolvable = (puzzle: number[]) => {
    // Count inversions (simplified check for 3x3)
    let inversions = 0;
    for (let i = 0; i < puzzle.length; i++) {
      if (puzzle[i] === 0) continue;
      for (let j = i + 1; j < puzzle.length; j++) {
        if (puzzle[j] === 0) continue;
        if (puzzle[i] > puzzle[j]) {
          inversions++;
        }
      }
    }
    // For a 3x3 puzzle, it's solvable if inversions count is even
    return inversions % 2 === 0;
  };
  
  const canMoveTile = (tileIndex: number) => {
    const emptyIndex = tiles.indexOf(0);
    // Check if tile is adjacent to empty space (horizontally or vertically)
    const row = Math.floor(tileIndex / 3);
    const col = tileIndex % 3;
    const emptyRow = Math.floor(emptyIndex / 3);
    const emptyCol = emptyIndex % 3;
    
    return (
      (row === emptyRow && Math.abs(col - emptyCol) === 1) ||
      (col === emptyCol && Math.abs(row - emptyRow) === 1)
    );
  };
  
  const moveTile = (tile: number) => {
    if (isWon) return;
    
    const tileIndex = tiles.indexOf(tile);
    if (canMoveTile(tileIndex)) {
      const newTiles = [...tiles];
      const emptyIndex = newTiles.indexOf(0);
      
      // Swap the tile with the empty space
      newTiles[emptyIndex] = tile;
      newTiles[tileIndex] = 0;
      
      setTiles(newTiles);
      
      // Check if puzzle is solved
      const solved = newTiles.every((t, i) => t === (i + 1) % 9);
      if (solved) {
        setIsWon(true);
        toast.success("Puzzle solved! 🎉");
      }
    }
  };

  return (
    <Card className="glass-card w-full">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg flex items-center justify-between">
          <div className="flex items-center">
            <PiggyBank className="mr-2 h-5 w-5 text-wealthsync-primary" />
            Quick Tools
          </div>
          <Button variant="outline" size="sm" className="h-8 w-8 p-0" onClick={toggleCustomization}>
            <Settings className="h-4 w-4" />
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent className="p-3">
        <Tabs
          defaultValue={activeTab}
          onValueChange={setActiveTab}
          className="w-full"
        >
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="calculator" className="text-xs">
              <Calculator className="h-3 w-3 mr-1" /> Calc
            </TabsTrigger>
            <TabsTrigger value="notes" className="text-xs">
              <StickyNote className="h-3 w-3 mr-1" /> Notes
            </TabsTrigger>
            <TabsTrigger value="currency" className="text-xs">
              <Currency className="h-3 w-3 mr-1" /> Convert
            </TabsTrigger>
            <TabsTrigger value="puzzle" className="text-xs">
              <Pencil className="h-3 w-3 mr-1" /> Puzzle
            </TabsTrigger>
          </TabsList>

          <TabsContent value="calculator" className="mt-2 min-h-[250px]">
            <div className="bg-muted/30 rounded-lg p-2 mb-2 h-12 flex flex-col items-end justify-center overflow-hidden">
              <div className="text-xs text-muted-foreground truncate w-full text-right">{calcInput || "0"}</div>
              <div className="text-lg font-medium truncate w-full text-right">{calcResult || "0"}</div>
            </div>
            
            <div className="grid grid-cols-4 gap-1">
              {calculatorButtons.map((row, rowIndex) => 
                row.map((btn, btnIndex) => (
                  <motion.button
                    key={`${rowIndex}-${btnIndex}`}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => handleCalcButtonClick(btn)}
                    className={`rounded p-2 text-center transition-colors ${
                      btn === '=' ? 'bg-wealthsync-primary text-white hover:bg-wealthsync-primary/90' : 
                      btn === 'C' ? 'bg-red-500/20 hover:bg-red-500/30 text-red-500' :
                      btn === 'AC' ? 'bg-amber-500/20 hover:bg-amber-500/30 text-amber-500' :
                      ['/', '*', '-', '+', '(', ')', '.'].includes(btn) ? 
                        'bg-blue-500/20 hover:bg-blue-500/30 text-blue-500' :
                        'bg-muted/30 hover:bg-muted/50'
                    }`}
                  >
                    {btn}
                  </motion.button>
                ))
              )}
            </div>
          </TabsContent>

          <TabsContent value="notes" className="mt-2 min-h-[250px]">
            <div className="space-y-3">
              <textarea
                value={note}
                onChange={(e) => setNote(e.target.value)}
                className="w-full h-32 rounded-lg p-2 bg-yellow-50 dark:bg-yellow-900 border border-yellow-200 dark:border-yellow-700 resize-none text-yellow-900 dark:text-yellow-50 placeholder:text-yellow-500 dark:placeholder:text-yellow-300"
                placeholder="Write your note here..."
              />
              <motion.button
                whileTap={{ scale: 0.95 }}
                onClick={handleSaveNote}
                className="w-full p-2 rounded-lg bg-yellow-400 hover:bg-yellow-500 dark:bg-yellow-600 dark:hover:bg-yellow-700 text-yellow-900 dark:text-yellow-50 font-medium"
              >
                Save Note
              </motion.button>
              
              <div className="space-y-2 mt-4">
                {savedNotes.map((savedNote, index) => (
                  <div key={index} className="p-3 rounded-md bg-yellow-50 dark:bg-yellow-900 border border-yellow-200 dark:border-yellow-700 relative">
                    <p className="pr-6 text-yellow-900 dark:text-yellow-50">{savedNote}</p>
                    <button 
                      className="absolute top-2 right-2 text-yellow-500 hover:text-red-500 dark:text-yellow-400 dark:hover:text-red-400"
                      onClick={() => handleDeleteNote(index)}
                    >
                      ×
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="currency" className="mt-2 min-h-[250px]">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="amount">Amount</Label>
                <Input
                  id="amount"
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="Enter amount"
                  className="bg-muted/30"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="from-currency">From</Label>
                  <Select 
                    value={fromCurrency} 
                    onValueChange={setFromCurrency}
                  >
                    <SelectTrigger id="from-currency" className="bg-muted/30">
                      <SelectValue placeholder="Select currency" />
                    </SelectTrigger>
                    <SelectContent>
                      {availableCurrencies.map((currency) => (
                        <SelectItem key={currency.code} value={currency.code}>
                          {currency.code} - {currency.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="to-currency">To</Label>
                  <Select 
                    value={toCurrency} 
                    onValueChange={setToCurrency}
                  >
                    <SelectTrigger id="to-currency" className="bg-muted/30">
                      <SelectValue placeholder="Select currency" />
                    </SelectTrigger>
                    <SelectContent>
                      {availableCurrencies.map((currency) => (
                        <SelectItem key={currency.code} value={currency.code}>
                          {currency.code} - {currency.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="space-y-2">
                <Button 
                  onClick={handleConvert} 
                  className="w-full bg-wealthsync-primary hover:bg-wealthsync-primary/90"
                >
                  Convert
                </Button>
                
                {convertedAmount !== null && (
                  <div className="p-4 mt-3 bg-muted/30 rounded-lg text-center">
                    <p className="text-sm text-muted-foreground">Exchange Rate: 1 {fromCurrency} = {(exchangeRates[toCurrency] / exchangeRates[fromCurrency]).toFixed(4)} {toCurrency}</p>
                    <p className="text-xl font-bold mt-1">
                      {amount} {fromCurrency} = {convertedAmount} {toCurrency}
                    </p>
                  </div>
                )}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="puzzle" className="mt-2 min-h-[250px]">
            <div className="space-y-4">
              <div className="grid grid-cols-3 gap-1 aspect-square">
                {tiles.map((tile, index) => (
                  <motion.button
                    key={index}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => tile !== 0 && moveTile(tile)}
                    className={`${
                      tile === 0 
                        ? 'bg-transparent cursor-default' 
                        : canMoveTile(index) && !isWon
                          ? 'bg-wealthsync-primary/80 hover:bg-wealthsync-primary text-white cursor-pointer'
                          : 'bg-wealthsync-primary/50 text-white cursor-not-allowed'
                    } rounded-md flex items-center justify-center text-xl font-bold aspect-square transition-colors`}
                    disabled={tile === 0 || !canMoveTile(index) || isWon}
                  >
                    {tile !== 0 && tile}
                  </motion.button>
                ))}
              </div>
              
              <Button 
                onClick={initializePuzzle} 
                className="w-full"
                variant="outline"
              >
                New Game
              </Button>
              
              {isWon && (
                <div className="p-3 bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-100 rounded-lg text-center font-medium">
                  Congratulations! You solved the puzzle! 🎉
                </div>
              )}
              
              <p className="text-xs text-muted-foreground text-center">
                Slide the numbered tiles to put them in order from 1-8.
              </p>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default QuickTools;
