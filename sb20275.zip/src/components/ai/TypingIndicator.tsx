
import React from 'react';

const TypingIndicator: React.FC = () => {
  return (
    <div className="flex justify-start mb-4">
      <div className="flex flex-row max-w-[80%]">
        <div className="flex-shrink-0">
          <div className="h-8 w-8 rounded-full bg-wealthsync-secondary flex items-center justify-center text-white">
            AI
          </div>
        </div>
        
        <div className="px-4 py-3 rounded-2xl max-w-md mx-2 bg-wealthsync-card text-wealthsync-text rounded-tl-none">
          <div className="flex space-x-1">
            <div className="w-2 h-2 rounded-full bg-gray-400 animate-[bounce_0.8s_infinite_0s]"></div>
            <div className="w-2 h-2 rounded-full bg-gray-400 animate-[bounce_0.8s_infinite_0.2s]"></div>
            <div className="w-2 h-2 rounded-full bg-gray-400 animate-[bounce_0.8s_infinite_0.4s]"></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TypingIndicator;
