
import React from 'react';
import { ChatMessage as ChatMessageType } from '@/types';
import { Avatar } from '@/components/ui/avatar';

interface ChatMessageProps {
  message: ChatMessageType;
}

const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const isAI = message.role === 'assistant';
  
  return (
    <div className={`flex ${isAI ? 'justify-start' : 'justify-end'} mb-4 animate-fade-in`}>
      <div className={`flex ${isAI ? 'flex-row' : 'flex-row-reverse'} max-w-[80%]`}>
        <div className="flex-shrink-0">
          {isAI ? (
            <div className="h-8 w-8 rounded-full bg-wealthsync-secondary flex items-center justify-center text-white">
              AI
            </div>
          ) : (
            <div className="h-8 w-8 rounded-full bg-wealthsync-primary flex items-center justify-center text-white">
              U
            </div>
          )}
        </div>
        
        <div 
          className={`px-4 py-3 rounded-2xl max-w-md mx-2 ${
            isAI 
              ? 'bg-wealthsync-card text-wealthsync-text rounded-tl-none' 
              : 'bg-wealthsync-primary text-white rounded-tr-none'
          }`}
        >
          <p className="whitespace-pre-wrap">{message.content}</p>
        </div>
      </div>
    </div>
  );
};

export default ChatMessage;
