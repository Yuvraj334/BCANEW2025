
import React, { useState } from 'react';
import { Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';

interface ChatInputProps {
  onSendMessage: (message: string) => void;
  disabled?: boolean;
}

const ChatInput: React.FC<ChatInputProps> = ({
  onSendMessage,
  disabled = false,
}) => {
  const [message, setMessage] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim() && !disabled) {
      onSendMessage(message);
      setMessage('');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="relative">
      <Textarea
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        placeholder="Ask me anything about your finances..."
        className="pr-12 bg-wealthsync-dark border-gray-700 text-wealthsync-text focus-visible:ring-wealthsync-secondary resize-none"
        rows={2}
        disabled={disabled}
        onKeyDown={(e) => {
          if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSubmit(e);
          }
        }}
      />
      <Button
        type="submit"
        size="icon"
        disabled={!message.trim() || disabled}
        className={`absolute bottom-2 right-2 rounded-full ${
          message.trim() && !disabled
            ? 'bg-wealthsync-secondary hover:bg-wealthsync-secondary/90'
            : 'bg-gray-600'
        }`}
      >
        <Send size={18} className="text-white" />
      </Button>
    </form>
  );
};

export default ChatInput;
