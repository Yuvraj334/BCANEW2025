
import React from 'react';
import { Button } from '@/components/ui/button';

interface SuggestedQuestionsProps {
  questions: string[];
  onSelect: (question: string) => void;
}

const SuggestedQuestions: React.FC<SuggestedQuestionsProps> = ({
  questions,
  onSelect,
}) => {
  return (
    <div className="mt-4 mb-4">
      <p className="text-sm text-wealthsync-dimtext mb-2">Suggested questions:</p>
      <div className="flex flex-wrap gap-2">
        {questions.map((question, index) => (
          <Button 
            key={index}
            variant="outline"
            size="sm"
            onClick={() => onSelect(question)}
            className="text-sm border-gray-700 bg-wealthsync-dark text-wealthsync-text hover:bg-wealthsync-card hover:border-wealthsync-secondary"
          >
            {question}
          </Button>
        ))}
      </div>
    </div>
  );
};

export default SuggestedQuestions;
