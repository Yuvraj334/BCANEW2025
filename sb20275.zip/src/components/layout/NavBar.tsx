import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  Settings, 
  Bell, 
  Search, 
  Menu,
  Sun,
  Moon,
  Home,
  CreditCard,
  History,
  LineChart,
  Bot,
  HelpCircle,
  User,
  X,
  LogOut,
  Award,
  Palette,
  Download,
  Languages,
  Coins,
  Wallet,
  Banknote,
  MessageSquareQuote
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';
import { useTheme } from '@/contexts/ThemeContext';
import { toast } from 'sonner';
import { HeartToggle } from '@/components/ui/heart-toggle';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { motion } from 'framer-motion';
import { Box } from 'lucide-react';

const NavBar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearch, setShowSearch] = useState(false);
  const location = useLocation();
  const { mode, colorTheme, toggleMode, toggleCustomization } = useTheme();

  // Assuming the user data is stored in localStorage or context
  const user = JSON.parse(localStorage.getItem('wealthsync-user') || '{}');
  const userInitials = user?.firstName?.[0] + user?.lastName?.[0] || "YR"; // Default initials if none exist

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { name: 'Dashboard', path: '/', icon: <Home size={18} /> },
    { name: '3D Model', path: '/3d-model', icon: <Box size={18} /> },
    { name: 'Expenses', path: '/expenses', icon: <CreditCard size={18} /> },
    { name: 'History', path: '/history', icon: <History size={18} /> },
    { name: 'Insights', path: '/insights', icon: <LineChart size={18} /> },
    { name: 'AI Assistant', path: '/ai-assistant', icon: <Bot size={18} /> },
    { name: 'Testimonials', path: '/testimonials', icon: <MessageSquareQuote size={18} /> },
    { name: 'About', path: '/about', icon: <HelpCircle size={18} /> }
  ];

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    toast.info(`Searching for "${searchQuery}"...`);
    setSearchQuery('');
    setShowSearch(false);
  };

  const handleLogout = () => {
    toast.info("Logging out...");
    localStorage.removeItem('wealthsync-user');
    window.location.href = '/login';
  };

  const getLightModeStyles = () => {
    return mode === 'light' 
      ? "bg-wealthsync-light/80 backdrop-blur-md border-b border-wealthsync-dark/10" 
      : "bg-transparent";
  };

  return (
    <header className={cn(
      "fixed top-0 left-0 right-0 z-50 transition-all duration-300 py-3 px-4",
      isScrolled 
        ? `${mode === 'light' ? 'bg-wealthsync-light/80' : 'bg-background/80'} backdrop-blur-md border-b` 
        : `${mode === 'light' ? 'bg-wealthsync-light/50' : 'bg-transparent'}`,
      "rounded-b-3xl border-b border-accent/20 glass-morphism"
    )}>
      <div className="container mx-auto">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-x-2">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
                    <Menu />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Menu</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            
            <Link to="/" className="flex items-center">
              <motion.span 
                className="text-2xl font-bold tracking-tight"
                animate={{ 
                  backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"],
                }}
                transition={{ 
                  duration: 8,
                  repeat: Infinity,
                  ease: "linear"
                }}
                style={{
                  backgroundImage: mode === 'light' 
                    ? "linear-gradient(90deg, #575757, #7A7A7A, #575757)" 
                    : "linear-gradient(90deg, #f5a623, #f97316, #e11d48, #8b5cf6, #06b6d4, #f5a623)",
                  backgroundSize: "300% 100%",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                }}
              >
                WealthSync
              </motion.span>
            </Link>
          </div>
          
          <nav className="hidden md:flex items-center space-x-1">
            {navItems.map((item) => (
              <Link 
                key={item.path} 
                to={item.path}
                className={cn(
                  "px-3 py-2 rounded-md text-sm font-medium transition-colors flex items-center gap-2",
                  location.pathname === item.path
                    ? `${mode === 'light' ? 'text-wealthsync-dark bg-wealthsync-dark/10' : 'text-primary bg-primary/10'}`
                    : `${mode === 'light' ? 'text-wealthsync-dark/70 hover:text-wealthsync-dark hover:bg-wealthsync-dark/5' : 'text-muted-foreground hover:text-primary hover:bg-primary/5'}`
                )}
              >
                {item.icon}
                {item.name}
              </Link>
            ))}
          </nav>
          
          <div className="flex items-center gap-x-2">
            {showSearch ? (
              <form onSubmit={handleSearch} className="animate-fade-in">
                <Input
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-[200px] h-9"
                  placeholder="Search..."
                  autoFocus
                  onBlur={() => !searchQuery && setShowSearch(false)}
                />
              </form>
            ) : (
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className={`${mode === 'light' ? 'text-wealthsync-dark/70 hover:text-wealthsync-dark' : 'text-muted-foreground hover:text-primary'}`}
                      onClick={() => setShowSearch(true)}
                    >
                      <Search size={20} />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Search</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            )}
            
            <DropdownMenu>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <DropdownMenuTrigger asChild>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className={`${mode === 'light' ? 'text-wealthsync-dark/70 hover:text-wealthsync-dark' : 'text-muted-foreground hover:text-primary'}`}
                      >
                        <Bell size={20} />
                        <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
                      </Button>
                    </DropdownMenuTrigger>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Notifications</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
              
              <DropdownMenuContent align="end" className="w-80">
                <DropdownMenuLabel>Notifications</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <ScrollArea className="h-80">
                  <div className="space-y-2 p-2">
                    {/* Notification Content */}
                  </div>
                </ScrollArea>
                <DropdownMenuSeparator />
                <div className="p-2">
                  <Button variant="outline" size="sm" className="w-full">
                    Mark all as read
                  </Button>
                </div>
              </DropdownMenuContent>
            </DropdownMenu>
            
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <div className="flex items-center">
                    <HeartToggle 
                      checked={mode === 'dark'} 
                      onCheckedChange={() => toggleMode()}
                      size="sm"
                    />
                  </div>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Toggle Theme</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className={`rounded-full ${mode === 'light' ? 'bg-wealthsync-dark/10 border border-wealthsync-dark/20' : 'glass-card border border-gray-700/50'} hover:border-wealthsync-primary/50 transition-colors`}
                >
                  <span className="sr-only">Profile</span>
                  <span className="text-xs font-medium">
                    {userInitials} {/* Default initials if not available */}
                  </span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>User Profile</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => handleLogout()}>
                  <LogOut size={16} className="mr-2" />
                  Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
    </header>
  );
};

export default NavBar;
