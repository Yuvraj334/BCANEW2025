import React, { useEffect, useState } from 'react';
import { useTheme } from '@/contexts/ThemeContext';

const quotes = [
  "Track your expenses, control your future.",
  "Financial freedom begins with financial awareness.",
  "Saving a little each day adds up over time.",
  "Budget wisely today for a secure tomorrow.",
  "Your financial goals are achievable with proper planning.",
  "Build wealth through consistent habits.",
  "Make your money work for you.",
  "Smart spending leads to great saving.",
  "Financial security is a journey, not a destination.",
  "Small changes in spending lead to big changes in savings."
];

const SplashScreen = ({ onFinished }: { onFinished: () => void }) => {
  const { mode } = useTheme();
  const [loadingProgress, setLoadingProgress] = useState(0);
  const [currentQuote, setCurrentQuote] = useState(quotes[0]);
  const [quoteIndex, setQuoteIndex] = useState(0);

  // Handle loading progress
  useEffect(() => {
    const interval = setInterval(() => {
      setLoadingProgress(prev => {
        const newProgress = prev + (Math.random() * 5 + 2);
        if (newProgress >= 100) {
          clearInterval(interval);
          setTimeout(() => onFinished(), 500);
          return 100;
        }
        return newProgress;
      });
    }, 150);

    return () => clearInterval(interval);
  }, [onFinished]);

  // Rotate quotes
  useEffect(() => {
    const interval = setInterval(() => {
      setQuoteIndex(prev => {
        const next = (prev + 1) % quotes.length;
        setCurrentQuote(quotes[next]);
        return next;
      });
    }, 10000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className={`fixed inset-0 z-50 flex flex-col items-center justify-center ${mode === 'dark' ? 'bg-wealthsync-dark' : 'bg-white'}`}>
      <div className="relative flex flex-col items-center">
        {/* Logo Animation */}
        <div className="mb-8 relative">
          <div className="relative z-10 animate-fade-in">
            <div className="flex items-center justify-center h-24 w-24 bg-wealthsync-primary rounded-full">
              <div className="text-4xl font-bold text-white animation-delay-300 animate-fade-in">
                WS
              </div>
            </div>
          </div>

          <div className="absolute inset-0 bg-wealthsync-primary rounded-full opacity-20 animate-pulse filter blur-xl scale-150" />
          <div className="absolute inset-0 bg-wealthsync-secondary rounded-full opacity-30 animate-pulse filter blur-lg scale-125" />
        </div>

        {/* App Name */}
        <div className="mb-8 text-center animate-fade-in">
          <h1 className="text-3xl md:text-4xl font-bold">
            <span className="text-wealthsync-primary animate-pulse">Wealth</span>
            <span className={mode === 'dark' ? 'text-white' : 'text-gray-800'}>Sync</span>
          </h1>
          <p className={`mt-2 ${mode === 'dark' ? 'text-gray-400' : 'text-gray-600'} animate-fade-in animation-delay-600`}>
            {currentQuote}
          </p>
        </div>

        {/* Loading Indicator */}
        <div className="w-64 h-1 bg-gray-700 rounded-full mb-4 overflow-hidden">
          <div
            className="h-full bg-wealthsync-primary rounded-full transition-all duration-300"
            style={{ width: `${loadingProgress}%` }}
          />
        </div>

        {/* Loading Text */}
        <div className={`text-sm ${mode === 'dark' ? 'text-gray-400' : 'text-gray-600'} animate-fade-in animation-delay-900`}>
          <span className="mr-2">Loading</span>
          <span className="animate-pulse">...</span>
        </div>

        {/* Currency Symbols Animation */}
        <div className="absolute -z-10 inset-0 w-full h-full overflow-hidden pointer-events-none">
          {['₹', '$', '€', '£', '¥'].flatMap((symbol, i) =>
            Array.from({ length: 3 }, (_, j) => {
              const left = `${Math.random() * 100}%`;
              const top = `${Math.random() * 100}%`;
              const animationDelay = `${Math.random() * 5}s`;
              const animationDuration = `${5 + Math.random() * 10}s`;

              return (
                <div
                  key={`${symbol}-${j}`}
                  className={`absolute text-2xl ${mode === 'dark' ? 'text-gray-700' : 'text-gray-200'} animate-float`}
                  style={{
                    left,
                    top,
                    animationDelay,
                    animationDuration,
                    opacity: 0.3,
                  }}
                >
                  {symbol}
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};

export default SplashScreen;
