
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { availableCurrencies } from '@/utils/currency';
import { useTheme } from '@/contexts/ThemeContext';
import { Moon, Sun, Check, Sliders, Sparkles, Palette, Globe, TextQuote, Zap } from 'lucide-react';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { HoverCard, HoverCardContent, HoverCardTrigger } from '@/components/ui/hover-card';
import { motion } from 'framer-motion';

const CustomizationDialog = () => {
  const { 
    mode, 
    colorTheme, 
    currency, 
    toggleMode, 
    setColorTheme, 
    setCurrency,
    isCustomizationOpen,
    toggleCustomization,
    fontSize,
    setFontSize,
    animationSpeed,
    setAnimationSpeed,
  } = useTheme();

  const colorThemes = [
    { id: 'blush-rose', label: 'Blush Rose', colors: ['#F7D5DC', '#4B2C35'] },
    { id: 'deep-plum', label: 'Deep Plum', colors: ['#291A40', '#9b87f5'] },
    { id: 'midnight', label: 'Midnight', colors: ['#1F2F33', '#A3B4C4'] },
    { id: 'mahogany', label: 'Mahogany', colors: ['#1E1211', '#B2A39D'] },
    { id: 'olive', label: 'Olive', colors: ['#3D4D25', '#C8D4AB'] },
    { id: 'sand', label: 'Sand', colors: ['#D8C9AE', '#575757'] },
    { id: 'slate', label: 'Slate Teal', colors: ['#1F2F33', '#A3B4C4'] },
    { id: 'neutral', label: 'Neutral', colors: ['#B6B6B6', '#808080'] },
    { id: 'frost-blue', label: 'Frost Blue', colors: ['#A3B4C4', '#1F2F33'] },
    { id: 'warm-taupe', label: 'Warm Taupe', colors: ['#B2A39D', '#1E1211'] },
    { id: 'emerald', label: 'Emerald', colors: ['#1E3932', '#4CAF50'] },
    { id: 'azure', label: 'Azure', colors: ['#1A237E', '#64B5F6'] },
    { id: 'sunset', label: 'Sunset', colors: ['#FF7043', '#FFB74D'] },
    { id: 'lavender', label: 'Lavender', colors: ['#5E35B1', '#D1C4E9'] },
    { id: 'coral', label: 'Coral', colors: ['#FF5722', '#FFAB91'] },
    { id: 'teal', label: 'Teal', colors: ['#004D40', '#4DB6AC'] }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { staggerChildren: 0.05 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <Dialog open={isCustomizationOpen} onOpenChange={toggleCustomization}>
      <DialogContent className="max-w-2xl bg-card border-gray-700">
        <DialogHeader>
          <DialogTitle className="text-2xl flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-primary" />
            Personalize Your Experience
          </DialogTitle>
          <DialogDescription>
            Customize colors, appearance, and preferences
          </DialogDescription>
        </DialogHeader>
        
        <Tabs defaultValue="themes" className="mt-4">
          <TabsList className="w-full grid grid-cols-3 mb-4">
            <TabsTrigger value="themes" className="flex items-center gap-1">
              <Palette className="h-4 w-4" /> Themes
            </TabsTrigger>
            <TabsTrigger value="display" className="flex items-center gap-1">
              <TextQuote className="h-4 w-4" /> Display
            </TabsTrigger>
            <TabsTrigger value="preferences" className="flex items-center gap-1">
              <Sliders className="h-4 w-4" /> Preferences
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="themes" className="space-y-4">
            <div className="bg-muted/30 rounded-lg p-4 mb-4">
              <div className="font-medium mb-2">Preview</div>
              <div className="flex items-center">
                <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center mr-3">WS</div>
                <div>
                  <div>Theme: {mode === 'dark' ? 'Dark' : 'Light'}</div>
                  <div className="text-muted-foreground">Currency: {currency}</div>
                </div>
              </div>
            </div>
            
            <div className="space-y-4">
              <div>
                <div className="font-medium mb-2">Color Mode</div>
                <div className="flex gap-2">
                  <Button 
                    variant={mode === 'light' ? 'default' : 'outline'}
                    className="flex-1 gap-2"
                    onClick={() => toggleMode('light')}
                  >
                    <Sun size={18} />
                    Light
                  </Button>
                  <Button 
                    variant={mode === 'dark' ? 'default' : 'outline'}
                    className="flex-1 gap-2"
                    onClick={() => toggleMode('dark')}
                  >
                    <Moon size={18} />
                    Dark
                  </Button>
                </div>
              </div>
              
              <motion.div
                variants={containerVariants}
                initial="hidden"
                animate="visible"
              >
                <div className="font-medium mb-2">Color Themes</div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {colorThemes.map((theme) => (
                    <motion.div key={theme.id} variants={itemVariants}>
                      <HoverCard>
                        <HoverCardTrigger asChild>
                          <motion.button
                            className={`h-20 rounded-lg overflow-hidden transition hover:ring-2 hover:ring-primary ${
                              colorTheme === theme.id ? 'ring-2 ring-primary' : ''
                            }`}
                            onClick={() => setColorTheme(theme.id as any)}
                            whileHover={{ scale: 1.05 }}
                            whileTap={{ scale: 0.95 }}
                          >
                            <div className="h-full w-full relative">
                              <div className="absolute inset-0 right-1/2" style={{background: theme.colors[0]}}></div>
                              <div className="absolute inset-0 left-1/2" style={{background: theme.colors[1]}}></div>
                              <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/30">
                                <span className="text-white text-xs font-medium">{theme.label}</span>
                                {colorTheme === theme.id && <Check size={14} className="text-white mt-1" />}
                              </div>
                            </div>
                          </motion.button>
                        </HoverCardTrigger>
                        <HoverCardContent className="p-0 w-64">
                          <div className="p-2">
                            <div className="font-medium">{theme.label}</div>
                            <div className="text-xs text-muted-foreground">Click to apply this theme</div>
                          </div>
                          <div className="h-32 w-full relative">
                            <div className="absolute inset-0 right-1/2" style={{background: theme.colors[0]}}></div>
                            <div className="absolute inset-0 left-1/2" style={{background: theme.colors[1]}}></div>
                            <div className="absolute inset-0 flex items-center justify-center">
                              <div className="bg-card p-3 rounded-lg shadow-lg">
                                <div className="font-bold text-lg wealthsync-logo-text">WealthSync</div>
                              </div>
                            </div>
                          </div>
                        </HoverCardContent>
                      </HoverCard>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            </div>
          </TabsContent>
          
          <TabsContent value="display">
            <div className="space-y-6">
              <div>
                <div className="font-medium mb-2 flex items-center">
                  <Globe className="h-4 w-4 mr-2" /> Currency
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
                  {availableCurrencies.map((curr) => (
                    <Button 
                      key={curr.code}
                      variant={currency === curr.code ? 'default' : 'outline'} 
                      onClick={() => setCurrency(curr.code)}
                      className="h-auto py-2 justify-start"
                    >
                      <span className="mr-2">{curr.code}</span>
                      <span className="text-xs text-muted-foreground truncate">
                        {curr.name}
                      </span>
                    </Button>
                  ))}
                </div>
              </div>

              <div>
                <div className="font-medium mb-2 flex items-center">
                  <TextQuote className="h-4 w-4 mr-2" /> Font Size
                </div>
                <div className="flex items-center gap-4 mb-2">
                  <span className="text-sm">Small</span>
                  <Slider 
                    value={[fontSize]} 
                    max={100} 
                    step={10}
                    onValueChange={(value) => setFontSize(value[0])} 
                    className="flex-1" 
                  />
                  <span className="text-lg">Large</span>
                </div>
                <div className="bg-muted/30 rounded-lg p-3 mt-2">
                  <div className="text-center" style={{ fontSize: `${100 + (fontSize - 50) * 0.4}%` }}>
                    <p>Preview of your selected font size</p>
                    <p className="text-muted-foreground text-sm">This is how text will appear across the app</p>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="preferences">
            <div className="space-y-6">
              <div>
                <div className="font-medium mb-4 flex items-center">
                  <Zap className="h-4 w-4 mr-2" /> Animation Settings
                </div>
                <div className="flex items-center gap-4 mb-4">
                  <span className="text-sm">Slower</span>
                  <Slider 
                    value={[animationSpeed]} 
                    max={100} 
                    step={10}
                    onValueChange={(value) => setAnimationSpeed(value[0])} 
                    className="flex-1" 
                  />
                  <span className="text-sm">Faster</span>
                </div>

                <div className="space-y-3 mt-6">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="notifications">Enable Notifications</Label>
                    <Switch id="notifications" />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <Label htmlFor="sounds">Enable Sound Effects</Label>
                    <Switch id="sounds" />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <Label htmlFor="autobackup">Auto Backup Data</Label>
                    <Switch id="autobackup" defaultChecked />
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
        
        <div className="flex justify-end gap-2 mt-6">
          <Button variant="ghost" onClick={toggleCustomization}>Cancel</Button>
          <Button onClick={toggleCustomization}>Apply</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default CustomizationDialog;
