
import React, { useState } from 'react';
import { Transaction } from '@/types';
import { formatCurrency } from '@/utils/currency';
import { Plus, ChevronRight, Filter, MoreHorizontal, Edit, Trash2, List } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useTheme } from '@/contexts/ThemeContext';
import { motion, AnimatePresence } from 'framer-motion';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { toast } from 'sonner';

interface TransactionListProps {
  transactions: Transaction[];
  onAddTransaction: () => void;
}

const TransactionList: React.FC<TransactionListProps> = ({
  transactions,
  onAddTransaction,
}) => {
  const { currency } = useTheme();
  const [selectedTransaction, setSelectedTransaction] = useState<string | null>(null);
  
  const handleEdit = (id: string) => {
    toast.info("Edit transaction functionality coming soon!");
    setSelectedTransaction(null);
  };
  
  const handleDelete = (id: string) => {
    toast.success("Transaction deleted successfully!");
    setSelectedTransaction(null);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="glass-card p-6"
    >
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-2">
          <List className="text-wealthsync-dimtext" />
          <h2 className="text-lg font-semibold">Recent Transactions</h2>
        </div>
        
        <div className="flex space-x-2">
          <Button 
            variant="outline" 
            size="sm"
            className="text-wealthsync-dimtext border-gray-700 hover:border-wealthsync-primary"
          >
            <Filter size={16} className="mr-1" />
            Sort
          </Button>
          
          <Button
            onClick={onAddTransaction}
            size="sm"
            className="bg-wealthsync-primary hover:bg-wealthsync-primary/90 text-white"
          >
            <Plus size={16} className="mr-1" />
            Add Expense
          </Button>
        </div>
      </div>
      
      {transactions.length === 0 ? (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="flex flex-col items-center justify-center py-16 text-center"
        >
          <div className="rounded-full bg-muted/30 p-4 mb-3">
            <List size={32} className="text-wealthsync-dimtext" />
          </div>
          <p className="text-wealthsync-dimtext mb-2">No transactions in last 24 hours</p>
          <Button
            onClick={onAddTransaction}
            variant="outline"
            className="mt-4 border-gray-700 text-wealthsync-text hover:border-wealthsync-primary"
          >
            <Plus size={16} className="mr-1" />
            Add Your First Transaction
          </Button>
        </motion.div>
      ) : (
        <div className="space-y-4">
          <AnimatePresence>
            {transactions.map((transaction) => (
              <motion.div 
                key={transaction.id} 
                className={`flex items-center justify-between p-3 hover:bg-wealthsync-dark/50 rounded-md transition-colors relative ${
                  selectedTransaction === transaction.id ? 'bg-wealthsync-dark/50' : ''
                }`}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, x: -100 }}
                whileHover={{ scale: 1.01 }}
              >
                <div className="flex items-center space-x-4">
                  <div className={`w-10 h-10 rounded-full ${
                    transaction.type === 'expense' ? 'bg-red-500/20' : 'bg-green-500/20'
                  } flex items-center justify-center`}>
                    <span className={`text-lg ${
                      transaction.type === 'expense' ? 'text-red-500' : 'text-green-500'
                    }`}>
                      {transaction.category.charAt(0)}
                    </span>
                  </div>
                  
                  <div>
                    <h4 className="font-medium">{transaction.description}</h4>
                    <p className="text-sm text-wealthsync-dimtext">
                      {transaction.date instanceof Date 
                        ? transaction.date.toLocaleDateString() 
                        : new Date(transaction.date).toLocaleDateString()
                      }
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-3">
                  <div className={`font-semibold ${
                    transaction.type === 'expense' 
                      ? 'text-wealthsync-danger' 
                      : 'text-wealthsync-success'
                  }`}>
                    {transaction.type === 'expense' ? '-' : '+'}
                    {formatCurrency(transaction.amount, currency)}
                  </div>
                  
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" className="h-8 w-8 p-0">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuLabel>Transaction</DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem 
                        onClick={() => handleEdit(transaction.id)}
                        className="flex items-center"
                      >
                        <Edit className="mr-2 h-4 w-4" />
                        Edit
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        onClick={() => handleDelete(transaction.id)}
                        className="flex items-center text-red-500 focus:text-red-500"
                      >
                        <Trash2 className="mr-2 h-4 w-4" />
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}
    </motion.div>
  );
};

export default TransactionList;
