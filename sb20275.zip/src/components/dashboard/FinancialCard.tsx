
import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { TrendingDown, TrendingUp, Sparkles, Edit } from 'lucide-react';
import { formatCurrency } from '@/utils/currency';
import { useTheme } from '@/contexts/ThemeContext';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

interface FinancialCardProps {
  title: string;
  amount: number;
  change: number;
  timePeriod: 'day' | 'week' | 'month' | 'year';
  type: 'income' | 'expense' | 'balance';
  onEdit?: () => void;
  className?: string;
}

const FinancialCard = ({
  title,
  amount,
  change,
  timePeriod,
  type,
  onEdit,
}: FinancialCardProps) => {
  const { mode, colorTheme, currency } = useTheme();
  const [hovered, setHovered] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [newAmount, setNewAmount] = useState(amount);
  
  const getBgColor = () => {
    if (type === 'income') return 'from-green-500/10 to-green-600/5';
    if (type === 'expense') return 'from-red-500/10 to-red-600/5';
    return 'from-blue-500/10 to-blue-600/5';
  };
  
  const getIcon = () => {
    if (type === 'income') return <TrendingUp className="text-green-500" />;
    if (type === 'expense') return <TrendingDown className="text-red-500" />;
    return <TrendingUp className="text-blue-500" />;
  };
  
  const getChangeColor = () => {
    if (type === 'income') {
      return change >= 0 ? 'text-green-500' : 'text-red-500';
    } 
    if (type === 'expense') {
      return change >= 0 ? 'text-red-500' : 'text-green-500';
    }
    return change >= 0 ? 'text-green-500' : 'text-red-500';
  };

  const handleEditClick = () => {
    setNewAmount(amount);
    setShowConfirmation(true);
  };

  const handleConfirmEdit = () => {
    setShowConfirmation(false);
    if (onEdit) onEdit();
    
    toast.success(`${title} will be updated to ${formatCurrency(newAmount, currency)}`, {
      description: "Your financial information has been updated."
    });
  };

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        whileHover={{ scale: 1.02 }}
        onHoverStart={() => setHovered(true)}
        onHoverEnd={() => setHovered(false)}
      >
        <Card 
          className={`relative overflow-hidden bg-gradient-to-br ${getBgColor()} transition-all duration-500 hover:shadow-lg border border-wealthsync-primary/10 ${mode === 'dark' ? 'bg-black text-white' : 'bg-white text-black'} ${colorTheme}`}
        >
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <h3 className="text-sm font-medium text-muted-foreground mb-1">{title}</h3>
              {onEdit && (
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className={`h-6 w-6 rounded-full ${hovered ? 'opacity-100' : 'opacity-0'} transition-opacity`}
                  onClick={handleEditClick}
                >
                  <Edit className="h-3 w-3" />
                </Button>
              )}
            </div>
            
            <div className="relative">
              <div className="text-3xl font-bold mb-1">
                {formatCurrency(amount, currency)}
              </div>
              
              {/* Sparkle effect when hovered */}
              <AnimatedSparkles visible={hovered} />
            </div>
            
            <div className={`flex items-center text-sm ${getChangeColor()}`}>
              <motion.div animate={hovered ? { rotate: [0, 15, 0] } : {}}>
                {getIcon()}
              </motion.div>
              <span className="ml-1">
                {change >= 0 ? '+' : ''}
                {change}% from last {timePeriod}
              </span>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      <AlertDialog open={showConfirmation} onOpenChange={setShowConfirmation}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Edit {title}</AlertDialogTitle>
            <AlertDialogDescription>
              Enter the new {type === 'income' ? 'income' : 'expense'} amount. 
              This will change your overall financial balance.
            </AlertDialogDescription>
          </AlertDialogHeader>
          
          <div className="py-4">
            <Label htmlFor="new-amount">New Amount</Label>
            <Input 
              id="new-amount"
              type="number"
              value={newAmount}
              onChange={(e) => setNewAmount(Number(e.target.value))}
              className="mt-2"
            />
          </div>
          
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleConfirmEdit}>Update</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

// Animated sparkles component
const AnimatedSparkles = ({ visible }: { visible: boolean }) => {
  return (
    <motion.div 
      className="absolute inset-0 pointer-events-none"
      initial="hidden"
      animate={visible ? "visible" : "hidden"}
      variants={{
        visible: { opacity: 1 },
        hidden: { opacity: 0 }
      }}
    >
      <motion.div 
        className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"
        animate={{ 
          scale: [1, 1.2, 1], 
          opacity: [0.5, 0.8, 0.5],
        }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        <div className="w-40 h-40 rounded-full bg-gradient-radial from-white/20 to-transparent"></div>
      </motion.div>
      
      {[...Array(3)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute"
          initial={{ x: `${Math.random() * 100}%`, y: `${Math.random() * 100}%` }}
          animate={{
            x: [`${Math.random() * 100}%`, `${Math.random() * 100}%`],
            y: [`${Math.random() * 100}%`, `${Math.random() * 100}%`],
            opacity: [0.7, 0.1, 0.7]
          }}
          transition={{ duration: 3 + i, repeat: Infinity, repeatType: "reverse" }}
        >
          <Sparkles className="h-3 w-3 text-yellow-400" />
        </motion.div>
      ))}
    </motion.div>
  );
};

export default FinancialCard;
