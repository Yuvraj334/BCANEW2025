
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Bell, PlusCircle, Calendar, Edit, Trash2, Check, AlertCircle, Clock, Settings } from 'lucide-react';
import { BillReminder } from '@/types';
import { formatCurrency } from '@/utils/currency';
import { useTheme } from '@/contexts/ThemeContext';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

interface BillReminderCardProps {
  bills: BillReminder[];
  onAddBill?: () => void;
}

const BillReminderCard = ({ bills, onAddBill }: BillReminderCardProps) => {
  const { mode, currency, updateBill } = useTheme();
  const [selectedBill, setSelectedBill] = useState<string | null>(null);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [currentBill, setCurrentBill] = useState<BillReminder | null>(null);
  const [editedName, setEditedName] = useState('');
  const [editedAmount, setEditedAmount] = useState('');
  const [editedDate, setEditedDate] = useState('');
  
  // Get upcoming bills (not paid, closest due date first)
  const upcomingBills = [...bills]
    .filter(bill => !bill.isPaid)
    .sort((a, b) => a.dueDate.getTime() - b.dueDate.getTime())
    .slice(0, 3);
    
  // Calculate days until due
  const getDaysUntil = (date: Date): number => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const dueDate = new Date(date);
    dueDate.setHours(0, 0, 0, 0);
    const diffTime = dueDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const getBillStatus = (daysUntil: number) => {
    if (daysUntil < 0) return { status: 'Overdue', color: 'text-red-500', bgColor: 'bg-red-500/20', badgeColor: 'bg-red-500 hover:bg-red-600' };
    if (daysUntil === 0) return { status: 'Due Today', color: 'text-orange-500', bgColor: 'bg-orange-500/20', badgeColor: 'bg-orange-500 hover:bg-orange-600' };
    if (daysUntil <= 3) return { status: 'Upcoming', color: 'text-amber-500', bgColor: 'bg-amber-500/20', badgeColor: 'bg-amber-500 hover:bg-amber-600' };
    return { status: 'Scheduled', color: 'text-wealthsync-secondary', bgColor: 'bg-wealthsync-secondary/20', badgeColor: 'bg-blue-500 hover:bg-blue-600' };
  };

  // Check for due bills and show notifications
  useEffect(() => {
    const todaysDueBills = bills.filter(bill => {
      const daysUntil = getDaysUntil(bill.dueDate);
      return daysUntil === 0 && !bill.isPaid;
    });
    
    const overdueBills = bills.filter(bill => {
      const daysUntil = getDaysUntil(bill.dueDate);
      return daysUntil < 0 && !bill.isPaid;
    });
    
    if (todaysDueBills.length > 0) {
      setTimeout(() => {
        toast.warning(`You have ${todaysDueBills.length} bill(s) due today!`, {
          icon: <AlertCircle className="h-4 w-4" />,
          duration: 5000,
          action: {
            label: "View",
            onClick: () => console.log("View bills")
          },
        });
      }, 2000);
    }
    
    if (overdueBills.length > 0) {
      setTimeout(() => {
        toast.error(`You have ${overdueBills.length} overdue bill(s)!`, {
          icon: <AlertCircle className="h-4 w-4" />,
          duration: 5000,
          action: {
            label: "Pay Now",
            onClick: () => console.log("Pay bills")
          },
        });
      }, 3500);
    }
  }, [bills]);

  const handleMarkPaid = (id: string) => {
    // This would update through the finance context in a real implementation
    toast.success("Bill marked as paid!");
    setSelectedBill(null);
  };

  const handleEdit = (bill: BillReminder) => {
    setCurrentBill(bill);
    setEditedName(bill.name);
    setEditedAmount(bill.amount.toString());
    setEditedDate(bill.dueDate.toISOString().split('T')[0]);
    setShowEditDialog(true);
    setSelectedBill(null);
  };

  const handleDelete = (id: string) => {
    toast.success("Bill removed successfully!");
    setSelectedBill(null);
  };

  const handleSaveEdit = () => {
    if (!currentBill) return;
    
    // Validate inputs
    if (!editedName.trim()) {
      toast.error("Please provide a bill name");
      return;
    }
    
    const amount = parseFloat(editedAmount);
    if (isNaN(amount) || amount <= 0) {
      toast.error("Please provide a valid amount");
      return;
    }
    
    if (!editedDate) {
      toast.error("Please select a due date");
      return;
    }
    
    // Update bill
    updateBill(currentBill.id, {
      name: editedName,
      amount: amount,
      dueDate: new Date(editedDate)
    });
    
    toast.success("Bill updated successfully!");
    setShowEditDialog(false);
  };

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
        className="group"
        whileHover={{ scale: 1.01 }}
      >
        <Card className="glass-card relative overflow-hidden">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div className="flex items-center space-x-2">
              <Bell className="h-5 w-5 text-wealthsync-primary" />
              <CardTitle className="text-lg">Bill Reminders</CardTitle>
            </div>
            <div className="flex space-x-1">
              <Button 
                variant="ghost" 
                size="icon"
                className="text-wealthsync-dimtext hover:text-wealthsync-primary"
                onClick={() => console.log("Settings")}
              >
                <Settings className="h-4 w-4" />
              </Button>
              <Button 
                variant="ghost" 
                size="icon"
                className="text-wealthsync-dimtext hover:text-wealthsync-primary"
                onClick={onAddBill}
              >
                <PlusCircle className="h-4 w-4" />
              </Button>
            </div>
          </CardHeader>
          
          {/* Animated background elements */}
          <div className="absolute -right-8 -top-8 w-32 h-32 bg-blue-500/5 rounded-full filter blur-xl"></div>
          <div className="absolute -left-8 -bottom-8 w-32 h-32 bg-purple-500/5 rounded-full filter blur-xl"></div>
          
          <CardContent>
            {upcomingBills.length === 0 ? (
              <div className="flex flex-col items-center py-6 text-center">
                <motion.div
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ duration: 0.5 }}
                >
                  <Calendar className="h-12 w-12 text-wealthsync-dimtext mb-2" />
                </motion.div>
                <CardDescription className="text-center">
                  No upcoming bills
                </CardDescription>
                <Button 
                  variant="link" 
                  className="mt-2 text-wealthsync-primary"
                  onClick={onAddBill}
                >
                  Add your first bill
                </Button>
              </div>
            ) : (
              <div className="space-y-3">
                {upcomingBills.map(bill => {
                  const daysUntil = getDaysUntil(bill.dueDate);
                  const { status, color, bgColor, badgeColor } = getBillStatus(daysUntil);
                  
                  return (
                    <motion.div 
                      key={bill.id} 
                      className={`p-3 rounded-lg ${mode === "dark" 
                        ? "bg-wealthsync-dark/70 hover:bg-wealthsync-dark" 
                        : "bg-gray-100 hover:bg-gray-200"
                      } transition-all flex items-center justify-between relative overflow-hidden group`}
                      whileHover={{ scale: 1.01 }}
                      onClick={() => setSelectedBill(selectedBill === bill.id ? null : bill.id)}
                    >
                      {/* Status indicator strip */}
                      <div className={`absolute left-0 top-0 bottom-0 w-1 ${color.replace('text-', 'bg-')}`}></div>
                      
                      <div className="flex items-center space-x-3 ml-2">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${bgColor} group-hover:scale-110 transition-transform`}>
                          <span className={`text-sm font-medium ${color}`}>
                            {bill.dueDate.getDate()}
                          </span>
                        </div>
                        <div>
                          <h4 className="font-medium flex items-center gap-2">
                            {bill.name}
                            <Badge variant="outline" className={`${badgeColor} text-white text-xs py-0 px-1.5`}>
                              {status}
                            </Badge>
                          </h4>
                          <div className="flex items-center">
                            <span className="text-xs text-wealthsync-dimtext flex items-center">
                              <Clock className="h-3 w-3 mr-1 inline-block" />
                              {isNaN(daysUntil) ? "" : 
                                daysUntil < 0 ? `${Math.abs(daysUntil)} days overdue` : 
                                daysUntil === 0 ? "Today" : 
                                `Due in ${daysUntil} days`
                              }
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className={`text-right ${color} font-medium`}>
                        {formatCurrency(bill.amount, currency)}
                      </div>
                      
                      {/* Action panel that shows when bill is selected */}
                      <AnimatePresence>
                        {selectedBill === bill.id && (
                          <motion.div 
                            className="absolute inset-0 flex items-center justify-end bg-black/60 px-3"
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                          >
                            <div className="flex space-x-1">
                              <Button 
                                size="sm" 
                                variant="outline"
                                className="bg-green-500/20 border-green-500/50 text-green-500 hover:bg-green-500/30"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleMarkPaid(bill.id);
                                }}
                              >
                                <Check className="h-4 w-4 mr-1" />
                                Mark Paid
                              </Button>
                              <Button 
                                size="icon" 
                                variant="outline"
                                className="bg-blue-500/20 border-blue-500/50 text-blue-500 hover:bg-blue-500/30"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleEdit(bill);
                                }}
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button 
                                size="icon" 
                                variant="outline"
                                className="bg-red-500/20 border-red-500/50 text-red-500 hover:bg-red-500/30"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleDelete(bill.id);
                                }}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </motion.div>
                  );
                })}
                
                {bills.length > 3 && (
                  <Button variant="link" className="text-wealthsync-secondary w-full mt-2">
                    View all {bills.length} bills
                  </Button>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>
      
      {/* Edit Bill Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Bill</DialogTitle>
            <DialogDescription>Make changes to your bill details.</DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="name">Bill Name</Label>
              <Input id="name" value={editedName} onChange={(e) => setEditedName(e.target.value)} />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="amount">Amount</Label>
              <Input 
                id="amount" 
                type="number" 
                value={editedAmount} 
                onChange={(e) => setEditedAmount(e.target.value)} 
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="date">Due Date</Label>
              <Input 
                id="date" 
                type="date" 
                value={editedDate} 
                onChange={(e) => setEditedDate(e.target.value)} 
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEditDialog(false)}>Cancel</Button>
            <Button onClick={handleSaveEdit}>Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default BillReminderCard;
