
import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useFinance } from '@/contexts/FinanceContext';
import { useTheme } from '@/contexts/ThemeContext';
import { Upload } from 'lucide-react';

interface AddTransactionDialogProps {
  isOpen: boolean;
  onClose: () => void;
}

const PREDEFINED_CATEGORIES = [
  'Food', 'Transportation', 'Housing', 'Utilities', 'Healthcare',
  'Entertainment', 'Shopping', 'Education', 'Personal Care', 'Investments',
  'Savings', 'Gifts', 'Donations', 'Travel', 'Insurance',
  'Taxes', 'Subscriptions', 'Groceries', 'Dining Out', 'Electronics',
  'Clothing', 'Home Improvement', 'Auto', 'Hobbies', 'Pets'
];

const AddTransactionDialog: React.FC<AddTransactionDialogProps> = ({
  isOpen,
  onClose,
}) => {
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('');
  const [customCategory, setCustomCategory] = useState('');
  const [date, setDate] = useState(new Date().toISOString().substring(0, 10));
  const [note, setNote] = useState('');
  const [isRecurring, setIsRecurring] = useState(false);
  const [fileSelected, setFileSelected] = useState<File | null>(null);

  const { addTransaction } = useFinance();
  const { currency } = useTheme();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFileSelected(e.target.files[0]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!description || !amount) return;
    
    const finalCategory = category === 'Other' ? customCategory : category;
    
    if (!finalCategory) return;
    
    addTransaction({
      date: new Date(date),
      amount: parseFloat(amount),
      description,
      category: finalCategory,
      type: 'expense',
      isRecurring,
      note: note || undefined,
    });
    
    // Reset form
    setDescription('');
    setAmount('');
    setCategory('');
    setCustomCategory('');
    setDate(new Date().toISOString().substring(0, 10));
    setNote('');
    setIsRecurring(false);
    setFileSelected(null);
    
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-wealthsync-dark border border-gray-800 text-wealthsync-text sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="text-wealthsync-text">Add New Expense</DialogTitle>
          <DialogDescription className="text-wealthsync-dimtext">
            Enter the details of your expense below.
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="description">
              Description <span className="text-orange-500">*</span>
            </Label>
            <Input
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="bg-wealthsync-dark/70 border-gray-700 text-wealthsync-text"
              placeholder="e.g., Grocery Shopping"
              required
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="amount">
              Amount <span className="text-orange-500">*</span>
            </Label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-wealthsync-dimtext">
                {currency === 'INR' ? '₹' : '$'}
              </span>
              <Input
                id="amount"
                type="number"
                min="0"
                step="0.01"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="pl-8 bg-wealthsync-dark/70 border-gray-700 text-wealthsync-text"
                placeholder="0.00"
                required
              />
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="date">
                Date <span className="text-orange-500">*</span>
              </Label>
              <Input
                id="date"
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="bg-wealthsync-dark/70 border-gray-700 text-wealthsync-text"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="category">
                Category <span className="text-orange-500">*</span>
              </Label>
              <select
                id="category"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full bg-wealthsync-dark/70 border-gray-700 text-wealthsync-text rounded-md py-2"
                required
              >
                <option value="">Select category</option>
                {PREDEFINED_CATEGORIES.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
                <option value="Other">Other</option>
              </select>
            </div>
          </div>
          
          {category === 'Other' && (
            <div className="space-y-2">
              <Label htmlFor="customCategory">
                Custom Category <span className="text-orange-500">*</span>
              </Label>
              <Input
                id="customCategory"
                value={customCategory}
                onChange={(e) => setCustomCategory(e.target.value)}
                className="bg-wealthsync-dark/70 border-gray-700 text-wealthsync-text"
                placeholder="Enter custom category"
                required={category === 'Other'}
              />
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="receipt">Receipt (Optional)</Label>
            <div className="flex items-center">
              <label className="flex items-center justify-center gap-2 w-full py-2 px-4 border border-dashed border-gray-700 rounded-md cursor-pointer hover:bg-wealthsync-dark/50 transition-colors">
                <Upload size={16} />
                <span>{fileSelected ? fileSelected.name : "Attach receipt"}</span>
                <input 
                  id="receipt" 
                  type="file" 
                  accept="image/*,.pdf"
                  className="hidden"
                  onChange={handleFileChange}
                />
              </label>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <input
              type="checkbox"
              id="isRecurring"
              checked={isRecurring}
              onChange={() => setIsRecurring(!isRecurring)}
              className="rounded border-gray-700"
            />
            <Label htmlFor="isRecurring" className="text-sm">This is a recurring expense</Label>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="note">Note (Optional)</Label>
            <Input
              id="note"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              className="bg-wealthsync-dark/70 border-gray-700 text-wealthsync-text"
              placeholder="Add a note about this expense"
            />
          </div>
          
          <DialogFooter>
            <Button 
              type="button" 
              variant="outline"
              onClick={onClose}
              className="border-gray-700 text-wealthsync-text"
            >
              Cancel
            </Button>
            <Button 
              type="submit"
              className="bg-wealthsync-danger hover:bg-wealthsync-danger/90 text-white"
            >
              Add Expense
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default AddTransactionDialog;
