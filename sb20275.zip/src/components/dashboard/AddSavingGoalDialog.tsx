
import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useFinance } from '@/contexts/FinanceContext';

interface AddSavingGoalDialogProps {
  isOpen: boolean;
  onClose: () => void;
}

const AddSavingGoalDialog: React.FC<AddSavingGoalDialogProps> = ({
  isOpen,
  onClose,
}) => {
  const [name, setName] = useState('');
  const [currentAmount, setCurrentAmount] = useState('');
  const [targetAmount, setTargetAmount] = useState('');
  const [targetDate, setTargetDate] = useState('');

  const { addSavingGoal } = useFinance();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name || !targetAmount || !targetDate) return;
    
    addSavingGoal({
      name,
      currentAmount: parseFloat(currentAmount || '0'),
      targetAmount: parseFloat(targetAmount),
      targetDate: new Date(targetDate),
    });
    
    // Reset form
    setName('');
    setCurrentAmount('');
    setTargetAmount('');
    setTargetDate('');
    
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-wealthsync-dark border border-gray-800 text-wealthsync-text sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="text-wealthsync-text">Add New Saving Goal</DialogTitle>
          <DialogDescription className="text-wealthsync-dimtext">
            Set a new financial goal to track your progress.
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Goal Name</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="bg-wealthsync-dark/70 border-gray-700 text-wealthsync-text"
              placeholder="e.g., New Laptop, Vacation"
              required
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="currentAmount">Current Amount (Optional)</Label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-wealthsync-dimtext">
                ₹
              </span>
              <Input
                id="currentAmount"
                type="number"
                min="0"
                step="0.01"
                value={currentAmount}
                onChange={(e) => setCurrentAmount(e.target.value)}
                className="pl-8 bg-wealthsync-dark/70 border-gray-700 text-wealthsync-text"
                placeholder="0.00"
              />
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="targetAmount">Target Amount</Label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-wealthsync-dimtext">
                ₹
              </span>
              <Input
                id="targetAmount"
                type="number"
                min="0"
                step="0.01"
                value={targetAmount}
                onChange={(e) => setTargetAmount(e.target.value)}
                className="pl-8 bg-wealthsync-dark/70 border-gray-700 text-wealthsync-text"
                placeholder="0.00"
                required
              />
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="targetDate">Target Date</Label>
            <Input
              id="targetDate"
              type="date"
              value={targetDate}
              onChange={(e) => setTargetDate(e.target.value)}
              className="bg-wealthsync-dark/70 border-gray-700 text-wealthsync-text"
              required
            />
          </div>
          
          <DialogFooter>
            <Button 
              type="button" 
              variant="outline"
              onClick={onClose}
              className="border-gray-700 text-wealthsync-text"
            >
              Cancel
            </Button>
            <Button 
              type="submit"
              className="bg-wealthsync-secondary hover:bg-wealthsync-secondary/90 text-white"
            >
              Create Goal
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default AddSavingGoalDialog;
