
import React, { useState } from 'react';
import { SavingGoal } from '@/types';
import { formatCurrency } from '@/utils/currency';
import { TrendingUp, Plus, Edit, Trash2, PiggyBank, RefreshCcw, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';
import { useTheme } from '@/contexts/ThemeContext';

interface SavingGoalsProps {
  goals: SavingGoal[];
  onAddGoal: () => void;
}

const SavingGoals: React.FC<SavingGoalsProps> = ({ goals, onAddGoal }) => {
  const [selectedGoal, setSelectedGoal] = useState<string | null>(null);
  const { currency } = useTheme();

  // Add sparkle animation to goal when contribution is made
  const [sparkleGoal, setSparkleGoal] = useState<string | null>(null);

  const handleEdit = (id: string) => {
    toast.info("Edit goal functionality coming soon!");
  };

  const handleDelete = (id: string) => {
    toast.success("Goal removed successfully!");
    setSelectedGoal(null);
  };

  const handleContribute = (id: string) => {
    setSparkleGoal(id);
    setTimeout(() => setSparkleGoal(null), 2000);
    toast.success("Contribution added successfully!");
    setSelectedGoal(null);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.1 }}
      className="glass-card p-6"
    >
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-2">
          <TrendingUp size={18} className="text-wealthsync-secondary" />
          <h2 className="text-lg font-semibold">Saving Goals</h2>
        </div>

        <Button
          onClick={onAddGoal}
          size="sm"
          variant="outline"
          className="border-gray-700 hover:border-wealthsync-primary text-wealthsync-text"
        >
          <Plus size={16} className="mr-1" />
          Set New Goal
        </Button>
      </div>

      {goals.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <PiggyBank size={48} className="text-wealthsync-dimtext mb-2 opacity-50" />
          <p className="text-wealthsync-dimtext mb-2">No saving goals yet</p>
          <Button
            onClick={onAddGoal}
            variant="outline"
            className="mt-4 border-gray-700 text-wealthsync-text hover:border-wealthsync-primary"
          >
            <Plus size={16} className="mr-1" />
            Create Your First Saving Goal
          </Button>
        </div>
      ) : (
        <div className="space-y-6">
          {goals.map((goal) => (
            <div 
              key={goal.id} 
              className="space-y-2 relative"
              onClick={() => setSelectedGoal(selectedGoal === goal.id ? null : goal.id)}
            >
              <div className="flex items-center justify-between">
                <h3 className="font-medium">{goal.name}</h3>
                <p className="text-sm text-wealthsync-dimtext">
                  Target Date: {goal.targetDate.toLocaleDateString()}
                </p>
              </div>

              <div className="relative">
                <div className="progress-bar">
                  <motion.div 
                    className="progress-bar-fill bg-wealthsync-secondary" 
                    style={{ width: `${goal.progress}%` }}
                    initial={{ width: 0 }}
                    animate={{ width: `${goal.progress}%` }}
                    transition={{ duration: 1, ease: "easeOut" }}
                  />
                </div>

                {/* Sparkle effect when goal is updated */}
                <AnimatePresence>
                  {sparkleGoal === goal.id && (
                    <motion.div 
                      className="absolute top-1/2 -translate-y-1/2"
                      style={{ left: `${goal.progress}%` }}
                      initial={{ opacity: 0, scale: 0 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0 }}
                    >
                      <Sparkles className="h-5 w-5 text-yellow-400" />
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
              
              <div className="flex justify-between text-sm">
                <span className="text-wealthsync-text">
                  {formatCurrency(goal.currentAmount, currency)}
                </span>
                <span className="text-wealthsync-dimtext">
                  {formatCurrency(goal.targetAmount, currency)}
                </span>
              </div>

              {/* Action panel that shows when goal is selected */}
              {selectedGoal === goal.id && (
                <motion.div 
                  className="absolute inset-0 flex items-center justify-end bg-black/60 rounded-lg px-3"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                >
                  <div className="flex space-x-1">
                    <Button 
                      size="sm" 
                      variant="outline"
                      className="bg-green-500/20 border-green-500/50 text-green-500 hover:bg-green-500/30"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleContribute(goal.id);
                      }}
                    >
                      <Plus className="h-4 w-4 mr-1" />
                      Contribute
                    </Button>
                    <Button 
                      size="icon" 
                      variant="outline"
                      className="bg-blue-500/20 border-blue-500/50 text-blue-500 hover:bg-blue-500/30"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleEdit(goal.id);
                      }}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button 
                      size="icon" 
                      variant="outline"
                      className="bg-red-500/20 border-red-500/50 text-red-500 hover:bg-red-500/30"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDelete(goal.id);
                      }}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </motion.div>
              )}
            </div>
          ))}
        </div>
      )}
    </motion.div>
  );
};

export default SavingGoals;
