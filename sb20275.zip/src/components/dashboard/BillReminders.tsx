
import React, { useState } from 'react';
import { formatCurrency } from '@/utils/currency';
import { BillReminder } from '@/types';
import { Button } from '@/components/ui/button';
import { CheckCircle, Circle, Plus, Calendar } from 'lucide-react';

interface BillReminderProps {
  bills: BillReminder[];
  onAddBill?: () => void;
  onMarkPaid?: (id: string) => void;
}

const getBillStatusColor = (dueDate: Date): string => {
  const today = new Date();
  const daysUntilDue = Math.ceil((dueDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
  
  if (daysUntilDue < 0) return 'text-red-500'; // Overdue
  if (daysUntilDue <= 3) return 'text-amber-500'; // Due soon
  if (daysUntilDue <= 7) return 'text-yellow-500'; // Coming up
  return 'text-green-500'; // Due later
}

const BillReminders = ({ bills, onAddBill, onMarkPaid }: BillReminderProps) => {
  const [expandedBill, setExpandedBill] = useState<string | null>(null);
  
  const toggleExpand = (id: string) => {
    setExpandedBill(expandedBill === id ? null : id);
  };
  
  // Sort bills by due date
  const sortedBills = [...bills].sort((a, b) => a.dueDate.getTime() - b.dueDate.getTime());
  
  return (
    <div className="glass-card p-6">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-xl font-semibold">Bill Reminders</h3>
        <Button
          variant="ghost"
          size="icon"
          className="h-8 w-8 bg-wealthsync-primary/10 text-wealthsync-primary rounded-full"
          onClick={onAddBill}
        >
          <Plus size={16} />
        </Button>
      </div>
      
      {sortedBills.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-8 text-center">
          <Calendar size={40} className="text-wealthsync-dimtext mb-2 opacity-50" />
          <p className="text-wealthsync-dimtext">No upcoming bills</p>
          <Button
            variant="outline"
            size="sm"
            className="mt-4 border-gray-700"
            onClick={onAddBill}
          >
            <Plus size={14} className="mr-1" />
            Add Bill Reminder
          </Button>
        </div>
      ) : (
        <div className="space-y-3">
          {sortedBills.map((bill) => {
            const statusColor = getBillStatusColor(bill.dueDate);
            const isExpanded = expandedBill === bill.id;
            
            return (
              <div
                key={bill.id}
                className="transition-all duration-200 bg-wealthsync-dark/40 rounded-lg overflow-hidden border border-gray-800 hover:border-gray-700"
              >
                <div
                  className="p-3 flex items-center justify-between cursor-pointer"
                  onClick={() => toggleExpand(bill.id)}
                >
                  <div className="flex items-center">
                    {bill.isPaid ? (
                      <CheckCircle size={18} className="text-wealthsync-success mr-3" />
                    ) : (
                      <Circle size={18} className={`${statusColor} mr-3`} />
                    )}
                    <div>
                      <h4 className="font-medium">{bill.name}</h4>
                      <div className="text-xs text-wealthsync-dimtext flex items-center">
                        <span className={`w-2 h-2 rounded-full ${statusColor} mr-1.5`}></span>
                        Due {bill.dueDate.toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className={`font-semibold ${bill.isPaid ? 'text-wealthsync-dimtext line-through' : ''}`}>
                      {formatCurrency(bill.amount)}
                    </div>
                    <div className="text-xs text-wealthsync-dimtext">{bill.category}</div>
                  </div>
                </div>
                
                {isExpanded && (
                  <div className="p-3 pt-0 border-t border-gray-800 bg-wealthsync-dark/60">
                    <div className="flex justify-between text-sm py-2">
                      <span className="text-wealthsync-dimtext">Status:</span>
                      <span className={bill.isPaid ? 'text-wealthsync-success' : statusColor}>
                        {bill.isPaid ? 'Paid' : 'Pending'}
                      </span>
                    </div>
                    
                    {!bill.isPaid && (
                      <Button
                        variant="outline"
                        size="sm"
                        className="w-full mt-2 border-gray-700 hover:bg-wealthsync-success/20 hover:text-wealthsync-success hover:border-wealthsync-success"
                        onClick={(e) => {
                          e.stopPropagation();
                          if (onMarkPaid) onMarkPaid(bill.id);
                        }}
                      >
                        Mark as Paid
                      </Button>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default BillReminders;
