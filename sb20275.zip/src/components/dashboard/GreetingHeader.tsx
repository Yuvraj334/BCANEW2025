
import React from 'react';
import { useTheme } from '@/contexts/ThemeContext';
import { motion } from 'framer-motion';
import useGreeting from '@/hooks/useGreeting';

interface GreetingHeaderProps {
  userName?: string;
  style?: { background: string };
}

const GreetingHeader = ({ userName = 'User' }: GreetingHeaderProps) => {
  const { mode } = useTheme();
  const { 
    greeting, 
    emoji, 
    formattedDate, 
    formattedTime, 
    suggestion, 
    currentQuote,
    visitCount,
    streak,
    timeOnSite
  } = useGreeting();
  
  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: {
        when: "beforeChildren",
        staggerChildren: 0.2
      }
    }
  };
  
  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { type: "spring", stiffness: 300, damping: 24 }
    }
  };

  return (
    <motion.div 
      className="relative mb-8 overflow-hidden rounded-xl"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      <div className={`p-6 rounded-xl ${mode === 'dark' ? 'bg-gradient-to-br from-slate-800/70 to-slate-900/70' : 'bg-gradient-to-br from-slate-50 to-slate-100'}`}>
        <div className="relative z-10">
          <motion.div variants={itemVariants} className="mb-2">
            <h1 className="text-4xl font-bold">
              {greeting} {emoji}, {userName}
            </h1>
            <div className="flex flex-wrap items-center text-muted-foreground text-sm mt-2 gap-2">
              <span>{formattedDate}</span>
              <span>•</span>
              <span>{formattedTime}</span>
              <span>•</span>
              <span className="flex items-center">
                {streak} day streak <span className="ml-1">🔥</span>
              </span>
              <span>•</span>
              <span>Visit #{visitCount}</span>
              <span>•</span>
              <span>Time: {timeOnSite}</span>
            </div>
          </motion.div>
          
          <motion.div
            variants={itemVariants}
            className={`p-5 rounded-lg border transition-all duration-300 mt-4 ${
              mode === 'dark'
                ? "bg-[#151515] border-neutral-800 text-white"
                : "bg-white border-neutral-200 text-neutral-800"
            }`}
          >
            <div className="flex items-start">
              <div className="p-2 rounded-md bg-muted mr-4">
                <span className="text-xl">💬</span>
              </div>
              <div>
                <p className="italic text-lg">"{currentQuote.text}"</p>
                <p className="text-muted-foreground mt-1">— {currentQuote.author}</p>
              </div>
            </div>
          </motion.div>
          
          <motion.div 
            variants={itemVariants}
            className="mt-4 p-4 rounded-lg text-sm font-medium bg-rose-900/20 text-muted-foreground"
          >
            <span className="text-rose-400 font-semibold">Evening tip:</span>{" "}
            {suggestion}
          </motion.div>
        </div>
        
        {/* Animated background elements */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full filter blur-3xl -mr-20 -mt-20 animate-blob"></div>
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-primary/10 rounded-full filter blur-3xl -ml-20 -mb-20 animate-blob animation-delay-2000"></div>
      </div>
    </motion.div>
  );
};

export default GreetingHeader;
