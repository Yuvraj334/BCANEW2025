import React, { useState, useEffect } from 'react';
import { useFinance } from '@/contexts/FinanceContext';
import { formatCurrency } from '@/utils/currency';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';

interface UpdateIncomeDialogProps {
  isOpen: boolean;
  onClose: () => void;
  currentIncome: number;
  onSave: (newAmount: number) => void;
}

const UpdateIncomeDialog: React.FC<UpdateIncomeDialogProps> = ({
  isOpen,
  onClose,
  currentIncome,
  onSave,
}) => {
  const [income, setIncome] = useState(currentIncome);
  const { updateIncome } = useFinance();
  const [theme, setTheme] = useState('dark'); // Optional: replace with real theme context if available

  useEffect(() => {
    if (isOpen) {
      setIncome(currentIncome);
    }
  }, [isOpen, currentIncome]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    updateIncome(income);
    toast.success("Income updated", {
      description: "Your income has been updated successfully."
    });
    onSave(income);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent
        className={`border text-wealthsync-text sm:max-w-[425px] ${theme === 'dark' ? 'bg-black border-white' : 'bg-white border-black'}`}
      >
        <DialogHeader>
          <DialogTitle className="text-wealthsync-text">Update Income</DialogTitle>
          <DialogDescription className="text-wealthsync-dimtext">
            Adjust your income amount below. This will affect your overall financial balance.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="income" className="text-wealthsync-text">
              Monthly Income
            </Label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-wealthsync-dimtext">
                ₹
              </span>
              <Input
                id="income"
                type="number"
                value={income}
                onChange={(e) => setIncome(Number(e.target.value))}
                className={`pl-8 border ${theme === 'dark' ? 'bg-black text-white border-white' : 'bg-white text-black border-black'}`}
                autoFocus
              />
            </div>
            <p className="text-sm text-wealthsync-dimtext mt-2">
              Current income: {formatCurrency(currentIncome)}
            </p>
          </div>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className={`border ${theme === 'dark' ? 'border-white text-white' : 'border-black text-black'}`}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="bg-wealthsync-primary hover:bg-wealthsync-primary/90 text-white"
            >
              Update Income
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default UpdateIncomeDialog;
