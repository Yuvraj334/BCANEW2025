
import { useState, useEffect } from 'react';
import { format } from 'date-fns';

export const useGreeting = () => {
  const [greeting, setGreeting] = useState('');
  const [emoji, setEmoji] = useState('');
  const [formattedDate, setFormattedDate] = useState('');
  const [formattedTime, setFormattedTime] = useState('');
  const [suggestion, setSuggestion] = useState('');
  const [timeOfDay, setTimeOfDay] = useState('');
  
  // Sample quotes
  const quotes = [
    { text: "A penny saved is a penny earned.", author: "Benjamin Franklin" },
    { text: "An investment in knowledge pays the best interest.", author: "Benjamin Franklin" },
    { text: "The price of anything is the amount of life you exchange for it.", author: "Henry David Thoreau" },
    { text: "Financial peace isn't the acquisition of stuff. It's learning to live on less than you make.", author: "Dave Ramsey" },
    { text: "It's not how much money you make, but how much money you keep.", author: "Robert Kiyosaki" }
  ];
  
  const [quoteIndex, setQuoteIndex] = useState(0);
  
  // Update time and greeting
  useEffect(() => {
    const updateDateTime = () => {
      const now = new Date();
      const hours = now.getHours();
      
      setFormattedDate(format(now, "EEEE, MMMM d, yyyy"));
      setFormattedTime(format(now, "h:mm a"));
      
      if (hours < 12) {
        setGreeting('Good Morning');
        setEmoji('🌅');
        setTimeOfDay('morning');
        setSuggestion('Start your day with a financial check-in!');
      } else if (hours < 18) {
        setGreeting('Good Afternoon');
        setEmoji('☀️');
        setTimeOfDay('afternoon');
        setSuggestion('Check your spending for the day so far.');
      } else {
        setGreeting('Good Evening');
        setEmoji('🌙');
        setTimeOfDay('evening');
        setSuggestion('Review your spending and plan for tomorrow.');
      }
    };
    
    updateDateTime();
    
    // Update every minute
    const timerId = setInterval(updateDateTime, 60000);
    return () => clearInterval(timerId);
  }, []);
  
  // Cycle quote every 5 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setQuoteIndex(prev => (prev + 1) % quotes.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);
  
  return {
    greeting,
    emoji,
    formattedDate,
    formattedTime,
    timeOfDay,
    suggestion,
    currentQuote: quotes[quoteIndex],
    visitCount: localStorage.getItem('visitCount') ? Number(localStorage.getItem('visitCount')) : 1,
    streak: 7, // Dummy value for now
    timeOnSite: "14d 3h", // Dummy value for now
  };
};

export default useGreeting;
