
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { ChatMessage } from '@/types';
import { useFinance } from './FinanceContext';

type AiAssistantContextType = {
  messages: ChatMessage[];
  isTyping: boolean;
  sendMessage: (content: string) => void;
  suggestedQuestions: string[];
};

const AiAssistantContext = createContext<AiAssistantContextType | undefined>(undefined);

const defaultSuggestedQuestions = [
  "How can I improve my savings?",
  "Analyze my spending patterns",
  "Create a budget plan for me",
  "How much should I save each month?",
  "Tips to reduce my expenses"
];

export const AiAssistantProvider = ({ children }: { children: ReactNode }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const [suggestedQuestions, setSuggestedQuestions] = useState<string[]>(defaultSuggestedQuestions);
  
  const { financialSummary } = useFinance();

  // Initial greeting when the assistant loads
  useEffect(() => {
    const initialMessage: ChatMessage = {
      id: `msg-${Date.now()}`,
      content: "Hello! I'm your WealthSync AI assistant. How can I help you with your finances today?",
      role: 'assistant',
      timestamp: new Date(),
    };
    
    setMessages([initialMessage]);
  }, []);

  // Simulate AI response
  const generateAiResponse = async (userMessage: string): Promise<string> => {
    // Here you would integrate with the Gemini API
    // For now, we'll simulate responses with some finance-related answers
    
    // Simple keyword matching for demo purposes
    let response = "";
    const lowerMsg = userMessage.toLowerCase();
    
    if (lowerMsg.includes('saving') || lowerMsg.includes('save')) {
      response = `Based on your current balance of ${financialSummary.currentBalance}, I recommend setting aside 20% of your income for savings. This would be approximately ${Math.round(financialSummary.totalIncome * 0.2)} per month.`;
    } 
    else if (lowerMsg.includes('budget') || lowerMsg.includes('plan')) {
      response = "I can help create a budget plan! A good starting framework is the 50/30/20 rule: 50% for needs, 30% for wants, and 20% for savings and debt repayment.";
    }
    else if (lowerMsg.includes('spend') || lowerMsg.includes('expense')) {
      response = `Your current spending is ${financialSummary.totalExpenses}. Most of your expenses are in the category of Food and Dining. You could potentially save by cooking more meals at home.`;
    }
    else if (lowerMsg.includes('invest') || lowerMsg.includes('investment')) {
      response = "For investment advice, consider diversifying your portfolio with a mix of stocks, bonds, and index funds based on your risk tolerance.";
    }
    else {
      response = "That's a great question. While analyzing your financial data, I recommend focusing on building an emergency fund that covers 3-6 months of your expenses before making other financial decisions.";
    }
    
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    return response;
  };

  const sendMessage = async (content: string) => {
    if (!content.trim()) return;
    
    // Add user message
    const userMessage: ChatMessage = {
      id: `msg-${Date.now()}-user`,
      content,
      role: 'user',
      timestamp: new Date(),
    };
    
    setMessages(prev => [...prev, userMessage]);
    
    // Start AI typing animation
    setIsTyping(true);
    
    try {
      // Get AI response
      const responseContent = await generateAiResponse(content);
      
      // Add AI response
      const aiMessage: ChatMessage = {
        id: `msg-${Date.now()}-ai`,
        content: responseContent,
        role: 'assistant',
        timestamp: new Date(),
      };
      
      setMessages(prev => [...prev, aiMessage]);
      
      // Update suggested questions based on context
      // In a real app, this would be more sophisticated
      setSuggestedQuestions([
        "Tell me more about investment options",
        "How can I reduce my monthly expenses?",
        "What's a good savings target?",
        "Analyze my spending trends",
        "Help me create a debt repayment plan"
      ]);
    } catch (error) {
      console.error('Error generating AI response:', error);
      
      // Add error message
      const errorMessage: ChatMessage = {
        id: `msg-${Date.now()}-error`,
        content: "I'm sorry, I encountered an error. Please try again later.",
        role: 'assistant',
        timestamp: new Date(),
      };
      
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <AiAssistantContext.Provider
      value={{
        messages,
        isTyping,
        sendMessage,
        suggestedQuestions,
      }}
    >
      {children}
    </AiAssistantContext.Provider>
  );
};

export const useAiAssistant = () => {
  const context = useContext(AiAssistantContext);
  if (context === undefined) {
    throw new Error('useAiAssistant must be used within an AiAssistantProvider');
  }
  return context;
};
