import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Transaction, BillReminder, SavingGoal, FinancialSummary } from '@/types';
import { v4 as uuidv4 } from 'uuid';
import { toast } from 'sonner';

interface FinanceContextType {
  transactions: Transaction[];
  billReminders: BillReminder[];
  savingGoals: SavingGoal[];
  financialSummary: FinancialSummary;
  addTransaction: (transaction: Omit<Transaction, 'id'>) => void;
  updateTransaction: (id: string, transaction: Partial<Transaction>) => void;
  deleteTransaction: (id: string) => void;
  addBill: (bill: Omit<BillReminder, 'id'>) => void;
  updateBillReminder: (id: string, reminder: Partial<BillReminder>) => void;
  deleteBillReminder: (id: string) => void;
  toggleBillPaid: (id: string) => void;
  addSavingGoal: (goal: Omit<SavingGoal, 'id' | 'progress'>) => void;
  updateSavingGoal: (id: string, goal: Partial<Omit<SavingGoal, 'progress'>>) => void;
  deleteSavingGoal: (id: string) => void;
  contributeSavingGoal: (id: string, amount: number) => void;
  updateIncome: (newIncome: number) => void;
  convertCurrency: (amount: number, fromCurrency: string, toCurrency: string) => number;
}

const FinanceContext = createContext<FinanceContextType | undefined>(undefined);

export const FinanceProvider = ({ children }: { children: ReactNode }) => {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [billReminders, setBillReminders] = useState<BillReminder[]>([]);
  const [savingGoals, setSavingGoals] = useState<SavingGoal[]>([]);
  const [financialSummary, setFinancialSummary] = useState<FinancialSummary>({
    totalIncome: 0,
    totalExpenses: 0,
    currentBalance: 0,
    incomeChange: 0,
    expensesChange: 0,
    balanceChange: 0,
  });

  const convertCurrency = (amount: number, fromCurrency: string, toCurrency: string): number => {
    const exchangeRates: Record<string, number> = {
      USD: 1,
      EUR: 0.9,
      INR: 83,
      GBP: 0.78,
      JPY: 150,
      CAD: 1.35
    };

    if (!exchangeRates[fromCurrency] || !exchangeRates[toCurrency]) {
      toast.error('Currency not supported for conversion');
      return amount;
    }

    return (amount / exchangeRates[fromCurrency]) * exchangeRates[toCurrency];
  };

  // Transactions
  const addTransaction = (transaction: Omit<Transaction, 'id'>) => {
    const newTransaction: Transaction = { ...transaction, id: uuidv4() };
    setTransactions(prev => [...prev, newTransaction]);

    if (transaction.type === 'income') {
      setFinancialSummary(prev => ({
        ...prev,
        totalIncome: prev.totalIncome + transaction.amount,
        currentBalance: prev.currentBalance + transaction.amount,
        incomeChange: prev.totalIncome ? ((prev.totalIncome + transaction.amount) / prev.totalIncome - 1) * 100 : 0,
        balanceChange: prev.currentBalance ? ((prev.currentBalance + transaction.amount) / prev.currentBalance - 1) * 100 : 0,
      }));
    } else {
      setFinancialSummary(prev => ({
        ...prev,
        totalExpenses: prev.totalExpenses + transaction.amount,
        currentBalance: prev.currentBalance - transaction.amount,
        expensesChange: prev.totalExpenses ? ((prev.totalExpenses + transaction.amount) / prev.totalExpenses - 1) * 100 : 0,
        balanceChange: prev.currentBalance ? ((prev.currentBalance - transaction.amount) / prev.currentBalance - 1) * 100 : 0,
      }));
    }

    toast.success(`${transaction.type === 'income' ? 'Income' : 'Expense'} added successfully!`);
  };

  const updateTransaction = (id: string, transaction: Partial<Transaction>) => {
    const oldTransaction = transactions.find(t => t.id === id);
    if (!oldTransaction) return;

    setTransactions(transactions.map(t => t.id === id ? { ...t, ...transaction } : t));

    if (transaction.amount !== undefined && transaction.amount !== oldTransaction.amount) {
      const diff = transaction.amount - oldTransaction.amount;

      setFinancialSummary(prev => {
        if (oldTransaction.type === 'income') {
          return {
            ...prev,
            totalIncome: prev.totalIncome + diff,
            currentBalance: prev.currentBalance + diff,
          };
        } else {
          return {
            ...prev,
            totalExpenses: prev.totalExpenses + diff,
            currentBalance: prev.currentBalance - diff,
          };
        }
      });
    }

    toast.success('Transaction updated!');
  };

  const deleteTransaction = (id: string) => {
    const transaction = transactions.find(t => t.id === id);
    if (!transaction) return;

    setTransactions(transactions.filter(t => t.id !== id));

    setFinancialSummary(prev => {
      if (transaction.type === 'income') {
        return {
          ...prev,
          totalIncome: prev.totalIncome - transaction.amount,
          currentBalance: prev.currentBalance - transaction.amount,
        };
      } else {
        return {
          ...prev,
          totalExpenses: prev.totalExpenses - transaction.amount,
          currentBalance: prev.currentBalance + transaction.amount,
        };
      }
    });

    toast.success('Transaction deleted!');
  };

  // Bill Reminders
  const addBillReminder = (bill: Omit<BillReminder, 'id'>) => {
    const newBill = { ...bill, id: uuidv4() };
    setBillReminders(prev => [...prev, newBill]);
    toast.success('Bill reminder added!');
  };

  const updateBillReminder = (id: string, reminder: Partial<BillReminder>) => {
    setBillReminders(prev => prev.map(r => r.id === id ? { ...r, ...reminder } : r));
    toast.success('Bill reminder updated!');
  };

  const deleteBillReminder = (id: string) => {
    setBillReminders(prev => prev.filter(r => r.id !== id));
    toast.success('Bill reminder deleted!');
  };

  const toggleBillPaid = (id: string) => {
    setBillReminders(prev =>
      prev.map(r => r.id === id ? { ...r, isPaid: !r.isPaid } : r)
    );

    const bill = billReminders.find(r => r.id === id);
    if (bill) {
      toast.success(bill.isPaid ? 'Bill marked as unpaid' : 'Bill marked as paid');
    }
  };

  // Saving Goals
  const addSavingGoal = (goal: Omit<SavingGoal, 'id' | 'progress'>) => {
    const progress = goal.targetAmount > 0 ? (goal.currentAmount / goal.targetAmount) * 100 : 0;
    const newGoal = { ...goal, id: uuidv4(), progress: Number(progress.toFixed(2)) };
    setSavingGoals(prev => [...prev, newGoal]);
    toast.success('Saving goal added!');
  };

  const updateSavingGoal = (id: string, goal: Partial<Omit<SavingGoal, 'progress'>>) => {
    setSavingGoals(prev =>
      prev.map(g => {
        if (g.id === id) {
          const current = goal.currentAmount ?? g.currentAmount;
          const target = goal.targetAmount ?? g.targetAmount;
          return {
            ...g,
            ...goal,
            progress: target > 0 ? Number(((current / target) * 100).toFixed(2)) : 0,
          };
        }
        return g;
      })
    );
    toast.success('Saving goal updated!');
  };

  const deleteSavingGoal = (id: string) => {
    setSavingGoals(prev => prev.filter(g => g.id !== id));
    toast.success('Saving goal deleted!');
  };

  const contributeSavingGoal = (id: string, amount: number) => {
    setSavingGoals(prev =>
      prev.map(g => {
        if (g.id === id) {
          const updatedAmount = g.currentAmount + amount;
          const progress = g.targetAmount > 0 ? Number(((updatedAmount / g.targetAmount) * 100).toFixed(2)) : 0;
          return { ...g, currentAmount: updatedAmount, progress };
        }
        return g;
      })
    );
    toast.success(`Contributed ${amount} to your saving goal!`);
  };

  // Income
  const updateIncome = (newIncome: number) => {
    if (newIncome < 0) {
      toast.error('Income cannot be negative');
      return;
    }

    setFinancialSummary(prev => {
      const diff = newIncome - prev.totalIncome;
      return {
        ...prev,
        totalIncome: newIncome,
        currentBalance: prev.currentBalance + diff,
        incomeChange: prev.totalIncome ? ((newIncome / prev.totalIncome) - 1) * 100 : 0,
        balanceChange: prev.currentBalance ? (((prev.currentBalance + diff) / prev.currentBalance) - 1) * 100 : 0,
      };
    });

    toast.success('Income updated!');
  };

  return (
    <FinanceContext.Provider
      value={{
        transactions,
        billReminders,
        savingGoals,
        financialSummary,
        addTransaction,
        updateTransaction,
        deleteTransaction,
        addBill: addBillReminder,
        updateBillReminder,
        deleteBillReminder,
        toggleBillPaid,
        addSavingGoal,
        updateSavingGoal,
        deleteSavingGoal,
        contributeSavingGoal,
        updateIncome,
        convertCurrency,
      }}
    >
      {children}
    </FinanceContext.Provider>
  );
};

export const useFinance = () => {
  const context = useContext(FinanceContext);
  if (context === undefined) {
    throw new Error('useFinance must be used within a FinanceProvider');
  }
  return context;
};
