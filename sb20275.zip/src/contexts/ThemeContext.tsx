import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

type ThemeMode = 'light' | 'dark';
type ColorTheme = 'blush-rose' | 'deep-plum' | 'midnight' | 'mahogany' | 'olive' | 'sand' | 'slate' | 'neutral' | 'frost-blue' | 'warm-taupe' | 'emerald' | 'azure' | 'sunset' | 'lavender' | 'coral' | 'teal';

interface ThemeContextType {
  mode: ThemeMode;
  colorTheme: ColorTheme;
  currency: string;
  fontSize: number;
  animationSpeed: number;
  toggleMode: (newMode?: ThemeMode) => void;
  setColorTheme: (theme: ColorTheme) => void;
  setCurrency: (currency: string) => void;
  setFontSize: (size: number) => void;
  setAnimationSpeed: (speed: number) => void;
  isCustomizationOpen: boolean;
  toggleCustomization: () => void;
  updateIncome: (amount: number) => void;
  updateExpense: (amount: number) => void;
  updateBill: (id: string, data: any) => void;
  updateSavingGoal: (id: string, data: any) => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

const ThemeProvider = ({ children }: { children: ReactNode }) => {
  const [mode, setMode] = useState<ThemeMode>(
    () => (localStorage.getItem('theme-mode') as ThemeMode) || 'light'
  );
  const [colorTheme, setColorTheme] = useState<ColorTheme>(
    () => (localStorage.getItem('color-theme') as ColorTheme) || 'sand'
  );
  const [currency, setCurrency] = useState<string>(
    () => localStorage.getItem('currency') || 'INR'
  );
  const [fontSize, setFontSize] = useState(
    () => Number(localStorage.getItem('font-size')) || 50
  );
  const [animationSpeed, setAnimationSpeed] = useState(
    () => Number(localStorage.getItem('animation-speed')) || 1
  );
  const [isCustomizationOpen, setIsCustomizationOpen] = useState(false);

  const toggleMode = (newMode?: ThemeMode) => {
    const updatedMode = newMode || (mode === 'light' ? 'dark' : 'light');
    setMode(updatedMode);
    localStorage.setItem('theme-mode', updatedMode);
  };

  const toggleCustomization = () => {
    setIsCustomizationOpen(!isCustomizationOpen);
  };

  const updateIncome = (amount: number) => {
    // Logic to update income
  };

  const updateExpense = (amount: number) => {
    // Logic to update expense
  };

  const updateBill = (id: string, data: any) => {
    // Logic to update bill
  };

  const updateSavingGoal = (id: string, data: any) => {
    // Logic to update saving goal
  };

  return (
    <ThemeContext.Provider
      value={{
        mode,
        colorTheme,
        currency,
        fontSize,
        animationSpeed,
        toggleMode,
        setColorTheme,
        setCurrency,
        setFontSize,
        setAnimationSpeed,
        isCustomizationOpen,
        toggleCustomization,
        updateIncome,
        updateExpense,
        updateBill,
        updateSavingGoal,
      }}
    >
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};

export { ThemeProvider };
export default ThemeProvider;
