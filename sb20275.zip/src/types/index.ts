
export type User = {
  name: string;
  avatar?: string;
  age?: number;
  gender?: string;
  initials?: string;
};

export type Transaction = {
  id: string;
  date: Date;
  amount: number;
  description: string;
  category: string;
  type: 'income' | 'expense';
  isRecurring?: boolean;
  note?: string;
  receiptUrl?: string;
};

export type SavingGoal = {
  id: string;
  name: string;
  currentAmount: number;
  targetAmount: number;
  targetDate: Date;
  progress: number;
};

export type FinancialSummary = {
  totalIncome: number;
  totalExpenses: number;
  currentBalance: number;
  incomeChange: number;
  expensesChange: number;
  balanceChange: number;
};

export type ChatMessage = {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
};

export interface BillReminder {
  id: string;
  name: string;
  amount: number;
  dueDate: Date;
  category: string;
  isPaid: boolean;
}

export type ThemeMode = 'light' | 'dark';

export type AppSettings = {
  currency: string;
  themeMode: ThemeMode;
  colorTheme: string;
  notifications: {
    email: boolean;
    push: boolean;
    billReminders: boolean;
    spendingAlerts: boolean;
  };
};

export type CategoryWithBudget = {
  name: string;
  budgetAmount: number;
  spentAmount: number;
  percentage: number;
};

export type MarketData = {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercentage: number;
  category?: 'stock' | 'crypto' | 'currency' | 'commodity';
  icon?: string;
};

export type Quote = {
  text: string;
  author: string;
};

export type MarketSectorData = {
  name: string;
  performance: number;
  marketCap: number;
  volume: number;
};

export type NewsItem = {
  title: string;
  source: string;
  date: string;
  url: string;
  imageUrl?: string;
  summary?: string;
  category?: string;
};

export type CryptoData = {
  id: string;
  symbol: string;
  name: string;
  image: string;
  current_price: number;
  price_change_percentage_24h: number;
  market_cap: number;
  total_volume: number;
};
