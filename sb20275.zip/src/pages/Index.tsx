import React, { useState, useEffect } from 'react';
import { FinanceProvider } from '@/contexts/FinanceContext';
import { AiAssistantProvider } from '@/contexts/AiAssistantContext';
import NavBar from '@/components/layout/NavBar';
import Dashboard from './Dashboard';
import SplashScreen from '@/components/layout/SplashScreen';
import CustomizationDialog from '@/components/layout/CustomizationDialog';
import { Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import AddTransactionDialog from '@/components/dashboard/AddTransactionDialog';
 import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

const Index = () => {
  const [showSplash, setShowSplash] = useState(true);
  const [isAddTransactionOpen, setIsAddTransactionOpen] = useState(false);

  useEffect(() => {
    const hasVisited = localStorage.getItem('wealthsync-visited');
    const timeoutDuration = hasVisited ? 2000 : 3000;

    const timeout = setTimeout(() => {
      setShowSplash(false);
      localStorage.setItem('wealthsync-visited', 'true');
    }, timeoutDuration);

    return () => clearTimeout(timeout);
  }, []);

  if (showSplash) {
    return <SplashScreen onFinished={() => setShowSplash(false)} />;
  }

  return (
    <div className="min-h-screen bg-wealthsync-dark">
      <FinanceProvider>
        <AiAssistantProvider>
          <NavBar />
          <Routes>
            {/* Removed Route for 3D Model */}
            <Route path="/" element={<Dashboard />} />
          </Routes>
        </AiAssistantProvider>
      </FinanceProvider>
    </div>
  );
};

export default Index;
