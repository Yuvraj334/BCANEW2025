
import React, { useState } from 'react';
import { useFinance } from '@/contexts/FinanceContext';
import { formatCurrency } from '@/utils/currency';
import { Search, Filter, Plus, PieChart, BarChart, MoreHorizontal, Edit, Trash2 } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import AddTransactionDialog from '@/components/dashboard/AddTransactionDialog';
import { PieChart as RechartPieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip, LineChart, Line, XAxis, YAxis, CartesianGrid, BarChart as RechartBarChart, Bar } from 'recharts';
import { motion } from 'framer-motion';
import GreetingHeader from '@/components/dashboard/GreetingHeader';
import FinancialCard from '@/components/dashboard/FinancialCard';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { toast } from 'sonner';
import { useTheme } from '@/contexts/ThemeContext';

const COLORS = ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40'];

const Expenses = () => {
  const { transactions, financialSummary } = useFinance();
  const { currency } = useTheme();
  const [isAddTransactionOpen, setIsAddTransactionOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState('overview');
  
  // Filter expenses only
  const expenseTransactions = transactions.filter(t => t.type === 'expense');
  
  // Apply search filter if query exists
  const filteredTransactions = searchQuery 
    ? expenseTransactions.filter(t => 
        t.description.toLowerCase().includes(searchQuery.toLowerCase()) || 
        t.category.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : expenseTransactions;
    
  // Group expenses by category for pie chart
  const expensesByCategory: Record<string, number> = {};
  expenseTransactions.forEach(transaction => {
    const { category, amount } = transaction;
    expensesByCategory[category] = (expensesByCategory[category] || 0) + amount;
  });
  
  // Prepare data for pie chart
  const pieChartData = Object.entries(expensesByCategory).map(([name, value]) => ({
    name,
    value
  }));
  
  // Prepare data for monthly expense trend
  const monthlyExpenses = [
    { month: 'Jan', expense: 12000 },
    { month: 'Feb', expense: 15000 },
    { month: 'Mar', expense: 10000 },
    { month: 'Apr', expense: 18000 },
    { month: 'May', expense: 14000 },
  ];
  
  // Prepare data for expense vs income
  const comparisonData = [
    { name: 'Jan', expense: 12000, income: 45000 },
    { name: 'Feb', expense: 15000, income: 48000 },
    { name: 'Mar', expense: 10000, income: 47000 },
    { name: 'Apr', expense: 18000, income: 50000 },
    { name: 'May', expense: 14000, income: 52000 },
  ];
  
  // Calculate total expenses
  const totalExpenses = expenseTransactions.reduce((sum, t) => sum + t.amount, 0);

  const handleEditTransaction = (id: string) => {
    toast.info("Edit transaction functionality coming soon!");
  };
  
  const handleDeleteTransaction = (id: string) => {
    toast.success("Transaction deleted successfully!");
  };
  
  return (
    <div className="container py-8">
      <GreetingHeader userName="Yuv Raj" />
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          whileHover={{ scale: 1.02 }}
          className="group relative"
        >
          <FinancialCard
            title="Total Income"
            amount={financialSummary.totalIncome}
            change={financialSummary.incomeChange}
            timePeriod="month"
            type="income"
            onEdit={() => toast.info("Update income functionality coming soon!")}
          />
          <div className="absolute inset-0 opacity-0 group-hover:opacity-100 bg-gradient-to-r from-green-500/10 to-green-300/10 rounded-xl transition-opacity duration-300 pointer-events-none"></div>
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.1 }}
          whileHover={{ scale: 1.02 }}
          className="group relative"
        >
          <FinancialCard
            title="Current Balance"
            amount={financialSummary.currentBalance}
            change={financialSummary.balanceChange}
            timePeriod="week"
            type="balance"
          />
          <div className="absolute inset-0 opacity-0 group-hover:opacity-100 bg-gradient-to-r from-blue-500/10 to-blue-300/10 rounded-xl transition-opacity duration-300 pointer-events-none"></div>
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.2 }}
          whileHover={{ scale: 1.02 }}
          className="group relative"
        >
          <FinancialCard
            title="Total Expenses"
            amount={financialSummary.totalExpenses}
            change={financialSummary.expensesChange}
            timePeriod="month"
            type="expense"
          />
          <div className="absolute inset-0 opacity-0 group-hover:opacity-100 bg-gradient-to-r from-red-500/10 to-red-300/10 rounded-xl transition-opacity duration-300 pointer-events-none"></div>
        </motion.div>
      </div>
      
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Expense Analysis</h1>
        <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
          <Button 
            onClick={() => setIsAddTransactionOpen(true)}
            className="bg-wealthsync-primary hover:bg-wealthsync-primary/90 text-white"
          >
            <Plus size={16} className="mr-2" />
            Add Expense
          </Button>
        </motion.div>
      </div>
      
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          whileHover={{ scale: 1.02 }}
          className="card-hover-effect"
        >
          <Card className="glass-card">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Total Expenses</CardTitle>
              <CardDescription>Monthly</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{formatCurrency(totalExpenses, currency)}</div>
              <p className="text-wealthsync-dimtext text-sm mt-2">+12% from last month</p>
            </CardContent>
          </Card>
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          whileHover={{ scale: 1.02 }}
          className="card-hover-effect"
        >
          <Card className="glass-card">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Biggest Expense</CardTitle>
              <CardDescription>This month</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{pieChartData.length > 0 ? pieChartData[0].name : "N/A"}</div>
              <p className="text-wealthsync-dimtext text-sm mt-2">
                {pieChartData.length > 0 ? formatCurrency(pieChartData[0].value, currency) : "No expenses"}
              </p>
            </CardContent>
          </Card>
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          whileHover={{ scale: 1.02 }}
          className="card-hover-effect"
        >
          <Card className="glass-card">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Savings</CardTitle>
              <CardDescription>Relative to income</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">65%</div>
              <p className="text-wealthsync-success text-sm mt-2">+5% from last month</p>
            </CardContent>
          </Card>
        </motion.div>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
        <TabsList className="mb-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="transactions">Transactions</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Expense Breakdown */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
              className="card-hover-effect"
            >
              <Card className="glass-card">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center">
                    <PieChart size={18} className="mr-2" />
                    Expense Breakdown
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <RechartPieChart>
                        <Pie
                          data={pieChartData}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                          label={({name, percent}) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        >
                          {pieChartData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Legend />
                        <Tooltip formatter={(value) => formatCurrency(Number(value), currency)} />
                      </RechartPieChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
            
            {/* Monthly Trend */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
              className="card-hover-effect"
            >
              <Card className="glass-card">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center">
                    <BarChart size={18} className="mr-2" />
                    Monthly Expense Trend
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={monthlyExpenses}>
                        <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
                        <XAxis dataKey="month" />
                        <YAxis />
                        <Tooltip formatter={(value) => formatCurrency(Number(value), currency)} />
                        <Line 
                          type="monotone" 
                          dataKey="expense" 
                          stroke="#FF6384" 
                          strokeWidth={2} 
                          dot={{ r: 4 }} 
                          activeDot={{ r: 6 }} 
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="card-hover-effect mt-8"
          >
            <Card className="glass-card">
              <CardHeader>
                <CardTitle className="text-lg">Expense vs. Income</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <RechartBarChart data={comparisonData}>
                      <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip formatter={(value) => formatCurrency(Number(value), currency)} />
                      <Legend />
                      <Bar dataKey="expense" fill="#FF6384" name="Expenses" />
                      <Bar dataKey="income" fill="#36A2EB" name="Income" />
                    </RechartBarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>
        
        <TabsContent value="analytics">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Radial Chart for Budget Usage */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
              className="card-hover-effect"
            >
              <Card className="glass-card">
                <CardHeader>
                  <CardTitle className="text-lg">Budget Utilization</CardTitle>
                  <CardDescription>How much of your budget have you spent</CardDescription>
                </CardHeader>
                <CardContent className="flex items-center justify-center py-8">
                  <div className="relative inline-flex items-center justify-center">
                    <svg className="w-40 h-40">
                      <circle 
                        className="text-gray-700" 
                        strokeWidth="10" 
                        stroke="currentColor" 
                        fill="transparent" 
                        r="70" 
                        cx="80" 
                        cy="80" 
                      />
                      <motion.circle 
                        className="text-wealthsync-primary" 
                        strokeWidth="10" 
                        strokeDasharray={440} 
                        strokeDashoffset={440 * (1 - 0.65)} 
                        strokeLinecap="round" 
                        stroke="currentColor" 
                        fill="transparent" 
                        r="70" 
                        cx="80" 
                        cy="80"
                        initial={{ strokeDashoffset: 440 }}
                        animate={{ strokeDashoffset: 440 * (1 - 0.65) }}
                        transition={{ duration: 1.5, ease: "easeInOut" }}
                      />
                    </svg>
                    <span className="absolute text-xl text-center">
                      <motion.span 
                        className="font-bold text-3xl block"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.8 }}
                      >
                        65%
                      </motion.span>
                      <span className="text-wealthsync-dimtext text-sm">Used</span>
                    </span>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
            
            {/* Top Spending Categories */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="card-hover-effect"
            >
              <Card className="glass-card">
                <CardHeader>
                  <CardTitle className="text-lg">Top Spending Categories</CardTitle>
                  <CardDescription>Where your money is going</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {pieChartData.slice(0, 5).map((category, index) => (
                    <motion.div 
                      key={index} 
                      className="space-y-2"
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.1 * index }}
                    >
                      <div className="flex justify-between items-center">
                        <span className="font-medium">{category.name}</span>
                        <span>{formatCurrency(category.value, currency)}</span>
                      </div>
                      <div className="h-2 bg-gray-700 rounded-full overflow-hidden">
                        <motion.div 
                          className="h-full rounded-full" 
                          style={{ backgroundColor: COLORS[index % COLORS.length] }}
                          initial={{ width: 0 }}
                          animate={{ width: `${(category.value / totalExpenses) * 100}%` }}
                          transition={{ duration: 1, delay: 0.2 * index }}
                        />
                      </div>
                    </motion.div>
                  ))}
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </TabsContent>
        
        <TabsContent value="transactions">
          <Card className="glass-card">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">Recent Transactions</CardTitle>
                <div className="flex">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-wealthsync-dimtext" size={18} />
                    <Input
                      placeholder="Search transactions..."
                      className="pl-10 bg-wealthsync-dark/70 border-gray-700 text-wealthsync-text max-w-xs"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                  <Button 
                    variant="outline" 
                    size="icon"
                    className="ml-2 border-gray-700"
                  >
                    <Filter size={18} />
                  </Button>
                  <Button 
                    variant="default" 
                    size="sm"
                    className="ml-2 bg-wealthsync-primary text-white"
                    onClick={() => setIsAddTransactionOpen(true)}
                  >
                    <Plus size={16} className="mr-2" />
                    Add
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {filteredTransactions.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-16 text-center">
                  <p className="text-wealthsync-dimtext mb-2">
                    {searchQuery ? 'No transactions matching your search' : 'No expense transactions yet'}
                  </p>
                  <motion.div
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <Button
                      onClick={() => setIsAddTransactionOpen(true)}
                      variant="outline"
                      className="mt-4 border-gray-700 text-wealthsync-text hover:border-wealthsync-primary"
                    >
                      <Plus size={16} className="mr-2" />
                      Add Your First Expense
                    </Button>
                  </motion.div>
                </div>
              ) : (
                <div className="space-y-4 max-h-[500px] overflow-y-auto pr-2">
                  {filteredTransactions.map((transaction) => (
                    <motion.div 
                      key={transaction.id} 
                      className="flex items-center justify-between p-4 hover:bg-wealthsync-dark/50 rounded-md transition-colors border border-gray-800"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      whileHover={{ scale: 1.01 }}
                    >
                      <div className="flex items-center space-x-4">
                        <div className="w-10 h-10 rounded-full bg-gray-700 flex items-center justify-center">
                          {transaction.category.charAt(0)}
                        </div>
                        
                        <div>
                          <h4 className="font-medium">{transaction.description}</h4>
                          <div className="flex items-center">
                            <span className="text-sm text-wealthsync-dimtext">
                              {transaction.date instanceof Date
                                ? transaction.date.toLocaleDateString()
                                : new Date(transaction.date).toLocaleDateString()
                              }
                            </span>
                            <span className="mx-2 text-gray-600">•</span>
                            <span className="text-sm text-wealthsync-secondary">
                              {transaction.category}
                            </span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-3">
                        <div className="text-wealthsync-danger font-semibold">
                          -{formatCurrency(transaction.amount, currency)}
                        </div>
                        
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Transaction</DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem 
                              onClick={() => handleEditTransaction(transaction.id)}
                              className="flex items-center"
                            >
                              <Edit className="mr-2 h-4 w-4" />
                              Edit
                            </DropdownMenuItem>
                            <DropdownMenuItem 
                              onClick={() => handleDeleteTransaction(transaction.id)}
                              className="flex items-center text-red-500 focus:text-red-500"
                            >
                              <Trash2 className="mr-2 h-4 w-4" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      {/* Dialog */}
      <AddTransactionDialog
        isOpen={isAddTransactionOpen}
        onClose={() => setIsAddTransactionOpen(false)}
      />
    </div>
  );
};

export default Expenses;
