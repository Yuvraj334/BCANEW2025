
import React from 'react';
import { motion } from 'framer-motion';
import { useTheme } from '@/contexts/ThemeContext';

const Viewer = () => {
  const { colorTheme } = useTheme();
  
  return (
    <div className="min-h-screen bg-wealthsync-dark flex flex-col">
      <div className="flex-1 flex">
        {/* Left sidebar with app name */}
        <motion.div 
          className="w-64 p-8 flex flex-col justify-center items-center"
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5, duration: 0.8 }}
        >
          <motion.h1 
            className="text-4xl font-bold writing-mode-vertical text-transparent bg-clip-text bg-gradient-to-b from-wealthsync-primary to-wealthsync-primary/50"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1, duration: 1 }}
          >
            WealthSync
          </motion.h1>
          
          <motion.div 
            className="mt-12 space-y-6"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.5, duration: 1 }}
          >
            <div className="text-center text-muted-foreground">
              <p className="text-sm">Current Theme:</p>
              <p className="text-lg font-medium capitalize">{colorTheme.replace('-', ' ')}</p>
            </div>
          </motion.div>
        </motion.div>
        
        {/* Main content area for Spline */}
        <motion.div 
          className="flex-1 relative"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1 }}
        >
          <div className="absolute inset-0 flex items-center justify-center">
            {/* Placeholder for Spline animation */}
            <div className="w-full h-full">
              {/* We can conditionally load the Spline component when it's ready */}
              <div className="w-full h-full flex items-center justify-center">
                <div className="text-center">
                  <p className="text-xl text-muted-foreground mb-4">3D View Loading...</p>
                  <div className="w-32 h-32 rounded-full bg-wealthsync-primary/20 animate-pulse mx-auto"></div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Viewer;
