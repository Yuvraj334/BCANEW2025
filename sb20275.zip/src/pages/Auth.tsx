import React, { useState } from 'react';
import { Eye, EyeOff, ArrowRight, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Checkbox } from '@/components/ui/checkbox';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from '@/hooks/use-toast';
import { useTheme } from '@/contexts/ThemeContext';
import { motion } from 'framer-motion';

const Auth = () => {
  const { mode } = useTheme();
  const [showPassword, setShowPassword] = useState(false);
  const [activeTab, setActiveTab] = useState<'login' | 'signup' | 'guest'>('login');
  
  // Login form state
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(false);
  
  // Signup form state
  const [signupName, setSignupName] = useState('');
  const [signupEmail, setSignupEmail] = useState('');
  const [signupPassword, setSignupPassword] = useState('');
  const [signupConfirmPassword, setSignupConfirmPassword] = useState('');
  const [agreeTerms, setAgreeTerms] = useState(false);
  const [age, setAge] = useState('');
  const [gender, setGender] = useState('');
  
  // Temporary auth simulation
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginEmail || !loginPassword) {
      toast({
        title: "Missing fields",
        description: "Please enter both email and password",
        variant: "destructive"
      });
      return;
    }
    
    // Simulate login (in a real app, this would call an API)
    localStorage.setItem('wealthsync-user', JSON.stringify({ name: "Demo User" }));
    window.location.href = '/';
  };
  
  const handleSignup = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!signupName || !signupEmail || !signupPassword || !signupConfirmPassword) {
      toast({
        title: "Missing fields",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }
    
    if (signupPassword !== signupConfirmPassword) {
      toast({
        title: "Passwords don't match",
        description: "Please make sure your passwords match",
        variant: "destructive"
      });
      return;
    }
    
    if (!agreeTerms) {
      toast({
        title: "Terms and Conditions",
        description: "Please agree to the Terms and Conditions to continue",
        variant: "destructive"
      });
      return;
    }
    
    // Simulate signup (in a real app, this would call an API)
    localStorage.setItem('wealthsync-user', JSON.stringify({ 
      name: signupName,
      email: signupEmail,
      age,
      gender
    }));
    window.location.href = '/';
  };
  
  const handleGuestLogin = () => {
    localStorage.setItem('wealthsync-user', JSON.stringify({ name: "Guest User" }));
    window.location.href = '/';
  };
  
  const handleDemoLogin = () => {
    localStorage.setItem('wealthsync-user', JSON.stringify({ name: "Demo User" }));
    window.location.href = '/';
  };

  return (
    <div className={`min-h-screen py-12 ${mode === "dark" ? "bg-wealthsync-dark" : "bg-white"}`}>
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row gap-8 max-w-5xl mx-auto">
          {/* Left column with logo and welcome text */}
          <motion.div 
            className="w-full md:w-5/12 flex flex-col justify-center"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className={`p-8 rounded-lg ${mode === "dark" ? "glass-card" : "bg-white shadow-md border border-gray-100"} flex flex-col items-center`}>
              <div className="mb-6 relative w-48 h-16">
                <motion.h1 
                  className="text-4xl font-bold absolute text-transparent bg-clip-text bg-gradient-to-r from-wealthsync-primary to-wealthsync-secondary"
                  animate={{ 
                    backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"],
                  }}
                  transition={{ 
                    duration: 15,
                    repeat: Infinity,
                    ease: "linear"
                  }}
                  style={{ 
                    backgroundSize: "200% 200%",
                  }}
                >
                  WealthSync
                </motion.h1>
              </div>
              
              <h2 className={`text-xl font-medium mb-4 text-center ${mode === "dark" ? "text-white" : "text-gray-800"}`}>
                Your Financial Companion
              </h2>
              <p className={`text-center mb-6 ${mode === "dark" ? "text-gray-300" : "text-gray-600"}`}>
                Track expenses, manage budgets, and reach your financial goals
              </p>
              
              <div className="mt-6 space-y-4 w-full">
                <div className={`p-4 rounded-lg ${mode === "dark" ? "bg-wealthsync-dark/50" : "bg-gray-50"} flex items-center`}>
                  <Check size={16} className="text-green-500 mr-3 flex-shrink-0" />
                  <p className="text-sm">Track all your expenses in one place</p>
                </div>
                <div className={`p-4 rounded-lg ${mode === "dark" ? "bg-wealthsync-dark/50" : "bg-gray-50"} flex items-center`}>
                  <Check size={16} className="text-green-500 mr-3 flex-shrink-0" />
                  <p className="text-sm">Get personalized financial insights</p>
                </div>
                <div className={`p-4 rounded-lg ${mode === "dark" ? "bg-wealthsync-dark/50" : "bg-gray-50"} flex items-center`}>
                  <Check size={16} className="text-green-500 mr-3 flex-shrink-0" />
                  <p className="text-sm">Set and achieve your savings goals</p>
                </div>
              </div>
            </div>
          </motion.div>
          
          {/* Right column with auth forms */}
          <motion.div 
            className="w-full md:w-7/12"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <div className={`p-8 rounded-lg ${mode === "dark" ? "glass-card" : "bg-white shadow-md border border-gray-100"}`}>
              <Tabs defaultValue={activeTab} value={activeTab} onValueChange={(value) => setActiveTab(value as "login" | "signup" | "guest")}>
                <TabsList className="grid grid-cols-3 mb-8 w-full">
                  <TabsTrigger value="login">Login</TabsTrigger>
                  <TabsTrigger value="signup">Sign Up</TabsTrigger>
                  <TabsTrigger value="guest">Guest</TabsTrigger>
                </TabsList>
                
                <TabsContent value="login">
                  <form onSubmit={handleLogin} className="space-y-6">
                    <div className="space-y-2">
                      <Label htmlFor="email">Email Address <span className="text-orange-500">*</span></Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="your@email.com"
                        className={mode === "dark" ? "bg-wealthsync-dark/70 border-gray-700" : "bg-gray-50"}
                        value={loginEmail}
                        onChange={(e) => setLoginEmail(e.target.value)}
                        required
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <Label htmlFor="password">Password <span className="text-orange-500">*</span></Label>
                        <Button variant="link" size="sm" className="text-xs p-0 h-auto text-wealthsync-secondary">
                          Forgot password?
                        </Button>
                      </div>
                      <div className="relative">
                        <Input
                          id="password"
                          type={showPassword ? "text" : "password"}
                          placeholder="••••••••"
                          className={`pr-10 ${mode === "dark" ? "bg-wealthsync-dark/70 border-gray-700" : "bg-gray-50"}`}
                          value={loginPassword}
                          onChange={(e) => setLoginPassword(e.target.value)}
                          required
                        />
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          className="absolute right-0 top-0 h-full"
                          onClick={() => setShowPassword(!showPassword)}
                        >
                          {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                        </Button>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Checkbox 
                        id="remember" 
                        checked={rememberMe}
                        onCheckedChange={(checked) => setRememberMe(checked === true)}
                      />
                      <Label htmlFor="remember" className="text-sm">
                        Remember me
                      </Label>
                    </div>
                    
                    <Button 
                      type="submit" 
                      className="w-full bg-wealthsync-primary hover:bg-wealthsync-primary/90"
                    >
                      Sign In
                      <ArrowRight size={16} className="ml-2" />
                    </Button>
                    
                    <div className="relative my-6">
                      <div className="absolute inset-0 flex items-center">
                        <Separator className={mode === "dark" ? "border-gray-700" : "border-gray-200"} />
                      </div>
                      <div className="relative flex justify-center text-xs">
                        <span className={`px-2 ${mode === "dark" ? "bg-wealthsync-dark" : "bg-white"} text-muted-foreground`}>
                          Or continue with
                        </span>
                      </div>
                    </div>
                    
                    <Button 
                      type="button" 
                      variant="outline" 
                      className={`w-full ${mode === "dark" ? "border-gray-700 hover:bg-wealthsync-dark/70" : ""}`}
                      onClick={handleDemoLogin}
                    >
                      Try Demo Account
                    </Button>
                  </form>
                </TabsContent>
                
                <TabsContent value="signup">
                  <form onSubmit={handleSignup} className="space-y-6">
                    <div className="space-y-2">
                      <Label htmlFor="name">Full Name <span className="text-orange-500">*</span></Label>
                      <Input
                        id="name"
                        type="text"
                        placeholder="John Doe"
                        className={mode === "dark" ? "bg-wealthsync-dark/70 border-gray-700" : "bg-gray-50"}
                        value={signupName}
                        onChange={(e) => setSignupName(e.target.value)}
                        required
                      />
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="age">Age</Label>
                        <Input
                          id="age"
                          type="number"
                          placeholder="25"
                          min="0"
                          max="120"
                          className={mode === "dark" ? "bg-wealthsync-dark/70 border-gray-700" : "bg-gray-50"}
                          value={age}
                          onChange={(e) => setAge(e.target.value)}
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="gender">Gender</Label>
                        <Select value={gender} onValueChange={setGender}>
                          <SelectTrigger className={mode === "dark" ? "bg-wealthsync-dark/70 border-gray-700" : "bg-gray-50"}>
                            <SelectValue placeholder="Select" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="male">Male</SelectItem>
                            <SelectItem value="female">Female</SelectItem>
                            <SelectItem value="non-binary">Non-binary</SelectItem>
                            <SelectItem value="other">Other</SelectItem>
                            <SelectItem value="prefer-not-to-say">Prefer not to say</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="signup-email">Email Address <span className="text-orange-500">*</span></Label>
                      <Input
                        id="signup-email"
                        type="email"
                        placeholder="your@email.com"
                        className={mode === "dark" ? "bg-wealthsync-dark/70 border-gray-700" : "bg-gray-50"}
                        value={signupEmail}
                        onChange={(e) => setSignupEmail(e.target.value)}
                        required
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="signup-password">Password <span className="text-orange-500">*</span></Label>
                      <div className="relative">
                        <Input
                          id="signup-password"
                          type={showPassword ? "text" : "password"}
                          placeholder="••••••••"
                          className={`pr-10 ${mode === "dark" ? "bg-wealthsync-dark/70 border-gray-700" : "bg-gray-50"}`}
                          value={signupPassword}
                          onChange={(e) => setSignupPassword(e.target.value)}
                          required
                        />
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          className="absolute right-0 top-0 h-full"
                          onClick={() => setShowPassword(!showPassword)}
                        >
                          {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                        </Button>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="confirm-password">Confirm Password <span className="text-orange-500">*</span></Label>
                      <Input
                        id="confirm-password"
                        type={showPassword ? "text" : "password"}
                        placeholder="••••••••"
                        className={mode === "dark" ? "bg-wealthsync-dark/70 border-gray-700" : "bg-gray-50"}
                        value={signupConfirmPassword}
                        onChange={(e) => setSignupConfirmPassword(e.target.value)}
                        required
                      />
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Checkbox 
                        id="terms" 
                        checked={agreeTerms}
                        onCheckedChange={(checked) => setAgreeTerms(checked === true)}
                      />
                      <Label htmlFor="terms" className="text-sm cursor-pointer">
                        I agree to the Terms and Conditions
                      </Label>
                    </div>
                    
                    <Button 
                      type="submit" 
                      className="w-full bg-wealthsync-primary hover:bg-wealthsync-primary/90"
                    >
                      Create Account
                      <ArrowRight size={16} className="ml-2" />
                    </Button>
                  </form>
                </TabsContent>

                <TabsContent value="guest">
                  <div className="space-y-6">
                    <div className={`p-6 rounded-lg ${mode === "dark" ? "bg-wealthsync-dark/30" : "bg-gray-50"}`}>
                      <h3 className="text-lg font-medium mb-2">Guest Mode</h3>
                      <p className="mb-4 text-muted-foreground">
                        Try WealthSync without creating an account. Some features will be limited.
                      </p>
                      <ul className="space-y-2 mb-6">
                        <li className="flex items-center">
                          <Check size={16} className="text-green-500 mr-2" />
                          <span className="text-sm">View all dashboard features</span>
                        </li>
                        <li className="flex items-center">
                          <Check size={16} className="text-green-500 mr-2" />
                          <span className="text-sm">Try expense tracking</span>
                        </li>
                        <li className="flex items-center text-muted-foreground/70">
                          <span className="line-through text-sm">Save preferences (requires account)</span>
                        </li>
                        <li className="flex items-center text-muted-foreground/70">
                          <span className="line-through text-sm">Sync data across devices (requires account)</span>
                        </li>
                      </ul>
                      <Button
                        type="button"
                        onClick={handleGuestLogin}
                        className="w-full bg-gray-500 hover:bg-gray-600"
                      >
                        Continue as Guest
                      </Button>
                    </div>
                    
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground">
                        Want full access?
                      </p>
                      <div className="flex gap-4 mt-3 justify-center">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setActiveTab("login")}
                          className={mode === "dark" ? "border-gray-700" : ""}
                        >
                          Login
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setActiveTab("signup")}
                          className={mode === "dark" ? "border-gray-700" : ""}
                        >
                          Create Account
                        </Button>
                      </div>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </motion.div>
        </div>
      </div>
      
      <style>
        {`
        @keyframes gradient-animation {
          0% {
            background-position: 0% 50%;
          }
          50% {
            background-position: 100% 50%;
          }
          100% {
            background-position: 0% 50%;
          }
        }
        `}
      </style>
    </div>
  );
};

export default Auth;
