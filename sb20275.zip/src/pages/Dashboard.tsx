
import React, { useState } from 'react';
import { useFinance } from '@/contexts/FinanceContext';
import { useTheme } from '@/contexts/ThemeContext';
import GreetingHeader from '@/components/dashboard/GreetingHeader';
import FinancialCard from '@/components/dashboard/FinancialCard';
import TransactionList from '@/components/dashboard/TransactionList';
import SavingGoals from '@/components/dashboard/SavingGoals';
import BillReminderCard from '@/components/dashboard/BillReminderCard';
import UpdateIncomeDialog from '@/components/dashboard/UpdateIncomeDialog';
import AddTransactionDialog from '@/components/dashboard/AddTransactionDialog';
import AddSavingGoalDialog from '@/components/dashboard/AddSavingGoalDialog';
import { Plus, Brain, BarChart3, FileEdit, StickyNote } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { useToast } from '@/components/ui/use-toast';
import { Textarea } from '@/components/ui/textarea';
import QuickToolCard from '@/components/tools/QuickToolCard';

const Dashboard = () => {
  const { transactions, savingGoals, financialSummary, billReminders, updateIncome, addSavingGoal, addBill } = useFinance();
  const { mode } = useTheme();
  const { toast } = useToast();
  
  const [isUpdateIncomeOpen, setIsUpdateIncomeOpen] = useState(false);
  const [isAddTransactionOpen, setIsAddTransactionOpen] = useState(false);
  const [isAddGoalOpen, setIsAddGoalOpen] = useState(false);
  const [isAddBillOpen, setIsAddBillOpen] = useState(false); // New state for bill reminder dialog
  const [note, setNote] = useState('');
  const [savedNotes, setSavedNotes] = useState<string[]>([]);
  
  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };
  
  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  const handleEditIncome = () => {
    setIsUpdateIncomeOpen(true);
  };
  
  const handleUpdateIncome = (newAmount: number) => {
    updateIncome(newAmount);
    setIsUpdateIncomeOpen(false);
    toast({
      title: "Income updated",
      description: `Your income has been updated to ${newAmount}`
    });
  };

  const handleAddGoal = () => {
    setIsAddGoalOpen(true);
  };
  
  const handleAddBill = () => {
    setIsAddBillOpen(true);
  };

  const handleSaveNote = () => {
    if (note.trim()) {
      setSavedNotes([...savedNotes, note]);
      setNote('');
      toast({
        title: "Note saved",
        description: "Your note has been saved successfully."
      });
    }
  };

  const handleDeleteNote = (index: number) => {
    const newNotes = [...savedNotes];
    newNotes.splice(index, 1);
    setSavedNotes(newNotes);
    toast({
      title: "Note deleted",
      description: "Your note has been deleted successfully."
    });
  };
  
  return (
    <motion.div 
      className={`container py-8 ${mode === 'dark' ? 'bg-black text-white border-white' : 'bg-white text-black border-black'}`}
      initial="hidden"
      animate="show"
      variants={container}
    >
      <GreetingHeader userName="Yuv Raj" style={{ background: mode === 'dark' ? 'linear-gradient(45deg, #333, #444)' : 'linear-gradient(45deg, #ff6b6b, #f06595, #cc5de8, #845ef7, #5c7cfa, #339af0, #22b8cf, #20c997, #51cf66, #94d82d, #fcc419, #ff922b, #ff6b6b)' }} />
      {/* Removed QuickToolCard */}
      <motion.div 
        className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8"
        variants={item}
      >
        <FinancialCard
          title="Total Income"
          amount={financialSummary.totalIncome}
          change={financialSummary.incomeChange}
          timePeriod="month"
          type="income"
          onEdit={handleEditIncome}
          className={`${mode === 'dark' ? 'bg-black text-white' : 'bg-white text-black'}`}
        />
        
        <FinancialCard
          title="Current Balance"
          amount={financialSummary.currentBalance}
          change={financialSummary.balanceChange}
          timePeriod="week"
          type="balance"
          className={`${mode === 'dark' ? 'bg-black text-white' : 'bg-white text-black'}`}
        />
        
        <FinancialCard
          title="Total Expenses"
          amount={financialSummary.totalExpenses}
          change={financialSummary.expensesChange}
          timePeriod="month"
          type="expense"
          className={`${mode === 'dark' ? 'bg-black text-white' : 'bg-white text-black'}`}
        />
      </motion.div>
      
      <motion.div 
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8"
        variants={item}
      >
        <div className="lg:col-span-2">
          <TransactionList
            transactions={transactions}
            onAddTransaction={() => setIsAddTransactionOpen(true)}
          />
        </div>
        <div className="space-y-6">
          <SavingGoals
            goals={savingGoals}
            onAddGoal={handleAddGoal}
          />
          <BillReminderCard 
            bills={billReminders || []} 
            onAddBill={handleAddBill}
          />
          <QuickToolCard />
          <div className="space-y-4">
            <h3 className="font-semibold">Quick Notes</h3>
            <Textarea
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Write your notes here..."
              className="w-full"
            />
            <Button onClick={handleSaveNote} className="bg-wealthsync-primary hover:bg-wealthsync-primary/90 text-white">
              Save Note
            </Button>
            <div className="space-y-2">
              {savedNotes.map((savedNote, index) => (
                <div key={index} className="flex justify-between items-center">
                  <span>{savedNote}</span>
                  <Button variant="destructive" onClick={() => handleDeleteNote(index)}>
                    Delete
                  </Button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </motion.div>

      {/* AI Assistant & Insights Cards at Bottom */}
      <motion.div 
        className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8"
        variants={item}
      >
        <Link to="/ai-assistant">
          <Card className="hover:shadow-lg transition-all duration-300 cursor-pointer border border-blue-500/20 h-full">
            <CardContent className="p-6 flex flex-col h-full">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 rounded-full bg-blue-500/20 flex items-center justify-center mr-4">
                  <Brain className="h-6 w-6 text-blue-400" />
                </div>
                <div>
                  <h3 className="text-xl font-bold">Finance Assistant</h3>
                  <p className="text-muted-foreground">Get personalized help with your finances</p>
                </div>
              </div>
              <p className="text-muted-foreground mb-4">
                Ask questions about your spending, get budgeting advice, or learn financial tips.
              </p>
              <div className="mt-auto">
                <Button variant="outline" className="w-full">
                  Ask a Question
                </Button>
              </div>
            </CardContent>
          </Card>
        </Link>

        <Link to="/insights">
          <Card className="hover:shadow-lg transition-all duration-300 cursor-pointer border border-green-500/20 h-full">
            <CardContent className="p-6 flex flex-col h-full">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 rounded-full bg-green-500/20 flex items-center justify-center mr-4">
                  <BarChart3 className="h-6 w-6 text-green-400" />
                </div>
                <div>
                  <h3 className="text-xl font-bold">Financial Insights</h3>
                  <p className="text-muted-foreground">Discover patterns in your spending</p>
                </div>
              </div>
              <p className="text-muted-foreground mb-4">
                Get detailed analytics, spending trends, and actionable insights to improve your finances.
              </p>
              <div className="mt-auto">
                <Button variant="outline" className="w-full">
                  View Insights
                </Button>
              </div>
            </CardContent>
          </Card>
        </Link>
      </motion.div>
      
      {/* Floating action button for adding expense */}
      <motion.div 
        className="fixed bottom-4 right-4 z-30"
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 0.5, type: "spring" }}
      >
        <Button 
          onClick={() => setIsAddTransactionOpen(true)}
          className="bg-wealthsync-primary text-primary-foreground hover:bg-wealthsync-primary/90 h-14 w-14 rounded-full shadow-lg flex items-center justify-center"
          aria-label="Add New Expense"
          title="Add New Expense"
        >
          <Plus size={24} />
        </Button>
      </motion.div>
      
      {/* Dialogs */}
      <UpdateIncomeDialog
        isOpen={isUpdateIncomeOpen}
        onClose={() => setIsUpdateIncomeOpen(false)}
        currentIncome={financialSummary.totalIncome}
        onSave={handleUpdateIncome}
      />
      
      <AddTransactionDialog
        isOpen={isAddTransactionOpen}
        onClose={() => setIsAddTransactionOpen(false)}
      />
      
      <AddSavingGoalDialog
        isOpen={isAddGoalOpen}
        onClose={() => setIsAddGoalOpen(false)}
      />
    </motion.div>
  );
};

export default Dashboard;
