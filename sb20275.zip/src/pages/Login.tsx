import React from 'react';
import { useTheme } from '@/contexts/ThemeContext';

const LoginPage: React.FC = () => {
  const { mode } = useTheme();
  return (
    <div className={mode === 'dark' ? 'bg-black text-white' : 'bg-white text-black'}>
      <h1>Login Page</h1>
      <button className={mode === 'dark' ? 'bg-white text-black' : 'bg-black text-white'}>Login</button>
      {/* Implement login form here */}
    </div>
  );
};

export default LoginPage;