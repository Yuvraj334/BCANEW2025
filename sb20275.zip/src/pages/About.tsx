
import { useState } from "react";
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Share2, Heart, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const About = () => {
  const { toast } = useToast();
  const [showShareSuccess, setShowShareSuccess] = useState(false);
  
  const fadeIn = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
  };

  const staggerContainer = {
    hidden: {},
    visible: {
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const features = [
    {
      title: "Transaction Tracking",
      description: "Keep track of your income and expenses with ease, helping you maintain a clear picture of your financial health.",
      icon: "💰"
    },
    {
      title: "Budget Management",
      description: "Create and monitor budgets for different spending categories, ensuring you stay on track with your financial goals.",
      icon: "📊"
    },
    {
      title: "Financial Insights",
      description: "Gain valuable insights into your spending patterns and financial behavior through detailed analytics.",
      icon: "📈"
    },
    {
      title: "Bill Reminders",
      description: "Never miss a payment with timely reminders for your bills and subscriptions.",
      icon: "🔔"
    },
    {
      title: "Savings Goals",
      description: "Set and track progress towards your financial goals, whether it's for a vacation, a new home, or retirement.",
      icon: "🎯"
    },
    {
      title: "Market Insights",
      description: "Stay updated with the latest financial market trends and news to make informed investment decisions.",
      icon: "📰"
    }
  ];

  const teamMembers = [
    {
      name: "Alex Johnson",
      role: "Founder & CEO",
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80",
      bio: "Financial expert with over 15 years of experience in personal finance and investment banking."
    },
    {
      name: "Sophia Chen",
      role: "CTO",
      image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80",
      bio: "Tech innovator with a passion for creating intuitive financial tools that empower users."
    },
    {
      name: "Marcus Williams",
      role: "Lead Designer",
      image: "https://images.unsplash.com/photo-1531427186611-ecfd6d936c79?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80",
      bio: "UX/UI specialist focused on creating beautiful, accessible financial interfaces."
    }
  ];
  
  const handleShare = async () => {
    try {
      if (navigator.share) {
        await navigator.share({
          title: 'WealthSync',
          text: 'Check out WealthSync, the ultimate personal finance companion!',
          url: window.location.origin,
        });
        toast({
          title: "Shared successfully!",
          description: "Thanks for sharing WealthSync with others.",
        });
      } else {
        // Fallback for browsers that don't support navigator.share
        navigator.clipboard.writeText(window.location.origin);
        setShowShareSuccess(true);
        toast({
          title: "Link copied to clipboard!",
          description: "Share the link with your friends and family.",
        });
        setTimeout(() => setShowShareSuccess(false), 2000);
      }
    } catch (error) {
      console.error("Error sharing:", error);
      toast({
        variant: "destructive",
        title: "Sharing failed",
        description: "An error occurred while trying to share.",
      });
    }
  };

  return (
    <div className="container mx-auto px-4 py-12">
      {/* Hero Section */}
      <motion.section 
        className="mb-16 text-center relative"
        initial="hidden"
        animate="visible"
        variants={fadeIn}
      >
        <div className="absolute inset-0 -z-10 bg-gradient-to-br from-primary/10 to-primary/5 rounded-3xl blur-3xl transform -translate-y-1/2"></div>
        <h1 className="text-4xl md:text-5xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-primary to-primary/70">About WealthSync</h1>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-8">
          Your comprehensive personal finance companion, designed to help you take control of your financial journey.
        </p>
        <motion.div 
          className="flex flex-wrap gap-4 justify-center"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Button 
            className="rounded-full gap-2 bg-primary text-primary-foreground"
            size="lg"
            onClick={handleShare}
          >
            <Share2 size={18} />
            {showShareSuccess ? <Check size={18} /> : "Share WealthSync"}
          </Button>
        </motion.div>
      </motion.section>

      {/* Our Mission */}
      <motion.section 
        className="mb-16"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.2 }}
        variants={staggerContainer}
      >
        <motion.div variants={fadeIn} className="max-w-3xl mx-auto text-center mb-12">
          <Badge className="mb-2">Our Mission</Badge>
          <h2 className="text-3xl font-bold mb-4 text-gradient">Financial Freedom for Everyone</h2>
          <p className="text-lg text-muted-foreground">
            At WealthSync, we believe that financial literacy and proper money management should be accessible to everyone. 
            Our mission is to empower individuals with the tools and knowledge needed to make informed financial decisions.
          </p>
        </motion.div>

        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          variants={staggerContainer}
        >
          {features.map((feature, index) => (
            <motion.div key={index} variants={fadeIn}>
              <Card className="h-full hover:shadow-lg transition-shadow hover:border-primary/20">
                <CardContent className="p-6">
                  <motion.div 
                    className="text-4xl mb-4"
                    whileHover={{ scale: 1.1, rotate: 5 }}
                    transition={{ type: 'spring', stiffness: 400, damping: 10 }}
                  >
                    {feature.icon}
                  </motion.div>
                  <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                  <p className="text-muted-foreground">{feature.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </motion.section>

      {/* Our Story */}
      <motion.section 
        className="mb-16"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.2 }}
        variants={fadeIn}
      >
        <div className="max-w-3xl mx-auto">
          <Badge className="mb-2">Our Story</Badge>
          <h2 className="text-3xl font-bold mb-4 text-gradient">The Journey of WealthSync</h2>
          <div className="prose dark:prose-invert max-w-none">
            <p>
              WealthSync began with a simple idea: make personal finance management accessible and even enjoyable. 
              Founded in 2020, our team of finance experts and technology enthusiasts came together during the
              global pandemic, recognizing the increasing importance of financial literacy and planning.
            </p>
            <p>
              We observed that many people struggle with managing their finances not because they lack discipline, 
              but because they lack the right tools that fit seamlessly into their lives. This insight drove us to 
              develop WealthSync, a platform that combines powerful financial tracking capabilities with an intuitive, 
              user-friendly interface.
            </p>
            <p>
              Since our launch, we've helped thousands of users gain better control of their finances, set and achieve 
              savings goals, and make more informed financial decisions. Our commitment to continuous improvement means 
              we're constantly adding new features and refining existing ones based on user feedback.
            </p>
          </div>
        </div>
      </motion.section>

      {/* Our Team */}
      <motion.section 
        className="mb-16"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.2 }}
        variants={staggerContainer}
      >
        <motion.div variants={fadeIn} className="text-center mb-12">
          <Badge className="mb-2">Our Team</Badge>
          <h2 className="text-3xl font-bold mb-4 text-gradient">Meet the Minds Behind WealthSync</h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Our diverse team brings together expertise in finance, technology, and design to create the best personal finance experience.
          </p>
        </motion.div>

        <motion.div 
          className="grid grid-cols-1 md:grid-cols-3 gap-8"
          variants={staggerContainer}
        >
          {teamMembers.map((member, index) => (
            <motion.div 
              key={index} 
              variants={fadeIn}
              whileHover={{ y: -10, transition: { duration: 0.2 } }}
            >
              <Card className="text-center overflow-hidden h-full">
                <div className="h-48 overflow-hidden">
                  <motion.img 
                    src={member.image} 
                    alt={member.name} 
                    className="w-full h-full object-cover"
                    whileHover={{ scale: 1.05 }}
                    transition={{ duration: 0.3 }}
                  />
                </div>
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold">{member.name}</h3>
                  <p className="text-muted-foreground mb-4">{member.role}</p>
                  <p>{member.bio}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </motion.section>

      {/* Contact CTA */}
      <motion.section 
        className="text-center"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.2 }}
        variants={fadeIn}
      >
        <div className="max-w-3xl mx-auto p-8 rounded-lg bg-gradient-to-br from-primary/10 to-muted/50">
          <h2 className="text-3xl font-bold mb-4">Get in Touch</h2>
          <p className="text-lg mb-6">
            Have questions about WealthSync or feedback to share? We'd love to hear from you!
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button size="lg" className="rounded-full gap-2 bg-primary text-primary-foreground">
              <Heart size={18} />
              Contact Us
            </Button>
            <Button size="lg" variant="outline" className="rounded-full">
              FAQs
            </Button>
          </div>
        </div>
      </motion.section>

      {/* Share Floating Button */}
      <motion.div
        className="fixed bottom-20 right-4 z-40"
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 1, type: "spring" }}
      >
        <Button
          onClick={handleShare}
          className="h-12 w-12 rounded-full bg-primary text-primary-foreground shadow-lg flex items-center justify-center"
        >
          <Share2 size={20} />
        </Button>
      </motion.div>
    </div>
  );
};

export default About;
