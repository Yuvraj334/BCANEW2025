
import React, { useState } from "react";
import { useTheme } from "@/contexts/ThemeContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "@/hooks/use-toast";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

// Testimonial data
const testimonials = [
  {
    id: 1,
    name: "Amanda Martinez",
    location: "San Francisco, CA",
    content: "WealthSync has transformed my financial life! The detailed insights and beautiful visualizations make it so easy to track my expenses. I've saved more money in the last 3 months than I did all of last year.",
    image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80",
    stars: 5
  },
  {
    id: 2,
    name: "James Wilson",
    location: "Chicago, IL",
    content: "As someone who's always struggled with budgeting, WealthSync has been a game-changer. The app is intuitive, and the financial insights are actually useful. I'm finally feeling in control of my finances.",
    image: "https://images.unsplash.com/photo-1563351672-62b74891a28a?auto=format&fit=crop&q=80",
    stars: 5
  },
  {
    id: 3,
    name: "Sophie Chen",
    location: "New York, NY",
    content: "I love how WealthSync organizes my expenses by category. The bill reminder feature has saved me from late fees multiple times. The AI assistant offers surprisingly helpful financial advice too!",
    image: "https://images.unsplash.com/photo-1469460340997-2f854421e72f?auto=format&fit=crop&q=80",
    stars: 4
  },
  {
    id: 4,
    name: "Marcus Johnson",
    location: "Atlanta, GA",
    content: "The saving goals feature on WealthSync has been a lifesaver since I started saving for my new home. Being able to visualize my progress keeps me motivated. Highly recommended!",
    image: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&q=80",
    stars: 5
  },
  {
    id: 5,
    name: "Elena Rodriguez",
    location: "Miami, FL",
    content: "As a busy professional, I appreciate how straightforward WealthSync is. The reports are accurate, and the dark mode is easy on the eyes. The multi-currency feature is perfect for my international travels!",
    image: "https://images.unsplash.com/photo-1499952127939-9bbf5af6c51c?auto=format&fit=crop&q=80",
    stars: 5
  },
  {
    id: 6,
    name: "Thomas Greene",
    location: "Seattle, WA",
    content: "The market insights section of WealthSync is exceptional. It helps me keep track of my investments alongside my everyday expenses. The comprehensive picture of my finances in one app is fantastic.",
    image: "https://images.unsplash.com/photo-1501196354995-cbb51c65aaea?auto=format&fit=crop&q=80",
    stars: 4
  }
];

const Testimonials = () => {
  const { mode } = useTheme();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [rating, setRating] = useState(5);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Testimonial Submitted",
      description: "Thank you for sharing your experience with WealthSync!",
    });
    // Reset form
    setName("");
    setEmail("");
    setMessage("");
    setRating(5);
  };
  
  // Render stars for ratings
  const renderStars = (count: number) => {
    return Array(5)
      .fill(0)
      .map((_, index) => (
        <span
          key={index}
          className={`text-2xl ${
            index < count ? "text-wealthsync-secondary" : "text-wealthsync-dimtext/40"
          }`}
        >
          ★
        </span>
      ));
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  return (
    <div className="container py-8">
      {/* Hero Section */}
      <section className="relative mb-16">
        <div className="absolute inset-0 bg-gradient-to-b from-wealthsync-dark to-black z-0 opacity-80"></div>
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1549590143-d5855148a9d5?auto=format&fit=crop&q=80')] bg-center bg-cover opacity-20 z-0"></div>
        
        <motion.div 
          className="container mx-auto px-4 py-24 relative z-10"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              What Our Users <span className="text-wealthsync-secondary">Say</span>
            </h1>
            <p className="text-lg md:text-xl text-wealthsync-dimtext">
              Discover how WealthSync has transformed the financial lives of users worldwide
            </p>
          </div>
        </motion.div>
      </section>
      
      {/* Testimonials Grid */}
      <motion.section
        variants={containerVariants}
        initial="hidden"
        animate="show"
        className="mb-16"
      >
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial) => (
            <motion.div
              key={testimonial.id}
              variants={itemVariants}
              transition={{ duration: 0.5 }}
            >
              <Card className="glass-card hover-scale h-full">
                <CardContent className="pt-6">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="h-16 w-16 rounded-full overflow-hidden">
                      <img
                        src={testimonial.image}
                        alt={testimonial.name}
                        className="h-full w-full object-cover"
                      />
                    </div>
                    <div>
                      <h3 className="font-bold">{testimonial.name}</h3>
                      <p className="text-wealthsync-dimtext text-sm">{testimonial.location}</p>
                    </div>
                  </div>
                  
                  <div className="mb-4">{renderStars(testimonial.stars)}</div>
                  
                  <blockquote className="text-wealthsync-text/90 italic">
                    "{testimonial.content}"
                  </blockquote>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </motion.section>
      
      {/* Share Your Experience */}
      <section className="mb-16">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6 }}
        >
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-2xl text-center">Share Your Experience</CardTitle>
            </CardHeader>
            <CardContent className="max-w-2xl mx-auto">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="name">Your Name <span className="text-orange-500">*</span></Label>
                    <Input
                      id="name"
                      type="text"
                      placeholder="John Doe"
                      className={mode === "dark" ? "bg-wealthsync-dark/70 border-gray-700" : ""}
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="email">Your Email <span className="text-orange-500">*</span></Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="your@email.com"
                      className={mode === "dark" ? "bg-wealthsync-dark/70 border-gray-700" : ""}
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="rating">Your Rating</Label>
                  <div className="flex space-x-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setRating(star)}
                        className={`text-3xl focus:outline-none ${
                          star <= rating ? "text-wealthsync-secondary" : "text-wealthsync-dimtext/40"
                        }`}
                      >
                        ★
                      </button>
                    ))}
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="message">Your Experience <span className="text-orange-500">*</span></Label>
                  <Textarea
                    id="message"
                    placeholder="Share your experience with WealthSync..."
                    className={`min-h-[150px] ${mode === "dark" ? "bg-wealthsync-dark/70 border-gray-700" : ""}`}
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    required
                  />
                </div>
                
                <Button type="submit" className="w-full bg-wealthsync-secondary hover:bg-wealthsync-secondary/90">
                  Submit Testimonial
                </Button>
              </form>
            </CardContent>
          </Card>
        </motion.div>
      </section>
      
      {/* Community Stats */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.3 }}
      >
        <h2 className="text-2xl font-bold text-center mb-8">Our Growing Community</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
          <Card className="glass-card">
            <CardContent className="pt-6">
              <div className="text-4xl font-bold text-wealthsync-secondary mb-2">50,000+</div>
              <p className="font-medium">Happy Users</p>
            </CardContent>
          </Card>
          
          <Card className="glass-card">
            <CardContent className="pt-6">
              <div className="text-4xl font-bold text-wealthsync-secondary mb-2">₹120M+</div>
              <p className="font-medium">Expenses Tracked</p>
            </CardContent>
          </Card>
          
          <Card className="glass-card">
            <CardContent className="pt-6">
              <div className="text-4xl font-bold text-wealthsync-secondary mb-2">4.8/5</div>
              <p className="font-medium">Average Rating</p>
            </CardContent>
          </Card>
        </div>
      </motion.section>
    </div>
  );
};

export default Testimonials;
