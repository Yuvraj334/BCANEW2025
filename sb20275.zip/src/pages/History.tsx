
import React, { useState } from 'react';
import { useFinance } from '@/contexts/FinanceContext';
import { formatCurrency } from '@/utils/currency';
import { Search, Calendar, ArrowUp, ArrowDown, Filter, Plus, FileDown, FileUp } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import AddTransactionDialog from '@/components/dashboard/AddTransactionDialog';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card } from '@/components/ui/card';

const ExportDialog = () => {
  const [exportFormat, setExportFormat] = useState('pdf');
  const [selectedData, setSelectedData] = useState<string[]>(['transactions']);
  
  const handleDataSelection = (type: string) => {
    if (selectedData.includes(type)) {
      setSelectedData(selectedData.filter(item => item !== type));
    } else {
      setSelectedData([...selectedData, type]);
    }
  };
  
  return (
    <DialogContent>
      <DialogHeader>
        <DialogTitle>Export Financial Data</DialogTitle>
        <DialogDescription>
          Select data types and format for export
        </DialogDescription>
      </DialogHeader>
      
      <div className="space-y-4 py-4">
        <div>
          <h4 className="text-sm font-medium mb-2">Select Data to Export</h4>
          <div className="space-y-2">
            {[
              { id: 'transactions', name: 'Transactions' },
              { id: 'bills', name: 'Bill Reminders' },
              { id: 'goals', name: 'Saving Goals' },
              { id: 'summary', name: 'Financial Summary' }
            ].map(item => (
              <div key={item.id} className="flex items-center">
                <input 
                  type="checkbox" 
                  id={item.id} 
                  checked={selectedData.includes(item.id)}
                  onChange={() => handleDataSelection(item.id)}
                  className="mr-2"
                />
                <label htmlFor={item.id}>{item.name}</label>
              </div>
            ))}
          </div>
        </div>
        
        <div>
          <h4 className="text-sm font-medium mb-2">Export Format</h4>
          <Tabs value={exportFormat} onValueChange={setExportFormat} className="w-full">
            <TabsList className="grid grid-cols-3 w-full">
              <TabsTrigger value="pdf">PDF</TabsTrigger>
              <TabsTrigger value="csv">CSV</TabsTrigger>
              <TabsTrigger value="excel">Excel</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </div>
      
      <div className="flex justify-end gap-2">
        <Button variant="outline">Cancel</Button>
        <Button>Export Data</Button>
      </div>
    </DialogContent>
  );
};

const History = () => {
  const { transactions } = useFinance();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPeriod, setSelectedPeriod] = useState<string>('all');
  const [isAddTransactionOpen, setIsAddTransactionOpen] = useState(false);
  
  const periods = [
    { value: 'all', label: 'All Time' },
    { value: 'month', label: 'This Month' },
    { value: 'week', label: 'This Week' },
    { value: 'today', label: 'Today' },
  ];
  
  // Filter by period
  const filterByPeriod = (transaction: any) => {
    const now = new Date();
    const txDate = new Date(transaction.date);
    
    switch (selectedPeriod) {
      case 'month':
        return txDate.getMonth() === now.getMonth() && txDate.getFullYear() === now.getFullYear();
      case 'week':
        const weekStart = new Date(now);
        weekStart.setDate(now.getDate() - now.getDay());
        return txDate >= weekStart;
      case 'today':
        return txDate.toDateString() === now.toDateString();
      default:
        return true;
    }
  };
  
  // Apply filters
  const filteredTransactions = transactions
    .filter(filterByPeriod)
    .filter(t => 
      searchQuery === '' || 
      t.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.category.toLowerCase().includes(searchQuery.toLowerCase())
    )
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  
  // Group transactions by date
  const groupedTransactions: Record<string, any[]> = {};
  
  filteredTransactions.forEach(transaction => {
    const dateKey = new Date(transaction.date).toDateString();
    if (!groupedTransactions[dateKey]) {
      groupedTransactions[dateKey] = [];
    }
    groupedTransactions[dateKey].push(transaction);
  });
  
  return (
    <div className="container py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Transaction History</h1>
        
        <div className="flex gap-2">
          <TooltipProvider>
            <Dialog>
              <Tooltip>
                <TooltipTrigger asChild>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="icon">
                      <FileDown size={18} />
                    </Button>
                  </DialogTrigger>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Export Data</p>
                </TooltipContent>
              </Tooltip>
              
              <ExportDialog />
            </Dialog>
          </TooltipProvider>
          
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="outline" size="icon">
                  <FileUp size={18} />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Import Data</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
          
          <Button 
            onClick={() => setIsAddTransactionOpen(true)}
            className="bg-primary text-primary-foreground flex gap-2"
          >
            <Plus size={18} />
            Add Transaction
          </Button>
        </div>
      </div>
      
      <div className="glass-card p-6 mb-8">
        <div className="flex flex-col md:flex-row md:items-center gap-4 md:gap-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" size={18} />
            <Input
              placeholder="Search transactions..."
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          
          <div className="flex gap-2 overflow-x-auto pb-2 md:pb-0">
            {periods.map(period => (
              <Button
                key={period.value}
                variant={selectedPeriod === period.value ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedPeriod(period.value)}
              >
                {period.label}
              </Button>
            ))}
          </div>
        </div>
      </div>
      
      {Object.keys(groupedTransactions).length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 text-center glass-card">
          <Calendar className="h-12 w-12 text-muted-foreground mb-4" />
          <h3 className="text-xl font-medium mb-2">No transactions found</h3>
          <p className="text-muted-foreground">
            {searchQuery 
              ? "Try adjusting your search or filters"
              : "Start adding transactions to see your history"
            }
          </p>
          <Button 
            onClick={() => setIsAddTransactionOpen(true)}
            className="mt-4 bg-primary text-primary-foreground"
          >
            <Plus size={18} className="mr-2" />
            Add First Transaction
          </Button>
        </div>
      ) : (
        <div className="space-y-8">
          {Object.entries(groupedTransactions).map(([date, dayTransactions]) => (
            <div key={date} className="space-y-4">
              <div className="flex items-center">
                <div className="bg-card px-4 py-2 rounded-full text-sm">
                  {new Date(date).toLocaleDateString('en-US', {
                    weekday: 'short',
                    month: 'short',
                    day: 'numeric'
                  })}
                </div>
                <div className="h-[1px] flex-1 bg-border ml-4"></div>
              </div>
              
              <div className="glass-card divide-y divide-border">
                {dayTransactions.map((transaction) => (
                  <div 
                    key={transaction.id}
                    className="flex items-center justify-between p-4 hover:bg-muted/20 transition-colors"
                  >
                    <div className="flex items-center space-x-4">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                        transaction.type === 'income' 
                          ? 'bg-wealthsync-success/20 text-wealthsync-success' 
                          : 'bg-wealthsync-danger/20 text-wealthsync-danger'
                      }`}>
                        {transaction.type === 'income' 
                          ? <ArrowUp size={18} />
                          : <ArrowDown size={18} />
                        }
                      </div>
                      
                      <div>
                        <h4 className="font-medium">{transaction.description}</h4>
                        <div className="flex items-center text-sm">
                          <span className="text-wealthsync-secondary">
                            {transaction.category}
                          </span>
                          <span className="mx-2 text-gray-600">•</span>
                          <span className="text-muted-foreground">
                            {new Date(transaction.date).toLocaleTimeString('en-US', {
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </span>
                        </div>
                      </div>
                    </div>
                    
                    <div className={`font-semibold ${
                      transaction.type === 'income' 
                        ? 'text-wealthsync-success' 
                        : 'text-wealthsync-danger'
                    }`}>
                      {transaction.type === 'income' ? '+' : '-'}
                      {formatCurrency(transaction.amount)}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      <AddTransactionDialog
        isOpen={isAddTransactionOpen}
        onClose={() => setIsAddTransactionOpen(false)}
      />
    </div>
  );
};

export default History;
