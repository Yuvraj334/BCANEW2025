
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Pencil, ArrowLeft, Mail, Phone, Lock, Bell, Shield, LogOut } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useTheme } from '@/contexts/ThemeContext';

const Profile = () => {
  const { mode } = useTheme();
  const navigate = useNavigate();
  const [user] = useState({
    name: 'Yuv Raj',
    email: 'yuv@example.com',
    phone: '+91 9876543210',
    avatar: '',
  });

  const handleLogout = () => {
    // Clear user data and redirect to login
    localStorage.removeItem('wealthsync-user');
    navigate('/login');
  };

  return (
    <div className="container py-8">
      <div className="flex items-center mb-6">
        <Button 
          variant="ghost" 
          className="mr-2 text-wealthsync-dimtext hover:text-wealthsync-text"
          onClick={() => navigate(-1)}
        >
          <ArrowLeft size={18} className="mr-1" />
          Back
        </Button>
        <h1 className="text-2xl font-bold">My Profile</h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left panel - User info */}
        <div className="space-y-6">
          <Card className="glass-card border-gray-700">
            <CardContent className="pt-6 text-center">
              <div className="relative inline-block mb-4">
                <Avatar className="h-24 w-24 border-4 border-wealthsync-primary">
                  <AvatarImage src={user.avatar} />
                  <AvatarFallback className="text-xl bg-gray-700">YR</AvatarFallback>
                </Avatar>
                <Button 
                  size="icon" 
                  className="absolute bottom-0 right-0 h-8 w-8 rounded-full bg-wealthsync-primary hover:bg-wealthsync-primary/90"
                >
                  <Pencil size={14} />
                </Button>
              </div>

              <h2 className="text-xl font-bold text-wealthsync-text">{user.name}</h2>
              <p className="text-wealthsync-dimtext">{user.email}</p>
              
              <div className="mt-6 flex justify-between items-center">
                <div className="text-center flex-1">
                  <p className="text-xs text-wealthsync-dimtext">Member Since</p>
                  <p className="text-wealthsync-text">May 2023</p>
                </div>
                <div className="border-l border-gray-700 h-10"></div>
                <div className="text-center flex-1">
                  <p className="text-xs text-wealthsync-dimtext">Account Type</p>
                  <div className="flex items-center justify-center gap-1">
                    <span className="text-wealthsync-text">Standard</span>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="border-t border-gray-700 pt-4 flex justify-center">
              <Button 
                variant="destructive"
                onClick={handleLogout}
                className="w-full bg-red-500/20 hover:bg-red-500/30 text-red-500"
              >
                <LogOut size={16} className="mr-2" />
                Sign Out
              </Button>
            </CardFooter>
          </Card>

          <Card className="glass-card border-gray-700">
            <CardHeader>
              <CardTitle className="text-wealthsync-text">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button 
                variant="outline" 
                className="w-full justify-start border-gray-700 text-wealthsync-text hover:border-wealthsync-primary"
                onClick={() => navigate('/expenses')}
              >
                View All Expenses
              </Button>
              <Button 
                variant="outline" 
                className="w-full justify-start border-gray-700 text-wealthsync-text hover:border-wealthsync-primary"
                onClick={() => navigate('/insights')}
              >
                Financial Insights
              </Button>
              <Button 
                variant="outline" 
                className="w-full justify-start border-gray-700 text-wealthsync-text hover:border-wealthsync-primary"
                onClick={() => navigate('/ai-assistant')}
              >
                Chat with AI Assistant
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Right panel - Account settings */}
        <div className="lg:col-span-2 space-y-6">
          <Card className="glass-card border-gray-700">
            <CardHeader>
              <CardTitle className="text-wealthsync-text">Account Settings</CardTitle>
              <CardDescription className="text-wealthsync-dimtext">
                Manage your profile information
              </CardDescription>
            </CardHeader>

            <CardContent>
              <Tabs defaultValue="personal">
                <TabsList className="w-full grid grid-cols-3 mb-6">
                  <TabsTrigger value="personal">Personal</TabsTrigger>
                  <TabsTrigger value="security">Security</TabsTrigger>
                  <TabsTrigger value="notifications">Notifications</TabsTrigger>
                </TabsList>

                <TabsContent value="personal">
                  <form className="space-y-6">
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="name">Full Name</Label>
                        <Input id="name" defaultValue={user.name} className="bg-wealthsync-dark/40 border-gray-700" />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="email">Email Address</Label>
                        <div className="relative">
                          <Mail className="absolute left-3 top-3 h-4 w-4 text-wealthsync-dimtext" />
                          <Input 
                            id="email" 
                            defaultValue={user.email} 
                            className="pl-10 bg-wealthsync-dark/40 border-gray-700" 
                          />
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="phone">Phone Number</Label>
                        <div className="relative">
                          <Phone className="absolute left-3 top-3 h-4 w-4 text-wealthsync-dimtext" />
                          <Input 
                            id="phone" 
                            defaultValue={user.phone} 
                            className="pl-10 bg-wealthsync-dark/40 border-gray-700" 
                          />
                        </div>
                      </div>
                    </div>

                    <div className="flex justify-end">
                      <Button className="bg-wealthsync-primary hover:bg-wealthsync-primary/90">
                        Save Changes
                      </Button>
                    </div>
                  </form>
                </TabsContent>

                <TabsContent value="security">
                  <div className="space-y-6">
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="current-password">Current Password</Label>
                        <div className="relative">
                          <Lock className="absolute left-3 top-3 h-4 w-4 text-wealthsync-dimtext" />
                          <Input 
                            id="current-password" 
                            type="password" 
                            placeholder="••••••••" 
                            className="pl-10 bg-wealthsync-dark/40 border-gray-700" 
                          />
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="new-password">New Password</Label>
                        <div className="relative">
                          <Lock className="absolute left-3 top-3 h-4 w-4 text-wealthsync-dimtext" />
                          <Input 
                            id="new-password" 
                            type="password" 
                            placeholder="••••••••" 
                            className="pl-10 bg-wealthsync-dark/40 border-gray-700" 
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="confirm-password">Confirm New Password</Label>
                        <div className="relative">
                          <Lock className="absolute left-3 top-3 h-4 w-4 text-wealthsync-dimtext" />
                          <Input 
                            id="confirm-password" 
                            type="password" 
                            placeholder="••••••••" 
                            className="pl-10 bg-wealthsync-dark/40 border-gray-700" 
                          />
                        </div>
                      </div>
                    </div>

                    <div className="pt-4 border-t border-gray-700">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="text-wealthsync-text font-medium">Two-Factor Authentication</h4>
                          <p className="text-xs text-wealthsync-dimtext">Enhance your account security</p>
                        </div>
                        <Switch />
                      </div>
                    </div>

                    <div className="flex justify-end">
                      <Button className="bg-wealthsync-primary hover:bg-wealthsync-primary/90">
                        Update Password
                      </Button>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="notifications">
                  <div className="space-y-6">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <Label className="text-wealthsync-text">Email Notifications</Label>
                          <p className="text-xs text-wealthsync-dimtext">Receive emails about account activity</p>
                        </div>
                        <Switch defaultChecked />
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <Label className="text-wealthsync-text">Push Notifications</Label>
                          <p className="text-xs text-wealthsync-dimtext">Receive push notifications on your device</p>
                        </div>
                        <Switch defaultChecked />
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <Label className="text-wealthsync-text">Bill Reminders</Label>
                          <p className="text-xs text-wealthsync-dimtext">Get notified before bills are due</p>
                        </div>
                        <Switch defaultChecked />
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <Label className="text-wealthsync-text">Spending Alerts</Label>
                          <p className="text-xs text-wealthsync-dimtext">Get notified when you exceed your budget</p>
                        </div>
                        <Switch />
                      </div>
                    </div>

                    <div className="flex justify-end">
                      <Button className="bg-wealthsync-primary hover:bg-wealthsync-primary/90">
                        Save Preferences
                      </Button>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>

          <Card className="glass-card border-gray-700">
            <CardHeader>
              <CardTitle className="text-wealthsync-text">Connected Accounts</CardTitle>
              <CardDescription className="text-wealthsync-dimtext">
                Manage your connected financial accounts
              </CardDescription>
            </CardHeader>

            <CardContent className="space-y-4">
              <div className="border border-gray-700 p-4 rounded-lg flex justify-between items-center">
                <div className="flex items-center">
                  <div className="h-10 w-10 rounded-full bg-blue-500 flex items-center justify-center mr-3">
                    <Shield size={18} className="text-white" />
                  </div>
                  <div>
                    <h4 className="text-wealthsync-text font-medium">Banking Account</h4>
                    <p className="text-xs text-wealthsync-dimtext">Connect your bank account for automatic tracking</p>
                  </div>
                </div>
                <Button variant="outline" className="border-gray-700">Connect</Button>
              </div>
              
              <div className="border border-gray-700 p-4 rounded-lg flex justify-between items-center">
                <div className="flex items-center">
                  <div className="h-10 w-10 rounded-full bg-green-500 flex items-center justify-center mr-3">
                    <Shield size={18} className="text-white" />
                  </div>
                  <div>
                    <h4 className="text-wealthsync-text font-medium">Investment Account</h4>
                    <p className="text-xs text-wealthsync-dimtext">Connect investment accounts for tracking</p>
                  </div>
                </div>
                <Button variant="outline" className="border-gray-700">Connect</Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Profile;
