
import React, { useRef, useEffect } from 'react';
import { useAiAssistant } from '@/contexts/AiAssistantContext';
import ChatMessage from '@/components/ai/ChatMessage';
import TypingIndicator from '@/components/ai/TypingIndicator';
import SuggestedQuestions from '@/components/ai/SuggestedQuestions';
import ChatInput from '@/components/ai/ChatInput';

const AiAssistant = () => {
  const { messages, isTyping, sendMessage, suggestedQuestions } = useAiAssistant();
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom when new messages come in
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  return (
    <div className="container max-w-4xl py-8">
      <div className="flex flex-col h-[80vh]">
        <div className="glass-card p-6 mb-6">
          <h1 className="text-2xl font-bold mb-2 flex items-center">
            <span className="text-wealthsync-secondary">AI</span>
            <span className="ml-2 text-wealthsync-text">Financial Assistant</span>
          </h1>
          <p className="text-wealthsync-dimtext">
            Ask me anything about your finances, budgeting, savings goals, or investment advice.
          </p>
        </div>

        <div className="flex-1 overflow-y-auto mb-4 glass-card p-6">
          <div className="space-y-4">
            {messages.map((message) => (
              <ChatMessage key={message.id} message={message} />
            ))}
            {isTyping && <TypingIndicator />}
            <div ref={messagesEndRef} />
          </div>
        </div>

        <div className="glass-card p-6">
          <SuggestedQuestions 
            questions={suggestedQuestions} 
            onSelect={sendMessage} 
          />
          <ChatInput 
            onSendMessage={sendMessage} 
            disabled={isTyping} 
          />
        </div>
      </div>
    </div>
  );
};

export default AiAssistant;
