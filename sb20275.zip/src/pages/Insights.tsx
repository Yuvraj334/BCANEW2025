
import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend, LineChart, Line } from 'recharts';
import { ChevronDown, TrendingUp, ArrowUpRight, BarChart3, PieChartIcon, LineChart as LineChartIcon, Search, BadgeDollarSign, Newspaper, Briefcase, Landmark, Bitcoin } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery } from '@tanstack/react-query';
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import MarketSection from '../components/insights/MarketSection';
import NewsSection from '../components/insights/NewsSection';
import { useFinance } from '@/contexts/FinanceContext';

const fetchCryptoData = async () => {
  try {
    // In a real app, we'd fetch from a real API
    // For now, let's return mock data that looks like the CoinGecko API response
    return [
      { id: "bitcoin", symbol: "btc", name: "Bitcoin", image: "https://assets.coingecko.com/coins/images/1/large/bitcoin.png", current_price: 67500.42, price_change_percentage_24h: 2.47, market_cap: 1326846090971, total_volume: 48952883048 },
      { id: "ethereum", symbol: "eth", name: "Ethereum", image: "https://assets.coingecko.com/coins/images/279/large/ethereum.png", current_price: 3345.21, price_change_percentage_24h: 1.32, market_cap: 401846090971, total_volume: 23952883048 },
      { id: "binancecoin", symbol: "bnb", name: "BNB", image: "https://assets.coingecko.com/coins/images/825/large/bnb-icon2_2x.png", current_price: 549.78, price_change_percentage_24h: -0.25, market_cap: 84846090971, total_volume: 11952883048 },
      { id: "solana", symbol: "sol", name: "Solana", image: "https://assets.coingecko.com/coins/images/4128/large/solana.png", current_price: 159.34, price_change_percentage_24h: 3.28, market_cap: 67846090971, total_volume: 7952883048 },
      { id: "cardano", symbol: "ada", name: "Cardano", image: "https://assets.coingecko.com/coins/images/975/large/cardano.png", current_price: 0.47, price_change_percentage_24h: -1.05, market_cap: 16846090971, total_volume: 952883048 },
    ];
  } catch (error) {
    console.error('Error fetching crypto data:', error);
    return [];
  }
};

const fetchMetalsData = async () => {
  try {
    return [
      { name: 'Gold', price: 1950.20, change: 0.5 },
      { name: 'Silver', price: 24.80, change: -0.2 },
      { name: 'Platinum', price: 950.10, change: 0.3 },
      { name: 'Palladium', price: 1200.40, change: -0.8 },
    ];
  } catch (error) {
    console.error('Error fetching metals data:', error);
    return [];
  }
};

const fetchStocksData = async () => {
  try {
    return [
      { symbol: 'AAPL', name: 'Apple Inc.', price: 174.50, change: 1.2 },
      { symbol: 'MSFT', name: 'Microsoft Corp', price: 340.20, change: 0.8 },
      { symbol: 'GOOGL', name: 'Alphabet Inc', price: 134.80, change: -0.5 },
      { symbol: 'AMZN', name: 'Amazon.com Inc', price: 178.30, change: 2.1 },
      { symbol: 'TSLA', name: 'Tesla Inc', price: 215.75, change: -1.2 },
      { symbol: 'NVDA', name: 'NVIDIA Corp', price: 458.60, change: 3.4 },
    ];
  } catch (error) {
    console.error('Error fetching stocks data:', error);
    return [];
  }
};

const fetchNewsData = async () => {
  try {
    return [
      { 
        title: 'Markets rally on hopes of interest rate cuts', 
        source: 'Financial Times', 
        date: '2023-07-12', 
        url: '#',
        category: 'investing',
      },
      { 
        title: 'Tech stocks surge as AI investments grow', 
        source: 'Wall Street Journal', 
        date: '2023-07-11', 
        url: '#',
        category: 'investing',
      },
      { 
        title: 'Central bank signals shift in monetary policy', 
        source: 'Bloomberg', 
        date: '2023-07-10', 
        url: '#',
        category: 'other',
      },
    ];
  } catch (error) {
    console.error('Error fetching news data:', error);
    return [];
  }
};

const Insights = () => {
  const [period, setPeriod] = useState('month');
  const [marketTab, setMarketTab] = useState('crypto');
  const [newsTab, setNewsTab] = useState('investing');
  const [mainTab, setMainTab] = useState('market');
  const [searchTerm, setSearchTerm] = useState('');
  const { transactions } = useFinance();

  const { data: cryptoData, isLoading: isCryptoLoading } = useQuery({
    queryKey: ['crypto'],
    queryFn: fetchCryptoData,
  });

  const { data: metalsData, isLoading: isMetalsLoading } = useQuery({
    queryKey: ['metals'],
    queryFn: fetchMetalsData,
  });

  const { data: stocksData, isLoading: isStocksLoading } = useQuery({
    queryKey: ['stocks'],
    queryFn: fetchStocksData,
  });

  const { data: newsData, isLoading: isNewsLoading } = useQuery({
    queryKey: ['news'],
    queryFn: fetchNewsData,
  });

  // Calculate expense data from transactions
  const expenseByCategory = transactions
    .filter(t => t.type === 'expense')
    .reduce((acc: Record<string, number>, t) => {
      acc[t.category] = (acc[t.category] || 0) + t.amount;
      return acc;
    }, {});

  const expenseData = Object.entries(expenseByCategory).map(([name, value]) => ({
    name,
    value
  })).sort((a, b) => b.value - a.value).slice(0, 5);

  // If there's no expense data, provide placeholders
  const finalExpenseData = expenseData.length === 0 
    ? [
        { name: 'Food', value: 500 },
        { name: 'Transport', value: 300 },
        { name: 'Shopping', value: 450 },
        { name: 'Bills', value: 800 },
        { name: 'Entertainment', value: 250 },
      ]
    : expenseData;

  // Monthly data for income vs expense chart
  const monthlyData = [
    { name: 'Jan', income: 5200, expense: 4100 },
    { name: 'Feb', income: 5400, expense: 4200 },
    { name: 'Mar', income: 5300, expense: 4500 },
    { name: 'Apr', income: 5500, expense: 4300 },
    { name: 'May', income: 5800, expense: 4700 },
    { name: 'Jun', income: 5600, expense: 4400 },
  ];

  // Daily spending data
  const dailySpendingData = [
    { day: 'Mon', amount: 65 },
    { day: 'Tue', amount: 45 },
    { day: 'Wed', amount: 80 },
    { day: 'Thu', amount: 120 },
    { day: 'Fri', amount: 95 },
    { day: 'Sat', amount: 140 },
    { day: 'Sun', amount: 75 },
  ];

  // Colors for charts
  const COLORS = ['#4CAF50', '#FF6B6B', '#FFBB28', '#0088FE', '#8884d8'];

  return (
    <div className="animate-fade-in">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold">Financial Insights</h1>
          <p className="text-muted-foreground">Analyze markets, news, and your finances</p>
        </div>
        <div className="flex mt-4 md:mt-0 space-x-2">
          <div className="relative w-full md:w-[220px]">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search markets & news..."
              className="pl-8"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <Select value={period} onValueChange={setPeriod}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select period" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="week">This Week</SelectItem>
              <SelectItem value="month">This Month</SelectItem>
              <SelectItem value="quarter">This Quarter</SelectItem>
              <SelectItem value="year">This Year</SelectItem>
              <SelectItem value="all">All Time</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Tabs value={mainTab} onValueChange={setMainTab} className="space-y-4">
        <TabsList className="bg-muted/40 p-1">
          <TabsTrigger value="market" className="flex items-center gap-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
            <BadgeDollarSign className="h-4 w-4" />
            Markets
          </TabsTrigger>
          <TabsTrigger value="news" className="flex items-center gap-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
            <Newspaper className="h-4 w-4" />
            News
          </TabsTrigger>
          <TabsTrigger value="overview" className="flex items-center gap-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
            <BarChart3 className="h-4 w-4" />
            My Finances
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="market" className="space-y-4">
          <Card className="glass-card">
            <CardHeader className="pb-2">
              <CardTitle>Market Insights</CardTitle>
              <CardDescription>Track real-time market data</CardDescription>
              
              <Tabs value={marketTab} onValueChange={setMarketTab} className="mt-2">
                <TabsList className="bg-background/50">
                  <TabsTrigger value="crypto" className="flex items-center gap-1">
                    <Bitcoin className="h-3 w-3" />
                    Crypto
                  </TabsTrigger>
                  <TabsTrigger value="metals" className="flex items-center gap-1">
                    <svg className="h-3 w-3" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M12 22V8M5 12H2a10 10 0 0020 0h-3"/>
                      <path d="M5 12V8a2 2 0 012-2h10a2 2 0 012 2v4"/>
                    </svg>
                    Metals
                  </TabsTrigger>
                  <TabsTrigger value="stocks" className="flex items-center gap-1">
                    <Briefcase className="h-3 w-3" />
                    Stocks
                  </TabsTrigger>
                  <TabsTrigger value="sectors" className="flex items-center gap-1">
                    <Landmark className="h-3 w-3" />
                    Sectors
                  </TabsTrigger>
                </TabsList>
              </Tabs>
            </CardHeader>
            <CardContent className="pt-2">
              <MarketSection 
                marketTab={marketTab} 
                cryptoData={cryptoData}
                metalsData={metalsData}
                stocksData={stocksData}
                isCryptoLoading={isCryptoLoading}
                isMetalsLoading={isMetalsLoading}
                isStocksLoading={isStocksLoading}
                searchTerm={searchTerm}
              />
            </CardContent>
          </Card>

          {/* Market Trends Chart */}
          <Card className="glass-card">
            <CardHeader>
              <CardTitle>Market Trends</CardTitle>
              <CardDescription>Historical performance of major indices</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={[
                      { date: 'Jan', sp500: 4500, nasdaq: 14200, dow: 35000 },
                      { date: 'Feb', sp500: 4450, nasdaq: 13900, dow: 34700 },
                      { date: 'Mar', sp500: 4600, nasdaq: 14400, dow: 35300 },
                      { date: 'Apr', sp500: 4650, nasdaq: 14500, dow: 35500 },
                      { date: 'May', sp500: 4700, nasdaq: 14800, dow: 35800 },
                      { date: 'Jun', sp500: 4750, nasdaq: 15000, dow: 36000 },
                      { date: 'Jul', sp500: 4800, nasdaq: 15200, dow: 36200 },
                      { date: 'Aug', sp500: 4780, nasdaq: 15100, dow: 36100 },
                      { date: 'Sep', sp500: 4800, nasdaq: 15300, dow: 36300 },
                      { date: 'Oct', sp500: 4830, nasdaq: 15400, dow: 36400 },
                      { date: 'Nov', sp500: 4900, nasdaq: 15600, dow: 36600 },
                    ]}
                    margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                    <XAxis dataKey="date" />
                    <YAxis domain={['auto', 'auto']} />
                    <Tooltip contentStyle={{ backgroundColor: '#1a1a2e', borderColor: '#2d2d3d' }} />
                    <Legend />
                    <Line type="monotone" dataKey="sp500" name="S&P 500" stroke="#4CAF50" activeDot={{ r: 8 }} strokeWidth={2} />
                    <Line type="monotone" dataKey="nasdaq" name="NASDAQ" stroke="#FF6B6B" activeDot={{ r: 8 }} strokeWidth={2} />
                    <Line type="monotone" dataKey="dow" name="Dow Jones" stroke="#2196F3" activeDot={{ r: 8 }} strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="news" className="space-y-4">
          <Card className="glass-card">
            <CardHeader className="pb-2">
              <CardTitle>Financial News</CardTitle>
              <CardDescription>Latest financial and market news</CardDescription>
              
              <Tabs value={newsTab} onValueChange={setNewsTab} className="mt-2">
                <TabsList className="bg-background/50">
                  <TabsTrigger value="investing">
                    Investment Tips
                  </TabsTrigger>
                  <TabsTrigger value="spending">
                    Spending Strategies
                  </TabsTrigger>
                  <TabsTrigger value="other">
                    General News
                  </TabsTrigger>
                </TabsList>
              </Tabs>
            </CardHeader>
            <CardContent className="pt-2">
              <NewsSection 
                newsTab={newsTab} 
                newsData={newsData}
                isNewsLoading={isNewsLoading}
                searchTerm={searchTerm}
              />
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="glass-card hover:shadow-md transition-all">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Spending Rate</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">₹650/day</div>
                <p className="text-xs text-muted-foreground">based on this month's spending</p>
                <div className="mt-2 flex items-center text-green-500">
                  <ArrowUpRight className="h-4 w-4 mr-1" />
                  <span className="text-xs">12% from last month</span>
                </div>
              </CardContent>
            </Card>
            <Card className="glass-card hover:shadow-md transition-all">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Avg. Transaction</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">₹1,250</div>
                <p className="text-xs text-muted-foreground">per transaction this month</p>
                <div className="mt-2 flex items-center text-red-500">
                  <ArrowUpRight className="h-4 w-4 mr-1" />
                  <span className="text-xs">8% from last month</span>
                </div>
              </CardContent>
            </Card>
            <Card className="glass-card hover:shadow-md transition-all">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Monthly Budget</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">75% Used</div>
                <p className="text-xs text-muted-foreground">of your budget this month</p>
                <div className="mt-2 flex items-center text-amber-500">
                  <ArrowUpRight className="h-4 w-4 mr-1" />
                  <span className="text-xs">₹5,000 remaining</span>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Income vs Expenses Chart */}
            <Card className="glass-card">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <BarChart3 className="h-5 w-5 mr-2" />
                  Income vs Expenses
                </CardTitle>
                <CardDescription>Comparison over the last 6 months</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={monthlyData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip formatter={(value) => [`₹${value}`, undefined]} />
                      <Legend />
                      <Bar dataKey="income" name="Income" fill="#4CAF50" radius={[4, 4, 0, 0]} />
                      <Bar dataKey="expense" name="Expense" fill="#FF6B6B" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Expense Categories Pie Chart */}
            <Card className="glass-card">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <PieChartIcon className="h-5 w-5 mr-2" />
                  Expense Breakdown
                </CardTitle>
                <CardDescription>Top spending categories</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={finalExpenseData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={100}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {finalExpenseData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => [`₹${value}`, undefined]} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Daily Spending Chart */}
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="flex items-center">
                <LineChartIcon className="h-5 w-5 mr-2" />
                Daily Spending Trend
              </CardTitle>
              <CardDescription>This week's spending pattern</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={dailySpendingData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                    <XAxis dataKey="day" />
                    <YAxis />
                    <Tooltip formatter={(value) => [`₹${value}`, 'Amount']} />
                    <Bar dataKey="amount" fill="#9b87f5" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Insights;
